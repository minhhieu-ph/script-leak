"""Checkpoint choice and early stopping driven by the real dev set during training (v30).

Reads <exp_dir>/devmon.jsonl, written by nemo_tools.devmon after every epoch
(leak and CER/WER on small real dev subsets, greedy and with the script lock).
All rules score the lock decoding (that is how the model would be deployed):

  final         the last epoch
  min-leak      lowest dev leak (Thai->Latin + English->Thai) over the saved epochs
  guarded       lowest dev leak among epochs whose dev CER and WER are at most TOL
                above the final epoch's (needs the whole run)
  es(P)         online early stopping: at each epoch, among the epochs seen so far whose dev
                CER and WER are at most TOL above the best seen so far, take the one with
                the lowest dev leak; stop once that choice has not changed for P epochs.
                Uses only past epochs, so it works while training and saves the rest.

  python -m scriptleak.esmon select --exp-dir exp/B20_rir_es [--prune]
  python -m scriptleak.esmon report --work $W --labels clean_es clean_s1_es ...
"""

from __future__ import annotations

import argparse
import glob
import json
import multiprocessing as mp
import os
import re
import sys
from typing import Dict, List, Optional

import numpy as np

SETS = ("dev_lotus_th", "dev_ami_en")
TEST = ("real_lotus_th", "real_ami_en")


def load(exp_dir: str) -> List[Dict]:
    path = os.path.join(exp_dir, "devmon.jsonl")
    if not os.path.exists(path):
        return []
    rows = {}
    with open(path, encoding="utf-8") as f:
        for l in f:
            if l.strip():
                r = json.loads(l)
                rows[r["epoch"]] = r  # a restarted run overwrites earlier lines
    return [rows[e] for e in sorted(rows)]


def leak(r: Dict, m: str = "lock") -> float:
    return r[f"{SETS[0]}/{m}/leak"] + r[f"{SETS[1]}/{m}/leak"]


def errs(r: Dict, m: str = "lock"):
    return r[f"{SETS[0]}/{m}/err"], r[f"{SETS[1]}/{m}/err"]


def select(rows: List[Dict], saved: List[int], tol: float = 0.01, patience: int = 5) -> Dict:
    """Epoch picked by each rule. `saved`: epochs that have a checkpoint (the
    last epoch is always available as final.nemo)."""
    if not rows:
        return {}
    last = rows[-1]["epoch"]
    avail = [r for r in rows if r["epoch"] in saved or r["epoch"] == last]
    out = {"final": last, "min-leak": min(avail, key=lambda r: (leak(r), -r["epoch"]))["epoch"]}
    cf, wf = errs(rows[-1])
    ok = [r for r in avail if errs(r)[0] <= cf + tol and errs(r)[1] <= wf + tol]
    out["guarded"] = min(ok, key=lambda r: (leak(r), -r["epoch"]))["epoch"] if ok else last
    for P in sorted({patience, 3, 10}):
        best, best_c, best_w, since, stop, seen = None, np.inf, np.inf, 0, last, []
        for r in rows:
            c, w = errs(r)
            best_c, best_w = min(best_c, c), min(best_w, w)
            if r["epoch"] in saved or r["epoch"] == last:
                seen.append(r)
            # re-checked every epoch: an early pick drops out once accuracy has moved on
            ok_now = [x for x in seen if errs(x)[0] <= best_c + tol and errs(x)[1] <= best_w + tol]
            cand = min(ok_now, key=lambda x: (leak(x), -x["epoch"])) if ok_now else None
            if cand is not None and (best is None or cand["epoch"] != best["epoch"]):
                best, since = cand, 0
            else:
                since += 1
            if best is not None and since >= P:
                stop = r["epoch"]
                break
        out[f"es{P}"] = best["epoch"] if best is not None else last
        out[f"es{P}_stop"] = stop
    return out


def select_fixed(rows: List[Dict], save_from: int = 10, tol: float = 0.01, patience: int = 5) -> Dict:
    """v35 online rule. The v30 rule compared each saved epoch with the best CER and
    WER of *every* epoch so far, including epochs 1..save_from-1 that are never
    saved; on noisy 1000-utterance dev subsets no saved epoch was then within TOL of
    both bests, the eligible set stayed empty and the rule fell back to the last
    epoch. Here the reference is the best over the checkpointable epochs only
    (epoch >= save_from), so the eligible set is never empty.
    Returns {"pick": epoch, "stop": epoch, "stopped": bool}."""
    last = rows[-1]["epoch"] if rows else 0
    best, since, seen = None, 0, []
    for r in rows:
        if r["epoch"] < save_from and r["epoch"] != last:
            continue
        seen.append(r)
        bc = min(errs(x)[0] for x in seen)
        bw = min(errs(x)[1] for x in seen)
        ok = [x for x in seen if errs(x)[0] <= bc + tol and errs(x)[1] <= bw + tol]
        if not ok:  # CER-best and WER-best epochs differ by more than tol: use the mean error
            bm = min(sum(errs(x)) for x in seen)
            ok = [x for x in seen if sum(errs(x)) <= bm + 2 * tol]
        cand = min(ok, key=lambda x: (leak(x), -x["epoch"]))
        if best is None or cand["epoch"] != best["epoch"]:
            best, since = cand, 0
        else:
            since += 1
        if since >= patience:
            return {"pick": best["epoch"], "stop": r["epoch"], "stopped": True}
    return {"pick": best["epoch"] if best else last, "stop": last, "stopped": False}


def cmd_resim(args) -> int:
    """Re-run the online rule (v35 fix) on devmon.jsonl; CPU only, no training.
    Test numbers are shown where a dump of the picked epoch exists (after --prune
    only the v30 picks and the final model have one)."""
    from .pareto import rates, score_dump

    cache: Dict[str, Optional[Dict]] = {}

    def test(l, e, last):
        out = {}
        for s in TEST:
            p = _cand_dump(args.work, args.b_pct, l, e, last, s)
            if p not in cache:
                cache[p] = None
                if os.path.exists(os.path.join(p, "meta.json")):
                    try:
                        cache[p] = {k: v.tolist() for k, v in rates(score_dump(p, s, ["greedy", "lock"])).items()}
                    except Exception as ex:  # noqa: BLE001
                        print(f"!! {p}: {type(ex).__name__}: {ex}")
            if cache[p] is None:
                return None
            out[s] = cache[p]
        t, a = out[TEST[0]], out[TEST[1]]
        return {"Th>L": t["leak"][1], "En>Th": a["leak"][1], "CER": t["err"][1], "WER": a["err"][1]}

    res = {}
    L = [f"v35 online early stopping (reference = best over epochs >= {args.save_from}); lock decoding",
         "  run            tol  P  pick stop  saved%   dev leak/CER/WER        test Th>L En>Th  sum  CER Th WER En"]
    for l in args.labels:
        exp = os.path.join(args.work, "exp", f"B{args.b_pct}_{l}")
        rows = load(exp)
        if not rows:
            L.append(f"  {l}: no devmon.jsonl")
            continue
        last = rows[-1]["epoch"]
        byep = {r["epoch"]: r for r in rows}
        sv = [r for r in rows if r["epoch"] >= args.save_from]
        L.append(f"  {l}: dev leak over saved epochs min {min(leak(r) for r in sv):.1%} "
                 f"(epoch {min(sv, key=leak)['epoch']}), max {max(leak(r) for r in sv):.1%}; final {leak(rows[-1]):.1%}")
        for tol in args.tols:
            for P in args.patience:
                f = select_fixed(rows, args.save_from, tol, P)
                r = byep[f["pick"]]
                t = test(l, f["pick"], last)
                tt = (f"{t['Th>L']:6.1%} {t['En>Th']:5.1%} {t['Th>L'] + t['En>Th']:5.1%} {t['CER']:6.1%} {t['WER']:6.1%}"
                      if t else "   (no checkpoint left for this epoch)")
                L.append(f"  {l:<14} {tol:.2f} {P:>2} {f['pick']:>5} {f['stop']:>4}{'' if f['stopped'] else '*'} "
                         f"{1 - f['stop'] / last:6.0%}   {leak(r):5.1%}/{errs(r)[0]:5.1%}/{errs(r)[1]:5.1%}   {tt}")
                res.setdefault(l, {})[f"tol{tol}_P{P}"] = {**f, "test": t}
        for e in sorted({int(v) for k, v in json.load(open(os.path.join(exp, "esmon_picks.json"))).items()
                         if not k.endswith("_stop")} if os.path.exists(os.path.join(exp, "esmon_picks.json")) else []):
            t = test(l, e, last)
            if t:
                L.append(f"  {l:<14} available epoch {e:>3}: test {t['Th>L']:6.1%} {t['En>Th']:5.1%} "
                         f"{t['Th>L'] + t['En>Th']:5.1%} {t['CER']:6.1%} {t['WER']:6.1%}")
    L.append("  (* = never stopped, pick taken at the last epoch; saved% = share of the 50 epochs not trained)")
    print("\n".join(L))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(res, fh, indent=1)
    return 0


def saved_epochs(exp_dir: str) -> List[int]:
    out = []
    for p in glob.glob(os.path.join(exp_dir, "mon_epoch*.nemo")):
        m = re.search(r"mon_epoch(\d+)\.nemo$", p)
        if m:
            out.append(int(m.group(1)))
    return sorted(out)


def cmd_select(args) -> int:
    rows = load(args.exp_dir)
    if not rows:
        print(f"no devmon.jsonl in {args.exp_dir}")
        return 1
    picks = select(rows, saved_epochs(args.exp_dir), args.tol, args.patience)
    with open(os.path.join(args.exp_dir, "esmon_picks.json"), "w", encoding="utf-8") as f:
        json.dump(picks, f, indent=1)
    print(json.dumps(picks))
    if args.prune:
        keep = {v for k, v in picks.items() if not k.endswith("_stop")}
        for e in saved_epochs(args.exp_dir):
            if e not in keep:
                os.remove(os.path.join(args.exp_dir, f"mon_epoch{e:03d}.nemo"))
    return 0


# ------------------------------------------------------------------ report

def _cand_dump(work, b_pct, label, epoch, last, s):
    d = os.path.join(work, "dumps", f"B{b_pct}_{label}")
    return os.path.join(d, s) if epoch == last else os.path.join(d, f"mon_epoch{epoch:03d}_{s}")


def _job(args):
    from .pareto import rates, score_dump

    path, s = args
    try:
        r = rates(score_dump(path, s, ["greedy", "lock"]))
        return path, {k: v.tolist() for k, v in r.items()}
    except Exception as e:  # noqa: BLE001
        return path, f"{type(e).__name__}: {e}"


def cmd_report(args) -> int:
    labels = args.labels
    runs = {}
    for l in labels:
        exp = os.path.join(args.work, "exp", f"B{args.b_pct}_{l}")
        rows = load(exp)
        pf = os.path.join(exp, "esmon_picks.json")
        if not rows or not os.path.exists(pf):
            print(f"   {l}: no devmon.jsonl / esmon_picks.json yet, skipped")
            continue
        runs[l] = {"rows": rows, "picks": json.load(open(pf, encoding="utf-8"))}
    if not runs:
        print("nothing to report (run 'esB' first)")
        return 1
    jobs = []
    for l, r in runs.items():
        last = r["rows"][-1]["epoch"]
        for k, e in r["picks"].items():
            if k.endswith("_stop"):
                continue
            for s in TEST:
                p = _cand_dump(args.work, args.b_pct, l, e, last, s)
                if os.path.exists(os.path.join(p, "meta.json")):
                    jobs.append((p, s))
    jobs = sorted(set(jobs))
    got = {}
    with mp.get_context("spawn").Pool(max(1, args.workers)) as pool:
        for p, r in pool.imap_unordered(_job, jobs):
            if isinstance(r, str):
                print(f"!! {p}: {r}")
            else:
                got[p] = r
    L = ["Dev curves (lock decoding, small real dev subsets): epoch: leak sum / CER Thai / WER English"]
    for l, r in runs.items():
        pts = [f"{x['epoch']}:{leak(x):.0%}/{errs(x)[0]:.0%}/{errs(x)[1]:.0%}" for x in r["rows"]
               if x["epoch"] % 5 == 0 or x["epoch"] in r["picks"].values()]
        L.append(f"  {l:<14} " + "  ".join(pts))
        L.append(f"  {'':<14} dev leak over the run: min {min(leak(x) for x in r['rows']):.1%}, "
                 f"max {max(leak(x) for x in r['rows']):.1%}; picks {r['picks']}")
    rules = ["final/greedy", "final", "min-leak", "guarded"] + sorted(
        {k for r in runs.values() for k in r["picks"] if k.startswith("es") and not k.endswith("_stop")})
    table = {}
    for l, r in runs.items():
        last = r["rows"][-1]["epoch"]
        for rule in rules:
            key, m = (rule.split("/")[0], 0) if rule.endswith("/greedy") else (rule, 1)
            e = r["picks"].get(key)
            if e is None:
                continue
            ps = [_cand_dump(args.work, args.b_pct, l, e, last, s) for s in TEST]
            if not all(p in got for p in ps):
                continue
            t, a = got[ps[0]], got[ps[1]]
            table.setdefault(rule, {})[l] = {"epoch": e, "Th>L": t["leak"][m], "En>Th": a["leak"][m],
                                             "CER": t["err"][m], "WER": a["err"][m]}
    L.append("\nTest sets, per rule (lock decoding unless marked greedy): mean over runs [min-max of leak sum]")
    L.append(f"  {'rule':<14} {'Th>L':>6} {'En>Th':>6} {'sum':>6} {'range':>14} {'CER Th':>7} {'WER En':>7}  epochs")
    groups = {}
    for l in runs:
        groups.setdefault(re.sub(r"(_s\d+)?_es$", "", l), []).append(l)
    for g, ls in groups.items():
        L.append(f"  -- {g} ({', '.join(ls)})")
        for rule in rules:
            v = [table.get(rule, {}).get(l) for l in ls]
            v = [x for x in v if x]
            if not v:
                continue
            sums = [x["Th>L"] + x["En>Th"] for x in v]
            L.append(f"  {rule:<14} {np.mean([x['Th>L'] for x in v]):6.1%} {np.mean([x['En>Th'] for x in v]):6.1%} "
                     f"{np.mean(sums):6.1%} {min(sums):6.1%}-{max(sums):6.1%} {np.mean([x['CER'] for x in v]):7.1%} "
                     f"{np.mean([x['WER'] for x in v]):7.1%}  " + ",".join(str(x["epoch"]) for x in v))
    stops = [(l, k, v) for l, r in runs.items() for k, v in r["picks"].items() if k.endswith("_stop")]
    if stops:
        L.append("\nEarly stopping: epoch at which training could have stopped (of "
                 f"{max(r['rows'][-1]['epoch'] for r in runs.values())})")
        for l, k, v in stops:
            L.append(f"  {l:<14} {k[:-5]:<5} stop at {v}")
    print("\n".join(L))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump({"table": table, "picks": {l: r["picks"] for l, r in runs.items()}}, f, indent=1)
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("select")
    a.add_argument("--exp-dir", required=True)
    a.add_argument("--tol", type=float, default=float(os.environ.get("SEL_TOL", "0.01")))
    a.add_argument("--patience", type=int, default=int(os.environ.get("ES_PATIENCE", "5")))
    a.add_argument("--prune", action="store_true", help="delete mon_epoch*.nemo that no rule picked")
    a = sub.add_parser("report")
    a.add_argument("--work", default=os.environ.get("W"))
    a.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    a.add_argument("--labels", nargs="+", required=True)
    a.add_argument("--workers", type=int, default=int(os.environ.get("CALIB_WORKERS", "16")))
    a.add_argument("--out")
    a = sub.add_parser("resim")
    a.add_argument("--work", default=os.environ.get("W"))
    a.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    a.add_argument("--labels", nargs="+", required=True)
    a.add_argument("--save-from", type=int, default=int(os.environ.get("MON_SAVE_FROM", "10")))
    a.add_argument("--tols", type=float, nargs="+", default=[0.01, 0.02, 0.03])
    a.add_argument("--patience", type=int, nargs="+", default=[3, 5, 10])
    a.add_argument("--out")
    args = p.parse_args(argv)
    return {"select": cmd_select, "report": cmd_report, "resim": cmd_resim}[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
