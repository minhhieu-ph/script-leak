import json, os, sys
import numpy as np
from scriptleak import baselines


def test_dev_paths_and_score(tmp_path, capsys):
    sys.path.insert(0, os.path.dirname(__file__))
    import test_v34
    w = str(tmp_path)
    os.makedirs(os.path.join(w, "real"))
    for _, m in baselines.DEV_MANIFESTS:
        with open(os.path.join(w, "real", m), "w") as f:
            f.write(json.dumps({"audio_filepath": f"/{m}/0.wav"}) + "\n")
    assert len(baselines._test_paths(w, dev=True)) == 2
    # reuse the v34 fixture, then rename its test dumps to dev dumps
    try:
        test_v34.test_score_full(tmp_path, capsys)
    except Exception:
        pass
    capsys.readouterr()
    moved = 0
    for d in os.listdir(os.path.join(w, "dumps")):
        for s, dv in baselines.DEV_OF.items():
            src = os.path.join(w, "dumps", d, s)
            if os.path.isdir(src):
                os.rename(src, os.path.join(w, "dumps", d, dv))
                moved += 1
    assert moved
    args = test_v34._args(w)
    args.dev = True
    assert baselines.cmd_score(args) == 0
    out = capsys.readouterr().out
    assert "DEV sets" in out and "fuse:voxlingua107" in out and "Typhoon" not in out
