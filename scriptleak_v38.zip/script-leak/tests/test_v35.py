import json, os
import numpy as np
from scriptleak import esmon, baselines


def _row(e, leak_th, leak_en, cer, wer):
    return {"epoch": e, "dev_lotus_th/lock/leak": leak_th, "dev_ami_en/lock/leak": leak_en,
            "dev_lotus_th/lock/err": cer, "dev_ami_en/lock/err": wer}


def test_old_rule_never_fires_new_rule_does():
    # early unsaved epoch 5 has the best WER, so the v30 rule finds nothing eligible
    rows = [_row(e, 0.1, 0.0, 0.70, 0.62 if e == 5 else 0.70 + 0.001 * e) for e in range(1, 31)]
    for r in rows:
        if r["epoch"] == 12:
            r["dev_lotus_th/lock/leak"] = 0.02
    old = esmon.select(rows, saved=list(range(10, 31)), tol=0.01, patience=3)
    assert old["es3"] == 30 and old["es3_stop"] == 30
    new = esmon.select_fixed(rows, save_from=10, tol=0.03, patience=3)
    assert new["stopped"] and new["pick"] == 12 and new["stop"] == 15


def test_fixed_rule_fallback_mean_error():
    rows = [_row(10, 0.1, 0, 0.60, 0.80), _row(11, 0.05, 0, 0.80, 0.60), _row(12, 0.2, 0, 0.70, 0.70)]
    f = esmon.select_fixed(rows, save_from=10, tol=0.01, patience=5)
    assert f["pick"] in (10, 11, 12) and not f["stopped"]


def test_fusion_rule():
    assert baselines.fuse_says_english(5.0, 0.4)       # confident LID wins over a weak lock
    assert not baselines.fuse_says_english(0.2, 0.05)  # unsure LID, confident Thai lock
    assert baselines._prefix_sec("voxlingua107_p2s") == 2.0
    assert baselines._prefix_sec("voxlingua107") == 0.0
    assert "fuse:x" in baselines.method_names({"x": {}})


def test_resim_end_to_end(tmp_path, capsys):
    import sys
    sys.path.insert(0, os.path.dirname(__file__))
    from test_v30 import _fake_dump, _row as r30
    work = str(tmp_path)
    rng = np.random.default_rng(0)
    exp = os.path.join(work, "exp", "B20_rir_es")
    os.makedirs(exp)
    rows = [r30(e, 0.2 + 0.1 * np.sin(e)) for e in range(1, 51)]
    open(os.path.join(exp, "devmon.jsonl"), "w").write("\n".join(json.dumps(r) for r in rows))
    json.dump({"final": 50, "min-leak": 11}, open(os.path.join(exp, "esmon_picks.json"), "w"))
    for e in (11, 50):
        for s in esmon.TEST:
            _fake_dump(esmon._cand_dump(work, "20", "rir_es", e, 50, s), s, 20, rng, 0.5)
    args = type("A", (), {"work": work, "b_pct": "20", "labels": ["rir_es", "nope_es"], "save_from": 10,
                          "tols": [0.01, 0.02], "patience": [3, 5], "out": str(tmp_path / "o.json")})()
    assert esmon.cmd_resim(args) == 0
    out = capsys.readouterr().out
    assert "available epoch  11" in out and "no devmon" in out
    assert json.load(open(tmp_path / "o.json"))["rir_es"]
