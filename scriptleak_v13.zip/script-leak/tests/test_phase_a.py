import json
import os

import numpy as np
import pytest

from scriptleak import probes, spans
from scriptleak.dumpio import DumpWriter
from scriptleak.languages import get_language
from scriptleak.ngram import CharNgram
from scriptleak.nonspeech import report
from scriptleak.tokenmap import MAJ, MIN, token_groups

TH, EN = get_language("th"), get_language("en")
VOCAB = ["▁กา", "คา", "▁ขา", "▁the", "▁cat", "s", "▁sh", "▁wonge"]
BLANK = len(VOCAB)
GROUPS = token_groups(VOCAB, TH, EN, BLANK)


def frames(seq, conf=0.9):
    """seq: list of token ids (or (id, conf)); returns log-probs [T, V+1]."""
    rows = []
    for item in seq:
        i, c = item if isinstance(item, tuple) else (item, conf)
        p = np.full(BLANK + 1, (1.0 - c) / BLANK)
        p[i] = c
        rows.append(np.log(p))
    return np.asarray(rows, dtype=np.float32)


def test_ngram_prefers_real_text():
    lm = CharNgram(4).fit(["the cat sat on the mat", "the cats sat", "a cat on a mat"] * 5)
    assert lm.score("the cat") > lm.score("sh wonge")
    assert lm.score("") == pytest.approx(-10.0)
    assert lm.score("zzzz") < lm.score("the mat")


def test_find_spans_blank_inside_majority_ends():
    g = GROUPS[np.array([0, BLANK, 3, BLANK, 4, 0, 6, 7])]
    assert spans.find_spans(g) == [(2, 5), (6, 8)]


def test_span_features_and_forced_reading():
    logp = frames([0, (6, 0.5), (7, 0.5), 1])
    st = spans.frame_stats(logp, GROUPS)
    (a, b), = spans.find_spans(st["g"])
    f = spans.span_features(st, a, b)
    assert f["frames"] == 2 and f["conf"] == pytest.approx(0.5, abs=1e-3)
    assert spans.text_of(st["ids"][a:b], VOCAB, BLANK) == "sh wonge"
    forced = spans.forced_ids(logp, GROUPS, a, b)
    assert all(GROUPS[i] != MIN for i in forced)


def test_word_chunks_cover_span():
    logp = frames([3, 4, 5, 3, 4, 3])
    st = spans.frame_stats(logp, GROUPS)
    (a, b), = spans.find_spans(st["g"])
    chunks = spans.word_chunks(st, a, b, VOCAB, BLANK, offset=0)
    assert chunks[0][0] == a and chunks[-1][1] == b
    assert all(x[1] == y[0] for x, y in zip(chunks, chunks[1:]))
    assert len(chunks) >= 2


def test_gated_text_replaces_rejected_span_only():
    logp = frames([0, (6, 0.4), (7, 0.4), 1, 3, 4])
    scorer = spans.Scorer(CharNgram(3).fit(["the cat"]), CharNgram(3).fit(["กา คา"]), {"the", "cat"})
    st, sp = spans.utterance_spans(logp, GROUPS, VOCAB, BLANK, scorer)
    assert [s["text"] for s in sp] == ["sh wonge", "the cat"]
    out = spans.gated_text(logp, GROUPS, VOCAB, BLANK, st, sp, lambda s: s["conf"] > 0.6)
    assert "wonge" not in out and "the cat" in out
    assert spans.gated_text(logp, GROUPS, VOCAB, BLANK, st, sp, lambda s: True).count("wonge") == 1


def test_auc_and_threshold():
    pos, neg = np.array([3.0, 4.0, 5.0]), np.array([1.0, 2.0, 3.0])
    assert spans.auc(pos, neg) == pytest.approx((8 + 0.5) / 9)
    assert spans.auc(neg, pos) == pytest.approx(1 - (8 + 0.5) / 9)
    assert spans.threshold_at(np.arange(100.0), 0.99) == pytest.approx(0.99)


def _dump(path, items, strata=None):
    with DumpWriter(str(path), VOCAB, BLANK) as w:
        for k, (text, lp) in enumerate(items):
            rec = {"text": text}
            if strata:
                rec["stratum"] = strata[k]
            w.add(rec, lp)


def test_spans_cli_end_to_end(tmp_path, capsys):
    rng = np.random.default_rng(0)
    thai, strata = [], []
    for k in range(30):
        leak = k % 3 == 0
        seq = [0, 1] + ([(6, 0.45 + 0.1 * rng.random()), (7, 0.45)] if leak else []) + [2, 0]
        thai.append(("กา คา ขา กา", frames(seq)))
        strata.append("noisy" if leak else "clean")
    eng = [("the cats the cat", frames([3, 4, 5, 3, 4], conf=0.9 + 0.05 * rng.random())) for _ in range(40)]
    _dump(tmp_path / "th", thai, strata)
    _dump(tmp_path / "en", eng)
    for name, texts in (("th.jsonl", ["กา คา ขา กา"] * 20), ("en.jsonl", ["the cat", "the cats the cat"] * 20)):
        with open(tmp_path / name, "w", encoding="utf-8") as f:
            for t in texts:
                f.write(json.dumps({"audio_filepath": "x.wav", "duration": 1.0, "text": t}, ensure_ascii=False) + "\n")
    out = tmp_path / "o.json"
    assert spans.main(["--majority", "th", "--minority", "en", "--leak-dump", str(tmp_path / "th"),
                       "--genuine-dump", str(tmp_path / "en"), "--majority-text", str(tmp_path / "th.jsonl"),
                       "--minority-text", str(tmp_path / "en.jsonl"), "--out", str(out)]) == 0
    res = json.load(open(out, encoding="utf-8"))
    assert res["counts"]["leak_spans"] == 10
    assert res["features"]["conf"]["auc_chunks"] == pytest.approx(1.0)
    assert res["rules"]["conf"]["leak_rejected"] == pytest.approx(1.0)
    d = res["decoding"][str(tmp_path / "th")]
    assert d["greedy"]["ALL"]["slr_u"] > 0 and d["conf"]["ALL"]["slr_u"] == 0
    en = res["decoding"][str(tmp_path / "en")]
    assert en["greedy"]["ALL"]["wer"] == 0 and en["conf"]["ALL"]["wer"] <= 0.1


def test_distortions_keep_length_and_do_what_they_say():
    rng = np.random.default_rng(0)
    sr = 16000
    x = (0.1 * np.sin(2 * np.pi * 440 * np.arange(sr) / sr)).astype(np.float32)
    for name, fn in probes.distortions(sr).items():
        y = fn(x, np.random.default_rng(1))
        assert len(y) == len(x) and y.dtype == np.float32 and np.isfinite(y).all(), name
        assert float(np.max(np.abs(y))) <= 1.0
    assert probes.rms(probes.gain(x, -20.0)) == pytest.approx(probes.rms(x) / 10, rel=1e-3)
    assert float(np.max(np.abs(probes.clip(x)))) == pytest.approx(0.01, rel=1e-3)
    noisy = probes.add_white(x, 0.0, rng)
    assert probes.rms(noisy - x) == pytest.approx(probes.rms(x), rel=0.05)
    low = (0.1 * np.sin(2 * np.pi * 60 * np.arange(sr) / sr)).astype(np.float32)
    assert probes.rms(probes.telephone(low, sr)) < 0.1 * probes.rms(low)


def test_nonspeech_report():
    rows = report([{"stratum": "noise_only", "pred_ctc": "the cat"}, {"stratum": "noise_only", "pred_ctc": ""},
                   {"stratum": "silence", "pred_ctc": "กา"}], TH, EN, "pred_ctc", "stratum")
    assert rows["noise_only"]["any_rate"] == 0.5 and rows["noise_only"]["minority_rate"] == 0.5
    assert rows["silence"]["majority_rate"] == 1.0
