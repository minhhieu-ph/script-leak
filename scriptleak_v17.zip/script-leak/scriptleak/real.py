"""Test sets with real noise: LOTUSDIS (far-field meetings) and GigaSpeech 2 (YouTube).

Every condition in phases A and B was synthetic: MUSAN noise or white noise
mixed into clean read speech. These two public Thai corpora were recorded in
real conditions, so a model that only learned "MUSAN means English" would show
it here.

  # GigaSpeech 2 is gated: accept the terms on its Hugging Face page and log in
  python -m scriptleak.real fetch-gs2 --out-dir $D/gigaspeech2

  # split a raw manifest into Thai-only and Thai+Latin references
  python -m scriptleak.real build --manifest lotus_test.raw.jsonl --name lotus \\
      --stratum-field mic --keep-frac 0.35 --out-thai lotus.th.jsonl \\
      --out-mixed lotus.mixed.jsonl --report lotus.build.json

The Thai-only file is scored for leakage like every other Thai test set. The
mixed file holds utterances whose reference itself has English words in Latin
script (names, loanwords); it is scored with scriptleak.retention, which asks
whether the model keeps those words instead of writing them in Thai.
"""

from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import os
import sys
import tarfile
import unicodedata
from collections import Counter
from typing import Dict, Iterable, List, Optional, Tuple

from .languages import get_language
from .manifest import read_manifest, write_manifest
from .normalize import _APOSTROPHES, _prepare, normalize
from .scripts import LATIN, THAI

GS2_REPO = "speechcolab/gigaspeech2"
GS2_FILES = ("data/th/test.tsv", "data/th/test.tar.gz")
_TH_REJECT = get_language("th").reject_chars


# ------------------------------------------------------------------ references

def mixed_normalize(text: str) -> Tuple[Optional[str], str]:
    """Normalise a reference that may mix Thai and Latin letters.

    Returns (text, kind) with kind "thai", "mixed" or a rejection reason.
    The rules follow scriptleak.normalize: anything whose spoken form is
    ambiguous (digits, symbols, other scripts) rejects the utterance. Latin
    letters are lower-cased; Thai word spaces are kept."""
    text = _prepare(text).lower()
    out: List[str] = []
    n_thai = n_latin = 0
    for ch in text:
        if ch.isspace():
            out.append(" ")
        elif ch in _TH_REJECT:
            return None, _TH_REJECT[ch]
        elif THAI.contains(ch):
            out.append(ch)
            n_thai += 1
        elif "a" <= ch <= "z":
            out.append(ch)
            n_latin += 1
        elif LATIN.contains(ch):
            return None, "accented_latin"
        elif ch in _APOSTROPHES:
            out.append("'")
        else:
            cat = unicodedata.category(ch)
            if cat[0] == "N":
                return None, "digit"
            if cat[0] == "P" and ch not in "%&@#/":
                out.append(" ")
                continue
            if cat[0] in "SL" or ch in "%&@#/":
                return None, "symbol_or_other_script"
            return None, "unknown_char"
    norm = " ".join(w.strip("'") for w in "".join(out).split())
    norm = " ".join(norm.split())
    if not norm:
        return None, "empty"
    if n_latin == 0:
        return norm, "thai"
    if n_thai == 0:
        return None, "latin_only"
    return norm, "mixed"


def _keep(entry: Dict, frac: float, group_fields: List[str]) -> bool:
    """Deterministic sample keyed on group_fields, so the same segment is kept
    for every microphone that recorded it."""
    if frac >= 1.0:
        return True
    key = "\x1f".join(str(entry.get(f, "")) for f in group_fields)
    h = int(hashlib.sha256(key.encode("utf-8")).hexdigest()[:8], 16)
    return h / 0xFFFFFFFF < frac


def build(entries: Iterable[Dict], name: str, stratum_field: Optional[str] = None,
          keep_frac: float = 1.0, group_fields: Optional[List[str]] = None,
          min_dur: float = 0.3, max_dur: float = 30.0,
          text_field: str = "text") -> Tuple[List[Dict], List[Dict], Dict]:
    """(thai_only, mixed, report). Thai-only references are normalised exactly
    like the Porjai test set (strict Thai, word spaces kept)."""
    th = dataclasses.replace(get_language("th"), remove_spaces=False)
    group_fields = group_fields or [text_field]
    thai: List[Dict] = []
    mixed: List[Dict] = []
    reasons: Counter = Counter()
    secs: Counter = Counter()
    n = 0
    for e in entries:
        n += 1
        dur = float(e.get("duration", 0.0))
        if dur < min_dur or dur > max_dur:
            reasons["duration"] += 1
            continue
        if not _keep(e, keep_frac, group_fields):
            reasons["not_sampled"] += 1
            continue
        raw = str(e.get(text_field, ""))
        text, kind = mixed_normalize(raw)
        if kind == "thai":
            res = normalize(raw, th)  # the strict rules, so Thai-only sets match Porjai's
            if not res.ok:
                reasons[res.reasons[0]] += 1
                continue
            text = res.text
        elif kind != "mixed":
            reasons[kind] += 1
            continue
        stratum = f"{name}/{e.get(stratum_field)}" if stratum_field else name
        out = dict(e)
        out.update({text_field: text, "text_raw": raw, "lang": "th", "stratum": stratum,
                    "text_key": text.replace(" ", "")})
        (thai if kind == "thai" else mixed).append(out)
        secs[kind] += dur
    per_stratum: Dict[str, Dict[str, int]] = {}
    for kind, rows in (("thai", thai), ("mixed", mixed)):
        for r in rows:
            per_stratum.setdefault(r["stratum"], {"thai": 0, "mixed": 0})[kind] += 1
    report = {
        "name": name, "utterances_in": n,
        "thai_only": len(thai), "thai_only_hours": round(secs["thai"] / 3600.0, 2),
        "mixed": len(mixed), "mixed_hours": round(secs["mixed"] / 3600.0, 2),
        "dropped": dict(reasons.most_common()),
        "per_stratum": dict(sorted(per_stratum.items())),
    }
    return thai, mixed, report


def format_build(report: Dict) -> str:
    lines = [f"{report['name']}: {report['utterances_in']} utterances in",
             f"  Thai-only references : {report['thai_only']:>7} ({report['thai_only_hours']} h)",
             f"  Thai + Latin words   : {report['mixed']:>7} ({report['mixed_hours']} h)",
             "  dropped: " + (", ".join(f"{k} {v}" for k, v in report["dropped"].items()) or "none")]
    if len(report["per_stratum"]) > 1:
        lines.append("  per stratum (thai-only / mixed):")
        for s, c in report["per_stratum"].items():
            lines.append(f"    {s:<28} {c['thai']:>6} / {c['mixed']:>5}")
    return "\n".join(lines)


def split_by_stratum(entries: List[Dict], out_dir: str) -> List[str]:
    """One manifest per stratum (for noisefloor). Returns NAME=PATH items."""
    os.makedirs(out_dir, exist_ok=True)
    groups: Dict[str, List[Dict]] = {}
    for e in entries:
        groups.setdefault(e["stratum"], []).append(e)
    items = []
    for s, rows in sorted(groups.items()):
        path = os.path.join(out_dir, s.replace("/", "_") + ".jsonl")
        write_manifest(path, rows)
        items.append(f"{s}={path}")
    return items


# ------------------------------------------------------------------ GigaSpeech 2

def safe_extract(tar_path: str, dest: str) -> int:
    """Extract regular files only, refusing paths that leave dest."""
    dest_abs = os.path.realpath(dest)
    n = 0
    with tarfile.open(tar_path, "r:*") as tf:
        for m in tf:
            if not m.isfile():
                continue
            target = os.path.realpath(os.path.join(dest_abs, m.name))
            if not target.startswith(dest_abs + os.sep):
                raise ValueError(f"unsafe path in archive: {m.name}")
            os.makedirs(os.path.dirname(target), exist_ok=True)
            src = tf.extractfile(m)
            if src is None:
                continue
            with open(target + ".tmp", "wb") as f:
                while True:
                    buf = src.read(1 << 20)
                    if not buf:
                        break
                    f.write(buf)
            os.replace(target + ".tmp", target)
            n += 1
    return n


def fetch_gs2(out_dir: str) -> Tuple[str, str]:
    """Download and extract the GigaSpeech 2 Thai test set. Returns (tsv,
    audio_dir). Skips whatever is already there."""
    audio_dir = os.path.join(out_dir, "data", "th", "test")
    tsv = os.path.join(out_dir, "data", "th", "test.tsv")
    done = os.path.join(audio_dir, ".extracted")
    if os.path.exists(done) and os.path.exists(tsv):
        print(f"GigaSpeech 2 test already in {audio_dir}")
        return tsv, audio_dir
    try:
        from huggingface_hub import hf_hub_download
    except ImportError as e:
        raise SystemExit("huggingface_hub is missing (it comes with `datasets`)") from e
    paths = {}
    for f in GS2_FILES:
        try:
            paths[f] = hf_hub_download(GS2_REPO, f, repo_type="dataset", local_dir=out_dir)
        except Exception as e:  # noqa: BLE001
            msg = str(e).splitlines()[0] if str(e) else type(e).__name__
            raise SystemExit(
                f"Could not download {f} from {GS2_REPO}: {msg}\n"
                "GigaSpeech 2 is gated. Open https://huggingface.co/datasets/speechcolab/gigaspeech2,\n"
                "accept the terms with your account, then run `huggingface-cli login` (or set HF_TOKEN)\n"
                "on this machine and start this step again.") from e
    os.makedirs(audio_dir, exist_ok=True)
    n = safe_extract(paths["data/th/test.tar.gz"], audio_dir)
    open(done, "w").close()
    print(f"Extracted {n} files to {audio_dir}")
    return paths["data/th/test.tsv"], audio_dir


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("fetch-gs2", help="download + extract the GigaSpeech 2 Thai test set")
    a.add_argument("--out-dir", required=True)

    a = sub.add_parser("build", help="raw manifest -> Thai-only and Thai+Latin manifests")
    a.add_argument("--manifest", required=True)
    a.add_argument("--name", required=True, help="prefix of the stratum, e.g. lotus")
    a.add_argument("--stratum-field", help="field appended to the stratum, e.g. mic")
    a.add_argument("--keep-frac", type=float, default=1.0,
                   help="keep this share of segments (same segments for every stratum)")
    a.add_argument("--group-fields", nargs="*", default=["speaker_id", "text"],
                   help="fields that identify one segment across microphones")
    a.add_argument("--min-dur", type=float, default=0.3)
    a.add_argument("--max-dur", type=float, default=30.0)
    a.add_argument("--out-thai", required=True)
    a.add_argument("--out-mixed", required=True)
    a.add_argument("--report")
    a.add_argument("--strata-dir", help="also write one Thai-only manifest per stratum here")

    args = p.parse_args(argv)
    if args.cmd == "fetch-gs2":
        tsv, audio_dir = fetch_gs2(args.out_dir)
        print(f"tsv: {tsv}\naudio: {audio_dir}")
        return 0
    thai, mixed, report = build(read_manifest(args.manifest), args.name, args.stratum_field,
                                args.keep_frac, args.group_fields, args.min_dur, args.max_dur)
    write_manifest(args.out_thai, thai)
    write_manifest(args.out_mixed, mixed)
    print(format_build(report))
    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
    if args.strata_dir:
        split_by_stratum(thai, args.strata_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
