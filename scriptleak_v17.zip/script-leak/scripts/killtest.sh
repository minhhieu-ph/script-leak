#!/usr/bin/env bash
# The two-week kill test, one stage at a time.
#
#   bash scripts/killtest.sh STAGE
#
# Stages, in order:
#   prepare    corpora -> raw manifests            (needs TEXT_COL)
#   audit      spoken-form filter; STOP and read the Thai hours
#   split      Thai train/dev/test, noisy strata, dialect test sets
#   mix        training manifests (English = 5% and 20% of hours)
#   tokenizer  one SentencePiece model per language
#   train05    train with 5% English                (needs BASE_CONFIG)
#   train20    train with 20% English
#   dump       frame-level log-probabilities for both models
#   results    leakage tables, frame analysis, method sweep
#   probeA     phase A: distortion probes and the span acceptance test
#              (uses the two trained models, no training)
#   noisefloor | prepB | trainB NAME | evalB NAME... | nightB [NAME...]   phase B, see below
#   realprep   real-noise Thai test sets (LOTUSDIS, GigaSpeech 2): download + manifests, CPU only
#   realB      score every trained model of B_PCT on them, one model per GPU
#
# Settings are environment variables, e.g.
#   D=/data/scriptleak TEXT_COL=sentence bash scripts/killtest.sh prepare
# prepare also reads TEXT_COL_CENTRAL, CENTRAL_MAX_HOURS (450, 0 = all),
# PREP_WORKERS (16). It can be re-run after an interruption.
# audit reads TH_KEEP_SPACES (1 = keep Thai word spaces, 0 = remove them).
#
# NOT TESTED where it was written (no data, no GPU there).
set -euo pipefail

D="${D:-/data/scriptleak}"            # where download_data.sh put the corpora
W="${W:-$D/work}"                     # manifests, tokenizers, models, dumps
TEXT_COL="${TEXT_COL:-}"              # transcript column of the Thai datasets
SPEAKER_COL="${SPEAKER_COL:-}"        # speaker column, if the datasets have one
BASE_CONFIG="${BASE_CONFIG:-}"        # a NeMo FastConformer hybrid transducer-CTC BPE yaml
INIT="${INIT:-stt_en_fastconformer_hybrid_large_streaming_multi}"   # INIT=none trains from scratch
GPUS="${GPUS:-8}"
BATCH="${BATCH:-32}"                  # per GPU
EPOCHS="${EPOCHS:-10}"
TH_HOURS="${TH_HOURS:-300}"
DIALECT_TEST_HOURS="${DIALECT_TEST_HOURS:-5}"
DIALECTS="khummuang korat pattani"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"
mkdir -p "$W"
need() { [ -n "${!1}" ] || { echo "Set $1 first. $2"; exit 1; }; }

stage_prepare() {
  need TEXT_COL "Find it with: python -m scriptleak.prepare hf-columns --dataset CMKL/Porjai-Thai-voice-dataset-korat"
  for part in train-clean-100:en_train dev-clean:en_dev test-clean:en_test; do
    python -m scriptleak.prepare librispeech --root "$D/LibriSpeech" \
        --subsets "${part%%:*}" --out "$W/${part##*:}.raw.jsonl"
  done
  local copy=()
  [ -n "$SPEAKER_COL" ] && copy=(--copy-cols "$SPEAKER_COL")
  # The central set may name its transcript column differently from the
  # dialect sets: TEXT_COL_CENTRAL overrides TEXT_COL for it. CENTRAL_MAX_HOURS
  # (default 450) keeps disk use down; the experiments need about 315 clean hours.
  for name in central $DIALECTS; do
    local col="$TEXT_COL" cap=()
    if [ "$name" = central ]; then
      col="${TEXT_COL_CENTRAL:-$TEXT_COL}"
      [ "${CENTRAL_MAX_HOURS:-450}" != 0 ] && cap=(--max-hours "${CENTRAL_MAX_HOURS:-450}")
    fi
    python -m scriptleak.prepare hf --dataset "CMKL/Porjai-Thai-voice-dataset-$name" \
        --split train --text-col "$col" "${copy[@]}" "${cap[@]}" \
        --num-workers "${PREP_WORKERS:-16}" \
        --audio-out "$D/porjai/$name/wav" --out "$W/th_$name.raw.jsonl"
  done
}

stage_audit() {
  local sp=()
  [ "${TH_KEEP_SPACES:-1}" = 1 ] && sp=(--keep-spaces)
  python -m scriptleak.audit --manifest "$W/th_central.raw.jsonl" --lang th "${sp[@]}" \
      --out-manifest "$W/th_central.clean.jsonl" --report "$W/th_central.audit.json"
  for s in en_train en_dev en_test; do
    python -m scriptleak.audit --manifest "$W/$s.raw.jsonl" --lang en \
        --out-manifest "$W/$s.clean.jsonl" --report "$W/$s.audit.json"
  done
  for name in $DIALECTS; do
    python -m scriptleak.audit --manifest "$W/th_$name.raw.jsonl" --lang th "${sp[@]}" \
        --out-manifest "$W/th_$name.clean.jsonl" --report "$W/th_$name.audit.json" \
        --set "stratum=$name"
  done
  echo
  echo "STOP: Thai-central needs at least $((TH_HOURS + 15)) clean hours (see above)."
}

stage_split() {
  # Split by sentence (text_key) unless a speaker column is given: the corpus
  # has each sentence read by several people, and a test sentence must not
  # also be a training sentence.
  local spk=(--speaker-field "${SPEAKER_COL:-text_key}")
  python -m scriptleak.split --manifest "$W/th_central.clean.jsonl" \
      --dev-hours 3 --test-hours 10 "${spk[@]}" --out-prefix "$W/th_central"
  python -m scriptleak.noise --manifest "$W/th_central.test.jsonl" --noise-dir "$D/musan/noise" \
      --snrs 10 5 0 --out-dir "$D/th_test_noisy" --out-manifest "$W/th_test.strata.jsonl"
  for name in $DIALECTS; do
    python -m scriptleak.split --manifest "$W/th_$name.clean.jsonl" \
        --dev-hours 0 --test-hours "$DIALECT_TEST_HOURS" "${spk[@]}" --out-prefix "$W/th_$name"
    cat "$W/th_$name.test.jsonl" >> "$W/th_test.strata.jsonl"
  done
  echo "Thai test set with strata: $W/th_test.strata.jsonl"
}

stage_mix() {
  for pct in 05 20; do
    python -m scriptleak.mix --majority "$W/th_central.train.jsonl" --minority "$W/en_train.clean.jsonl" \
        --majority-hours "$TH_HOURS" --minority-fraction "0.$pct" --seed 0 \
        --out "$W/train_th${TH_HOURS}_en$pct.jsonl"
  done
}

stage_tokenizer() {
  python -m scriptleak.nemo_tools.build_tokenizer --manifest "$W/th_central.train.jsonl" \
      --out-dir "$W/tokenizers/th_bpe1024" --vocab-size 1024
  python -m scriptleak.nemo_tools.build_tokenizer --manifest "$W/en_train.clean.jsonl" \
      --out-dir "$W/tokenizers/en_bpe256" --vocab-size 256
}

train_one() {  # train_one PCT
  need BASE_CONFIG "Pick one of the yaml files printed by scripts/setup_env.sh (step 4)."
  local init=()
  [ "$INIT" != "none" ] && init=(--init-pretrained "$INIT")
  python -m scriptleak.nemo_tools.train --base-config "$BASE_CONFIG" \
      --train-manifest "$W/train_th${TH_HOURS}_en$1.jsonl" \
      --val-manifest "$W/th_central.dev.jsonl" "$W/en_dev.clean.jsonl" \
      --tokenizer "th=$W/tokenizers/th_bpe1024" "en=$W/tokenizers/en_bpe256" \
      "${init[@]}" --exp-dir "$W/exp/th${TH_HOURS}_en$1" \
      --max-epochs "$EPOCHS" --batch-size "$BATCH" --num-workers 8 --devices "$GPUS"
}

stage_dump() {
  for pct in 05 20; do
    local m="$W/exp/th${TH_HOURS}_en$pct"
    CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs --model "$m/final.nemo" \
        --manifest "$W/th_test.strata.jsonl" --out "$W/dumps/en$pct/th_test" --transducer
    CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs --model "$m/final.nemo" \
        --manifest "$W/en_test.clean.jsonl" --out "$W/dumps/en$pct/en_test" --transducer
  done
}

stage_results() {
  for pct in 05 20; do
    local dd="$W/dumps/en$pct" r="$W/results/en$pct"
    mkdir -p "$r"
    echo "################ English = $pct% of training hours ################"
    echo "--- 1. Is there leakage, and does it grow with difficulty? (CTC head)"
    python -m scriptleak.sweep --dump "$dd/th_test" --majority th --minority en --spoken th \
        --group-by stratum --methods greedy --out "$r/leak_ctc.json" || echo "!! this step failed; continuing"
    echo "--- 2. Same question for the transducer head"
    python -m scriptleak.evaluate --manifest "$dd/th_test/utts.jsonl" --majority th --minority en \
        --hyp-field pred_transducer --group-by stratum --out "$r/leak_transducer.json" || echo "!! this step failed; continuing"
    echo "--- 3. Why: frame analysis"
    python -m scriptleak.analysis --dump "$dd/th_test" --majority th --minority en \
        --group-by stratum --out "$r/frames.json" || echo "!! this step failed; continuing"
    echo "--- 4. Methods on Thai speech"
    python -m scriptleak.sweep --dump "$dd/th_test" --majority th --minority en --spoken th \
        --out "$r/sweep_th.json" || echo "!! this step failed; continuing"
    echo "--- 5. What each method costs English"
    python -m scriptleak.sweep --dump "$dd/en_test" --majority th --minority en --spoken en \
        --out "$r/sweep_en.json" || echo "!! this step failed; continuing"
  done 2>&1 | tee "$W/results_summary.txt"
  echo "Summary saved to $W/results_summary.txt"
}

stage_probeA() {
  # Phase A: probes on the two trained models, no training.
  #   PROBE_UTTS (2000) clean Thai test utterances are distorted in 8 ways.
  local P="$W/probeA"
  mkdir -p "$P"
  if [ ! -s "$P/th_probes.jsonl" ] || [ ! -s "$P/nonspeech.jsonl" ]; then
    python -m scriptleak.probes --manifest "$W/th_central.test.jsonl" --noise-dir "$D/musan/noise" \
        --out-dir "$D/probeA_audio" --out-manifest "$P/th_probes.jsonl" \
        --out-nonspeech "$P/nonspeech.jsonl" --max-utts "${PROBE_UTTS:-2000}"
  fi
  if [ ! -s "$P/en_strata.jsonl" ]; then
    python -m scriptleak.noise --manifest "$W/en_test.clean.jsonl" --noise-dir "$D/musan/noise" \
        --snrs 10 5 0 --out-dir "$D/en_test_noisy" --out-manifest "$P/en_strata.jsonl"
  fi
  for pct in 05 20; do
    for set in th_probes nonspeech en_strata; do
      local out="$W/dumps/en$pct/$set"
      if [ ! -s "$out/meta.json" ] || [ ! -s "$out/utts.jsonl" ]; then
        CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs \
            --model "$W/exp/th${TH_HOURS}_en$pct/final.nemo" --manifest "$P/$set.jsonl" --out "$out"
      fi
    done
  done
  for pct in 05 20; do
    local dd="$W/dumps/en$pct" r="$W/results/en$pct"
    mkdir -p "$r"
    echo "################ English = $pct% of training hours ################"
    echo "--- A1. Which distortions make Thai speech leak? (CTC head)"
    python -m scriptleak.sweep --dump "$dd/th_probes" --majority th --minority en --spoken th \
        --group-by stratum --methods greedy --out "$r/probes_th.json" || echo "!! this step failed; continuing"
    echo "--- A2. No speech at all: what does the model write?"
    python -m scriptleak.nonspeech --manifest "$dd/nonspeech/utts.jsonl" --majority th --minority en \
        --out "$r/nonspeech.json" || echo "!! this step failed; continuing"
    echo "--- A3. Noisy English: is the error symmetric?"
    python -m scriptleak.sweep --dump "$dd/en_strata" --majority th --minority en --spoken en \
        --group-by stratum --methods greedy --out "$r/probes_en.json" || echo "!! this step failed; continuing"
    echo "--- A4. Can leaked spans be told from real English spans?"
    python -m scriptleak.spans --majority th --minority en \
        --leak-dump "$dd/th_test" "$dd/th_probes" --genuine-dump "$dd/en_strata" \
        --majority-text "$W/th_central.train.jsonl" --minority-text "$W/en_train.clean.jsonl" \
        --out "$r/spans.json" || echo "!! this step failed; continuing"
  done 2>&1 | tee "$W/probeA_summary.txt"
  echo "Summary saved to $W/probeA_summary.txt"
}

# ---------------------------------------------------------------- phase B
# Causal experiments. All start from the mix with B_PCT% English (default 20).
#   noisefloor          acoustic condition of each training block (minutes, CPU)
#   prepB               noisy training copies + held-out test manifests
#   trainB KIND         KIND = both | en | th   noise on both / English / Thai blocks
#                              clean            no noise (a replicate of the clean model)
#                              noinit           no noise, encoder not initialised
#   evalB KIND [KIND..] dump + tables; KIND as above, or base (the clean model of phase A)
#   nightB [KIND..]     prepB, trainB for each KIND, evalB base + KINDs
# Settings that change a model's name (so runs never overwrite each other):
#   B_PCT     English share of training hours                 20  -> B20_...
#   AUG_PROB  share of utterances of a noisy block given noise 0.5 -> (nothing); 0.1 -> p10_
#   SEED      training seed                                   0   -> (nothing); 1 -> _s1
# e.g. B_PCT=20 AUG_PROB=0.1 SEED=1, KIND th  ->  exp/B20_p10_th_s1
B_PCT="${B_PCT:-20}"
AUG_PROB="${AUG_PROB:-0.5}"
SEED="${SEED:-0}"
B_EPOCHS="${B_EPOCHS:-50}"
SAVE_EVERY="${SAVE_EVERY:-10}"
PTAG="$(python -c "p=float('$AUG_PROB'); print('' if abs(p-0.5)<1e-9 else 'p%02d' % round(p*100))")"
AT="B${B_PCT}${PTAG:+_$PTAG}"           # names of the augmented training manifests

_label() {  # KIND -> label used in exp/, dumps/, results/ (after "B<pct>_")
  local kind="$1" sfx=""
  [ "$SEED" != 0 ] && sfx="_s$SEED"
  case "$kind" in
    base)         echo "base" ;;
    both|en|th)   echo "${PTAG:+${PTAG}_}$kind$sfx" ;;
    clean|noinit) echo "$kind$sfx" ;;
    *) echo "unknown kind '$kind' (use base|clean|noinit|both|en|th)" >&2; return 1 ;;
  esac
}

_model_dir() {  # KIND -> directory holding final.nemo
  if [ "$1" = base ]; then echo "$W/exp/th${TH_HOURS}_en${B_PCT}"; else echo "$W/exp/B${B_PCT}_$(_label "$1")"; fi
}

stage_noisefloor() {
  python -m scriptleak.noisefloor --manifest "th=$W/th_central.train.jsonl" "en=$W/en_train.clean.jsonl"
}

stage_prepB() {
  local base="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl"
  # The noisy audio of a lower AUG_PROB is a subset of that of a higher one (same
  # draws per utterance), so every AUG_PROB shares one audio directory.
  python -m scriptleak.augment make --manifest "$base" --noise-dir "$D/musan/noise" \
      --out-dir "$D/aug/en${B_PCT}" --out "$W/${AT}.aug.jsonl" \
      --prob "$AUG_PROB" --snr-min "${AUG_SNR_MIN:-0}" --snr-max "${AUG_SNR_MAX:-20}" \
      --num-workers "${PREP_WORKERS:-16}"
  python -m scriptleak.augment select --manifest "$W/${AT}.aug.jsonl" --langs th en --out "$W/${AT}_aug-both.jsonl"
  python -m scriptleak.augment select --manifest "$W/${AT}.aug.jsonl" --langs en    --out "$W/${AT}_aug-en.jsonl"
  python -m scriptleak.augment select --manifest "$W/${AT}.aug.jsonl" --langs th    --out "$W/${AT}_aug-th.jsonl"
  python -m scriptleak.augment filter-heldout --manifest "$W/th_test.strata.jsonl" --out "$W/th_test.heldout.jsonl"
  # the curve set: clean + held-out noise only, no dialects (small, so every snapshot can be scored)
  python - "$W/th_test.heldout.jsonl" "$W/th_curve.jsonl" <<'PY'
import json, sys
keep = [l for l in open(sys.argv[1], encoding="utf-8")
        if l.strip() and (json.loads(l).get("stratum") == "clean" or str(json.loads(l).get("stratum", "")).startswith("snr"))]
open(sys.argv[2], "w", encoding="utf-8").writelines(keep)
print(f"curve set: {len(keep)} utterances")
PY
  if [ -s "$W/probeA/en_strata.jsonl" ]; then
    python -m scriptleak.augment filter-heldout --manifest "$W/probeA/en_strata.jsonl" --out "$W/en_test.heldout.jsonl"
  else
    echo "NOTE: run 'probeA' first to get the noisy English test set"
  fi
}

stage_trainB() {  # stage_trainB KIND
  need BASE_CONFIG "Pick one of the yaml files printed by scripts/setup_env.sh (step 4)."
  local kind="${1:-}" manifest init=() label m
  [ "$INIT" != "none" ] && init=(--init-pretrained "$INIT")
  case "$kind" in
    both|en|th) manifest="$W/${AT}_aug-$kind.jsonl" ;;
    clean)      manifest="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl" ;;
    noinit)     manifest="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl"; init=() ;;
    *) echo "usage: killtest.sh trainB both|en|th|clean|noinit"; exit 1 ;;
  esac
  [ -s "$manifest" ] || { echo "missing $manifest: run 'prepB' first"; exit 1; }
  label="$(_label "$kind")"; m="$(_model_dir "$kind")"
  if [ -s "$m/final.nemo" ]; then
    echo "$m/final.nemo exists: training of B${B_PCT}_$label skipped"; return 0
  fi
  echo "training B${B_PCT}_$label from $(basename "$manifest") (seed $SEED)"
  python -m scriptleak.nemo_tools.train --base-config "$BASE_CONFIG" \
      --train-manifest "$manifest" \
      --val-manifest "$W/th_central.dev.jsonl" "$W/en_dev.clean.jsonl" \
      --tokenizer "th=$W/tokenizers/th_bpe1024" "en=$W/tokenizers/en_bpe256" \
      ${init[@]+"${init[@]}"} --exp-dir "$m" --save-every-epochs "$SAVE_EVERY" --seed "$SEED" \
      --max-epochs "$B_EPOCHS" --batch-size "$BATCH" --num-workers 8 --devices "$GPUS"
}

_dump_if_missing() {  # MODEL MANIFEST OUT
  if [ ! -s "$3/meta.json" ] || [ ! -s "$3/utts.jsonl" ]; then
    CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs --model "$1" --manifest "$2" --out "$3"
  fi
}

_compare_all() {  # FILE_NAME [extra compare args]: one row per evaluated model of this B_PCT
  local fname="$1"; shift
  local all=() f n
  for f in "$W"/results/B${B_PCT}_*/"$fname"; do
    [ -e "$f" ] || continue
    n="$(basename "$(dirname "$f")")"; all+=("${n#B${B_PCT}_}=$f")
  done
  [ ${#all[@]} -gt 0 ] && python -m scriptleak.compare "$@" "${all[@]}" || true
}

stage_evalB() {  # stage_evalB KIND [KIND ...]
  [ $# -ge 1 ] || { echo "usage: killtest.sh evalB base|clean|noinit|both|en|th [...]"; exit 1; }
  local kind label m dd r labels=()
  for kind in "$@"; do
    label="$(_label "$kind")" || continue
    m="$(_model_dir "$kind")"
    [ -s "$m/final.nemo" ] || { echo "!! $m/final.nemo not found; skipping $label"; continue; }
    labels+=("$label")
    dd="$W/dumps/B${B_PCT}_$label"; r="$W/results/B${B_PCT}_$label"; mkdir -p "$r"
    _dump_if_missing "$m/final.nemo" "$W/th_test.heldout.jsonl" "$dd/heldout"
    python -m scriptleak.sweep --dump "$dd/heldout" --majority th --minority en --spoken th \
        --group-by stratum --methods greedy --out "$r/heldout.json" > /dev/null || echo "!! heldout failed for $label"
    if [ -s "$W/probeA/th_probes.jsonl" ]; then
      _dump_if_missing "$m/final.nemo" "$W/probeA/th_probes.jsonl" "$dd/probes"
      python -m scriptleak.sweep --dump "$dd/probes" --majority th --minority en --spoken th \
          --group-by stratum --methods greedy --out "$r/probes.json" > /dev/null || echo "!! probes failed for $label"
    fi
    if [ -s "$W/en_test.heldout.jsonl" ]; then
      _dump_if_missing "$m/final.nemo" "$W/en_test.heldout.jsonl" "$dd/en"
      python -m scriptleak.sweep --dump "$dd/en" --majority th --minority en --spoken en \
          --group-by stratum --methods greedy --out "$r/en.json" > /dev/null || echo "!! en failed for $label"
    fi
    local snap ep
    for snap in "$m"/epoch*.nemo; do
      [ -e "$snap" ] || continue
      ep="$(basename "$snap" .nemo)"
      _dump_if_missing "$snap" "$W/th_curve.jsonl" "$dd/curve_$ep"
      python -m scriptleak.sweep --dump "$dd/curve_$ep" --majority th --minority en --spoken th \
          --group-by stratum --methods greedy --out "$r/curve_$ep.json" > /dev/null || echo "!! curve $ep failed"
    done
  done
  {
    echo "################ Phase B, English = ${B_PCT}% of hours: Thai test, held-out noise (leak rate / CER) ################"
    _compare_all heldout.json
    echo; echo "################ Distortions never used in training (leak rate / CER) ################"
    _compare_all probes.json
    echo; echo "################ English test (Thai-script rate / WER) ################"
    _compare_all en.json --error wer
    local all f l
    for l in ${labels[@]+"${labels[@]}"}; do
      all=(); for f in "$W/results/B${B_PCT}_$l"/curve_epoch*.json; do [ -e "$f" ] && all+=("$(basename "$f" .json | sed 's/curve_//')=$f"); done
      [ -e "$W/results/B${B_PCT}_$l/heldout.json" ] && [ ${#all[@]} -gt 0 ] && all+=("final=$W/results/B${B_PCT}_$l/heldout.json")
      if [ ${#all[@]} -gt 0 ]; then
        echo; echo "################ $l: leakage during training (leak rate / CER) ################"
        python -m scriptleak.compare "${all[@]}"
      fi
    done
  } 2>&1 | tee "$W/phaseB_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/phaseB_en${B_PCT}_summary.txt"
}

stage_nightB() {  # prepB, then train every KIND given (default: both noinit), then evalB base + KINDs
  local kinds=("$@")
  [ ${#kinds[@]} -gt 0 ] || kinds=(both noinit)
  echo "== nightB, English = ${B_PCT}%, AUG_PROB = ${AUG_PROB}, seed = ${SEED}: ${kinds[*]}  ($(date))"
  stage_prepB
  local k
  for k in "${kinds[@]}"; do
    echo "== training B${B_PCT}_$(_label "$k")  ($(date))"
    ( stage_trainB "$k" ) 2>&1 | tee "$W/train_B${B_PCT}_$(_label "$k").log" || echo "!! training $k failed; continuing"
  done
  echo "== evaluation  ($(date))"
  stage_evalB base "${kinds[@]}"
  echo "== nightB done  ($(date))"
}

# ---------------------------------------------------------------- real noise (v17)
# Phase B used MUSAN noise in training and test. These sets were recorded in
# real conditions. realprep needs no GPU and can run while a model trains;
# realB needs the GPUs and refuses to start while another job is using them.
#   LOTUS_FRAC   share of LOTUSDIS test segments kept (same segments for all 9 mics)  0.35
#   REAL_MODELS  labels to score, e.g. "base both p10_th"   (default: every model of B_PCT)
#   REAL_SKIP    regex of labels to leave out                (default: noinit)
#   REAL_GPUS    GPUs used by realB                          (default: GPUS)
#   REAL_BATCH   utterances per batch when dumping           (default: 16)
R="$W/real"

stage_realprep() {
  mkdir -p "$R"
  local lotus_raw="$R/lotus_test.raw.jsonl" gs2_raw="$R/gs2_test.raw.jsonl"
  echo "== LOTUSDIS test split (about 1.6 GB from Hugging Face)  ($(date))"
  if [ ! -s "$lotus_raw" ]; then
    python -m scriptleak.prepare hf --dataset nectec/LOTUSDIS --split test --data-files "data/test-*" \
        --text-col sentence --copy-cols speaker_id mic --num-workers "${PREP_WORKERS:-8}" \
        --audio-out "$D/lotusdis/test/wav" --out "$lotus_raw" || echo "!! LOTUSDIS failed; continuing"
  fi
  if [ -s "$lotus_raw" ]; then
    python -m scriptleak.real build --manifest "$lotus_raw" --name lotus --stratum-field mic \
        --keep-frac "${LOTUS_FRAC:-0.35}" --out-thai "$R/lotus.th.jsonl" --out-mixed "$R/lotus.mixed.jsonl" \
        --report "$R/lotus.build.json" --strata-dir "$R/strata"
  fi
  echo "== GigaSpeech 2 Thai test (gated)  ($(date))"
  if [ ! -s "$gs2_raw" ]; then
    if python -m scriptleak.real fetch-gs2 --out-dir "$D/gigaspeech2"; then
      python -m scriptleak.prepare gigaspeech2 --tsv "$D/gigaspeech2/data/th/test.tsv" \
          --audio-dir "$D/gigaspeech2/data/th/test" --out "$gs2_raw" || echo "!! GigaSpeech 2 manifest failed"
    else
      echo "!! GigaSpeech 2 skipped (see the message above). LOTUSDIS alone is enough to start."
    fi
  fi
  if [ -s "$gs2_raw" ]; then
    python -m scriptleak.real build --manifest "$gs2_raw" --name gs2 --group-fields utt_id \
        --out-thai "$R/gs2.th.jsonl" --out-mixed "$R/gs2.mixed.jsonl" \
        --report "$R/gs2.build.json" --strata-dir "$R/strata"
  fi
  echo "== Acoustic condition: training blocks vs real test sets  ($(date))"
  local items=("th_train=$W/th_central.train.jsonl" "en_train=$W/en_train.clean.jsonl") f
  for f in "$R"/strata/*.jsonl; do [ -e "$f" ] && items+=("$(basename "$f" .jsonl)=$f"); done
  python -m scriptleak.noisefloor --manifest "${items[@]}" --sample 500 || echo "!! noisefloor failed"
  echo "== realprep done  ($(date))"
}

_real_models() {  # prints "label<TAB>model" for every model to score
  local m l
  if [ -n "${REAL_MODELS:-}" ]; then
    for l in $REAL_MODELS; do
      if [ "$l" = base ]; then m="$W/exp/th${TH_HOURS}_en${B_PCT}/final.nemo"; else m="$W/exp/B${B_PCT}_$l/final.nemo"; fi
      if [ -s "$m" ]; then printf '%s\t%s\n' "$l" "$m"; else echo "!! $m not found; skipping $l" >&2; fi
    done
    return 0
  fi
  m="$W/exp/th${TH_HOURS}_en${B_PCT}/final.nemo"
  [ -s "$m" ] && printf 'base\t%s\n' "$m"
  for m in "$W"/exp/B${B_PCT}_*/final.nemo; do
    [ -e "$m" ] || continue
    l="$(basename "$(dirname "$m")")"; l="${l#B${B_PCT}_}"
    [[ "$l" =~ ${REAL_SKIP:-noinit} ]] && continue
    printf '%s\t%s\n' "$l" "$m"
  done
}

_real_sets() {  # sets that realprep produced, as NAME=MANIFEST
  local s
  for s in lotus.th lotus.mixed gs2.th gs2.mixed; do
    [ -s "$R/$s.jsonl" ] && echo "${s/./_}=$R/$s.jsonl"
  done
}

stage_realB() {
  local busy
  busy="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader 2>/dev/null | grep -c . || true)"
  if [ "${busy:-0}" -gt 0 ] && [ "${REAL_FORCE:-0}" != 1 ]; then
    echo "!! $busy process(es) are using the GPUs (training still running?). Start realB when they finish,"
    echo "   or set REAL_FORCE=1 if you are sure."
    exit 1
  fi
  local labels=() models=() line sets=()
  while IFS=$'\t' read -r l m; do labels+=("$l"); models+=("$m"); done < <(_real_models)
  while read -r line; do sets+=("$line"); done < <(_real_sets)
  [ ${#labels[@]} -gt 0 ] || { echo "no trained model of B_PCT=$B_PCT found"; exit 1; }
  [ ${#sets[@]} -gt 0 ] || { echo "no real test set found; run realprep first"; exit 1; }
  local ngpu="${REAL_GPUS:-$GPUS}" g i logs="$W/logs"
  mkdir -p "$logs"
  echo "== realB, English = ${B_PCT}%: ${labels[*]}"
  echo "   test sets: ${sets[*]}"
  echo "   ${#labels[@]} models on $ngpu GPUs; one log per model in $logs/realB_B${B_PCT}_<model>.log  ($(date))"
  for ((g = 0; g < ngpu; g++)); do
    (
      for ((i = g; i < ${#labels[@]}; i += ngpu)); do
        local dd="$W/dumps/B${B_PCT}_${labels[$i]}" item
        for item in "${sets[@]}"; do
          local sn="${item%%=*}" man="${item#*=}"
          if [ ! -s "$dd/real_$sn/meta.json" ] || [ ! -s "$dd/real_$sn/utts.jsonl" ]; then
            CUDA_VISIBLE_DEVICES=$g python -m scriptleak.nemo_tools.dump_logprobs --model "${models[$i]}" \
                --manifest "$man" --out "$dd/real_$sn" --transducer --batch-size "${REAL_BATCH:-16}" \
                >> "$logs/realB_B${B_PCT}_${labels[$i]}.log" 2>&1 \
              || echo "!! dump ${labels[$i]} / $sn failed (see its log)"
          fi
        done
        echo "   done: ${labels[$i]}  ($(date +%H:%M))"
      done
    ) &
  done
  wait
  echo "== scoring  ($(date))"
  for ((i = 0; i < ${#labels[@]}; i++)); do
    local dd="$W/dumps/B${B_PCT}_${labels[$i]}" r="$W/results/B${B_PCT}_${labels[$i]}" sn
    mkdir -p "$r"
    for sn in lotus_th gs2_th; do
      [ -s "$dd/real_$sn/utts.jsonl" ] || continue
      python -m scriptleak.sweep --dump "$dd/real_$sn" --majority th --minority en --spoken th \
          --group-by stratum --methods greedy --out "$r/real_$sn.json" > /dev/null || echo "!! $sn failed for ${labels[$i]}"
      python -m scriptleak.evaluate --manifest "$dd/real_$sn/utts.jsonl" --majority th --minority en \
          --hyp-field pred_transducer --group-by stratum --out "$r/real_${sn}_rnnt.json" > /dev/null \
        || echo "!! $sn transducer scoring failed for ${labels[$i]}"
    done
    for sn in lotus_mixed gs2_mixed; do
      [ -s "$dd/real_$sn/utts.jsonl" ] || continue
      python -m scriptleak.retention score --manifest "$dd/real_$sn/utts.jsonl" --group-by stratum \
          --out "$r/real_$sn.json" > /dev/null || echo "!! $sn retention failed for ${labels[$i]}"
    done
  done
  {
    local sn head
    for sn in lotus_th gs2_th; do
      compgen -G "$W/results/B${B_PCT}_*/real_$sn.json" > /dev/null || continue
      case "$sn" in lotus_th) head="LOTUSDIS far-field meetings, per microphone" ;; *) head="GigaSpeech 2 test (YouTube)" ;; esac
      echo "################ $head, English = ${B_PCT}%: CTC head (leak rate / CER) ################"
      _compare_all "real_$sn.json"
      echo; echo "################ $head: transducer head (leak rate / CER) ################"
      _compare_all "real_${sn}_rnnt.json"
      echo
    done
    for sn in lotus_mixed gs2_mixed; do
      local all=() f n
      for f in "$W"/results/B${B_PCT}_*/"real_$sn.json"; do
        [ -e "$f" ] || continue
        n="$(basename "$(dirname "$f")")"; all+=("${n#B${B_PCT}_}=$f")
      done
      [ ${#all[@]} -gt 0 ] || continue
      echo "################ $sn: English words that really are in the Thai reference ################"
      python -m scriptleak.retention table "${all[@]}"
      echo
    done
  } 2>&1 | tee "$W/real_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/real_en${B_PCT}_summary.txt"
}

case "${1:-}" in
  prepare)   stage_prepare ;;
  audit)     stage_audit ;;
  split)     stage_split ;;
  mix)       stage_mix ;;
  tokenizer) stage_tokenizer ;;
  train05)   train_one 05 ;;
  train20)   train_one 20 ;;
  dump)      stage_dump ;;
  results)   stage_results ;;
  probeA)    stage_probeA ;;
  noisefloor) stage_noisefloor ;;
  prepB)     stage_prepB ;;
  trainB)    stage_trainB "${2:-}" ;;
  evalB)     shift; stage_evalB "$@" ;;
  nightB)    shift; stage_nightB "$@" ;;
  realprep)  stage_realprep ;;
  realB)     stage_realB ;;
  *) sed -n '2,24p' "$0"; exit 1 ;;
esac
