"""How noisy is each training block?

Phase A suggests the model ties background noise to the minority language.
That needs the minority block to be noisier than the majority block. This
measures it directly on a sample of each manifest, with two crude numbers per
utterance from 25 ms frame energies:

  floor_db    level of the quiet frames (5th percentile), in dB full scale
  range_db    loud frames minus quiet frames (95th - 5th percentile): a rough
              signal-to-noise ratio; clean studio speech has a large range

  python -m scriptleak.noisefloor --manifest th=th_central.train.jsonl en=en_train.clean.jsonl
"""

from __future__ import annotations

import argparse
import sys
from typing import Dict, List, Optional

import numpy as np

from .audio import to_mono
from .manifest import read_manifest


def frame_db(x: np.ndarray, sr: int, win: float = 0.025, hop: float = 0.010) -> np.ndarray:
    n, h = max(1, int(win * sr)), max(1, int(hop * sr))
    if len(x) < n:
        return np.zeros(0)
    idx = np.arange(0, len(x) - n + 1, h)
    c = np.concatenate([[0.0], np.cumsum(np.square(x, dtype=np.float64))])
    e = (c[idx + n] - c[idx]) / n
    return 10.0 * np.log10(np.maximum(e, 1e-12))


def utterance_stats(x: np.ndarray, sr: int) -> Optional[Dict[str, float]]:
    db = frame_db(x, sr)
    if len(db) < 10:
        return None
    lo, hi = np.percentile(db, [5, 95])
    return {"floor_db": float(lo), "range_db": float(hi - lo)}


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--manifest", nargs="+", required=True, metavar="NAME=PATH")
    p.add_argument("--sample", type=int, default=1000)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args(argv)

    import soundfile as sf

    print(f"{'block':<10} {'n':>6} {'floor dB (median)':>18} {'range dB (median)':>18} {'range 10%-90%':>16}")
    for item in args.manifest:
        name, path = item.split("=", 1)
        entries = list(read_manifest(path))
        if len(entries) > args.sample:
            pick = np.random.default_rng(args.seed).choice(len(entries), args.sample, replace=False)
            entries = [entries[i] for i in pick.tolist()]
        rows = []
        for e in entries:
            x, sr = sf.read(e["audio_filepath"], dtype="float32", always_2d=False)
            st = utterance_stats(to_mono(x), sr)
            if st:
                rows.append(st)
        if not rows:
            print(f"{name:<10} no readable audio")
            continue
        fl = np.array([r["floor_db"] for r in rows])
        rg = np.array([r["range_db"] for r in rows])
        print(f"{name:<10} {len(rows):>6} {np.median(fl):>18.1f} {np.median(rg):>18.1f} "
              f"{np.percentile(rg, 10):>7.1f}-{np.percentile(rg, 90):<7.1f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
