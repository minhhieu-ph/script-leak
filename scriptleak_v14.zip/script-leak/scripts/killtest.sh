#!/usr/bin/env bash
# The two-week kill test, one stage at a time.
#
#   bash scripts/killtest.sh STAGE
#
# Stages, in order:
#   prepare    corpora -> raw manifests            (needs TEXT_COL)
#   audit      spoken-form filter; STOP and read the Thai hours
#   split      Thai train/dev/test, noisy strata, dialect test sets
#   mix        training manifests (English = 5% and 20% of hours)
#   tokenizer  one SentencePiece model per language
#   train05    train with 5% English                (needs BASE_CONFIG)
#   train20    train with 20% English
#   dump       frame-level log-probabilities for both models
#   results    leakage tables, frame analysis, method sweep
#   probeA     phase A: distortion probes and the span acceptance test
#              (uses the two trained models, no training)
#   noisefloor | prepB | trainB NAME | evalB NAME...   phase B, see below
#
# Settings are environment variables, e.g.
#   D=/data/scriptleak TEXT_COL=sentence bash scripts/killtest.sh prepare
# prepare also reads TEXT_COL_CENTRAL, CENTRAL_MAX_HOURS (450, 0 = all),
# PREP_WORKERS (16). It can be re-run after an interruption.
# audit reads TH_KEEP_SPACES (1 = keep Thai word spaces, 0 = remove them).
#
# NOT TESTED where it was written (no data, no GPU there).
set -euo pipefail

D="${D:-/data/scriptleak}"            # where download_data.sh put the corpora
W="${W:-$D/work}"                     # manifests, tokenizers, models, dumps
TEXT_COL="${TEXT_COL:-}"              # transcript column of the Thai datasets
SPEAKER_COL="${SPEAKER_COL:-}"        # speaker column, if the datasets have one
BASE_CONFIG="${BASE_CONFIG:-}"        # a NeMo FastConformer hybrid transducer-CTC BPE yaml
INIT="${INIT:-stt_en_fastconformer_hybrid_large_streaming_multi}"   # INIT=none trains from scratch
GPUS="${GPUS:-8}"
BATCH="${BATCH:-32}"                  # per GPU
EPOCHS="${EPOCHS:-10}"
TH_HOURS="${TH_HOURS:-300}"
DIALECT_TEST_HOURS="${DIALECT_TEST_HOURS:-5}"
DIALECTS="khummuang korat pattani"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"
mkdir -p "$W"
need() { [ -n "${!1}" ] || { echo "Set $1 first. $2"; exit 1; }; }

stage_prepare() {
  need TEXT_COL "Find it with: python -m scriptleak.prepare hf-columns --dataset CMKL/Porjai-Thai-voice-dataset-korat"
  for part in train-clean-100:en_train dev-clean:en_dev test-clean:en_test; do
    python -m scriptleak.prepare librispeech --root "$D/LibriSpeech" \
        --subsets "${part%%:*}" --out "$W/${part##*:}.raw.jsonl"
  done
  local copy=()
  [ -n "$SPEAKER_COL" ] && copy=(--copy-cols "$SPEAKER_COL")
  # The central set may name its transcript column differently from the
  # dialect sets: TEXT_COL_CENTRAL overrides TEXT_COL for it. CENTRAL_MAX_HOURS
  # (default 450) keeps disk use down; the experiments need about 315 clean hours.
  for name in central $DIALECTS; do
    local col="$TEXT_COL" cap=()
    if [ "$name" = central ]; then
      col="${TEXT_COL_CENTRAL:-$TEXT_COL}"
      [ "${CENTRAL_MAX_HOURS:-450}" != 0 ] && cap=(--max-hours "${CENTRAL_MAX_HOURS:-450}")
    fi
    python -m scriptleak.prepare hf --dataset "CMKL/Porjai-Thai-voice-dataset-$name" \
        --split train --text-col "$col" "${copy[@]}" "${cap[@]}" \
        --num-workers "${PREP_WORKERS:-16}" \
        --audio-out "$D/porjai/$name/wav" --out "$W/th_$name.raw.jsonl"
  done
}

stage_audit() {
  local sp=()
  [ "${TH_KEEP_SPACES:-1}" = 1 ] && sp=(--keep-spaces)
  python -m scriptleak.audit --manifest "$W/th_central.raw.jsonl" --lang th "${sp[@]}" \
      --out-manifest "$W/th_central.clean.jsonl" --report "$W/th_central.audit.json"
  for s in en_train en_dev en_test; do
    python -m scriptleak.audit --manifest "$W/$s.raw.jsonl" --lang en \
        --out-manifest "$W/$s.clean.jsonl" --report "$W/$s.audit.json"
  done
  for name in $DIALECTS; do
    python -m scriptleak.audit --manifest "$W/th_$name.raw.jsonl" --lang th "${sp[@]}" \
        --out-manifest "$W/th_$name.clean.jsonl" --report "$W/th_$name.audit.json" \
        --set "stratum=$name"
  done
  echo
  echo "STOP: Thai-central needs at least $((TH_HOURS + 15)) clean hours (see above)."
}

stage_split() {
  # Split by sentence (text_key) unless a speaker column is given: the corpus
  # has each sentence read by several people, and a test sentence must not
  # also be a training sentence.
  local spk=(--speaker-field "${SPEAKER_COL:-text_key}")
  python -m scriptleak.split --manifest "$W/th_central.clean.jsonl" \
      --dev-hours 3 --test-hours 10 "${spk[@]}" --out-prefix "$W/th_central"
  python -m scriptleak.noise --manifest "$W/th_central.test.jsonl" --noise-dir "$D/musan/noise" \
      --snrs 10 5 0 --out-dir "$D/th_test_noisy" --out-manifest "$W/th_test.strata.jsonl"
  for name in $DIALECTS; do
    python -m scriptleak.split --manifest "$W/th_$name.clean.jsonl" \
        --dev-hours 0 --test-hours "$DIALECT_TEST_HOURS" "${spk[@]}" --out-prefix "$W/th_$name"
    cat "$W/th_$name.test.jsonl" >> "$W/th_test.strata.jsonl"
  done
  echo "Thai test set with strata: $W/th_test.strata.jsonl"
}

stage_mix() {
  for pct in 05 20; do
    python -m scriptleak.mix --majority "$W/th_central.train.jsonl" --minority "$W/en_train.clean.jsonl" \
        --majority-hours "$TH_HOURS" --minority-fraction "0.$pct" --seed 0 \
        --out "$W/train_th${TH_HOURS}_en$pct.jsonl"
  done
}

stage_tokenizer() {
  python -m scriptleak.nemo_tools.build_tokenizer --manifest "$W/th_central.train.jsonl" \
      --out-dir "$W/tokenizers/th_bpe1024" --vocab-size 1024
  python -m scriptleak.nemo_tools.build_tokenizer --manifest "$W/en_train.clean.jsonl" \
      --out-dir "$W/tokenizers/en_bpe256" --vocab-size 256
}

train_one() {  # train_one PCT
  need BASE_CONFIG "Pick one of the yaml files printed by scripts/setup_env.sh (step 4)."
  local init=()
  [ "$INIT" != "none" ] && init=(--init-pretrained "$INIT")
  python -m scriptleak.nemo_tools.train --base-config "$BASE_CONFIG" \
      --train-manifest "$W/train_th${TH_HOURS}_en$1.jsonl" \
      --val-manifest "$W/th_central.dev.jsonl" "$W/en_dev.clean.jsonl" \
      --tokenizer "th=$W/tokenizers/th_bpe1024" "en=$W/tokenizers/en_bpe256" \
      "${init[@]}" --exp-dir "$W/exp/th${TH_HOURS}_en$1" \
      --max-epochs "$EPOCHS" --batch-size "$BATCH" --num-workers 8 --devices "$GPUS"
}

stage_dump() {
  for pct in 05 20; do
    local m="$W/exp/th${TH_HOURS}_en$pct"
    CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs --model "$m/final.nemo" \
        --manifest "$W/th_test.strata.jsonl" --out "$W/dumps/en$pct/th_test" --transducer
    CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs --model "$m/final.nemo" \
        --manifest "$W/en_test.clean.jsonl" --out "$W/dumps/en$pct/en_test" --transducer
  done
}

stage_results() {
  for pct in 05 20; do
    local dd="$W/dumps/en$pct" r="$W/results/en$pct"
    mkdir -p "$r"
    echo "################ English = $pct% of training hours ################"
    echo "--- 1. Is there leakage, and does it grow with difficulty? (CTC head)"
    python -m scriptleak.sweep --dump "$dd/th_test" --majority th --minority en --spoken th \
        --group-by stratum --methods greedy --out "$r/leak_ctc.json" || echo "!! this step failed; continuing"
    echo "--- 2. Same question for the transducer head"
    python -m scriptleak.evaluate --manifest "$dd/th_test/utts.jsonl" --majority th --minority en \
        --hyp-field pred_transducer --group-by stratum --out "$r/leak_transducer.json" || echo "!! this step failed; continuing"
    echo "--- 3. Why: frame analysis"
    python -m scriptleak.analysis --dump "$dd/th_test" --majority th --minority en \
        --group-by stratum --out "$r/frames.json" || echo "!! this step failed; continuing"
    echo "--- 4. Methods on Thai speech"
    python -m scriptleak.sweep --dump "$dd/th_test" --majority th --minority en --spoken th \
        --out "$r/sweep_th.json" || echo "!! this step failed; continuing"
    echo "--- 5. What each method costs English"
    python -m scriptleak.sweep --dump "$dd/en_test" --majority th --minority en --spoken en \
        --out "$r/sweep_en.json" || echo "!! this step failed; continuing"
  done 2>&1 | tee "$W/results_summary.txt"
  echo "Summary saved to $W/results_summary.txt"
}

stage_probeA() {
  # Phase A: probes on the two trained models, no training.
  #   PROBE_UTTS (2000) clean Thai test utterances are distorted in 8 ways.
  local P="$W/probeA"
  mkdir -p "$P"
  if [ ! -s "$P/th_probes.jsonl" ] || [ ! -s "$P/nonspeech.jsonl" ]; then
    python -m scriptleak.probes --manifest "$W/th_central.test.jsonl" --noise-dir "$D/musan/noise" \
        --out-dir "$D/probeA_audio" --out-manifest "$P/th_probes.jsonl" \
        --out-nonspeech "$P/nonspeech.jsonl" --max-utts "${PROBE_UTTS:-2000}"
  fi
  if [ ! -s "$P/en_strata.jsonl" ]; then
    python -m scriptleak.noise --manifest "$W/en_test.clean.jsonl" --noise-dir "$D/musan/noise" \
        --snrs 10 5 0 --out-dir "$D/en_test_noisy" --out-manifest "$P/en_strata.jsonl"
  fi
  for pct in 05 20; do
    for set in th_probes nonspeech en_strata; do
      local out="$W/dumps/en$pct/$set"
      if [ ! -s "$out/meta.json" ] || [ ! -s "$out/utts.jsonl" ]; then
        CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs \
            --model "$W/exp/th${TH_HOURS}_en$pct/final.nemo" --manifest "$P/$set.jsonl" --out "$out"
      fi
    done
  done
  for pct in 05 20; do
    local dd="$W/dumps/en$pct" r="$W/results/en$pct"
    mkdir -p "$r"
    echo "################ English = $pct% of training hours ################"
    echo "--- A1. Which distortions make Thai speech leak? (CTC head)"
    python -m scriptleak.sweep --dump "$dd/th_probes" --majority th --minority en --spoken th \
        --group-by stratum --methods greedy --out "$r/probes_th.json" || echo "!! this step failed; continuing"
    echo "--- A2. No speech at all: what does the model write?"
    python -m scriptleak.nonspeech --manifest "$dd/nonspeech/utts.jsonl" --majority th --minority en \
        --out "$r/nonspeech.json" || echo "!! this step failed; continuing"
    echo "--- A3. Noisy English: is the error symmetric?"
    python -m scriptleak.sweep --dump "$dd/en_strata" --majority th --minority en --spoken en \
        --group-by stratum --methods greedy --out "$r/probes_en.json" || echo "!! this step failed; continuing"
    echo "--- A4. Can leaked spans be told from real English spans?"
    python -m scriptleak.spans --majority th --minority en \
        --leak-dump "$dd/th_test" "$dd/th_probes" --genuine-dump "$dd/en_strata" \
        --majority-text "$W/th_central.train.jsonl" --minority-text "$W/en_train.clean.jsonl" \
        --out "$r/spans.json" || echo "!! this step failed; continuing"
  done 2>&1 | tee "$W/probeA_summary.txt"
  echo "Summary saved to $W/probeA_summary.txt"
}

# ---------------------------------------------------------------- phase B
# Causal experiments. All start from the mix with B_PCT% English (default 20).
#   noisefloor          how noisy each training block is (minutes, CPU)
#   prepB               noisy training copies + held-out test manifests
#   trainB NAME         NAME = both | en | th   noise on both / English / Thai blocks
#                              noinit           clean data, encoder not initialised
#   evalB NAME [NAME..] dump + tables; NAME = base (the existing clean model) or as above
B_PCT="${B_PCT:-20}"
B_EPOCHS="${B_EPOCHS:-50}"
SAVE_EVERY="${SAVE_EVERY:-10}"

stage_noisefloor() {
  python -m scriptleak.noisefloor --manifest "th=$W/th_central.train.jsonl" "en=$W/en_train.clean.jsonl"
}

stage_prepB() {
  local base="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl"
  python -m scriptleak.augment make --manifest "$base" --noise-dir "$D/musan/noise" \
      --out-dir "$D/aug/en${B_PCT}" --out "$W/trainB.aug.jsonl" \
      --prob "${AUG_PROB:-0.5}" --snr-min "${AUG_SNR_MIN:-0}" --snr-max "${AUG_SNR_MAX:-20}" \
      --num-workers "${PREP_WORKERS:-16}"
  python -m scriptleak.augment select --manifest "$W/trainB.aug.jsonl" --langs th en --out "$W/trainB_aug-both.jsonl"
  python -m scriptleak.augment select --manifest "$W/trainB.aug.jsonl" --langs en    --out "$W/trainB_aug-en.jsonl"
  python -m scriptleak.augment select --manifest "$W/trainB.aug.jsonl" --langs th    --out "$W/trainB_aug-th.jsonl"
  python -m scriptleak.augment filter-heldout --manifest "$W/th_test.strata.jsonl" --out "$W/th_test.heldout.jsonl"
  # the curve set: clean + held-out noise only, no dialects (small, so every snapshot can be scored)
  python - "$W/th_test.heldout.jsonl" "$W/th_curve.jsonl" <<'PY'
import json, sys
keep = [l for l in open(sys.argv[1], encoding="utf-8")
        if l.strip() and (json.loads(l).get("stratum") == "clean" or str(json.loads(l).get("stratum", "")).startswith("snr"))]
open(sys.argv[2], "w", encoding="utf-8").writelines(keep)
print(f"curve set: {len(keep)} utterances")
PY
  if [ -s "$W/probeA/en_strata.jsonl" ]; then
    python -m scriptleak.augment filter-heldout --manifest "$W/probeA/en_strata.jsonl" --out "$W/en_test.heldout.jsonl"
  else
    echo "NOTE: run 'probeA' first to get the noisy English test set"
  fi
}

stage_trainB() {  # stage_trainB NAME
  need BASE_CONFIG "Pick one of the yaml files printed by scripts/setup_env.sh (step 4)."
  local name="${1:-}" manifest init=()
  [ "$INIT" != "none" ] && init=(--init-pretrained "$INIT")
  case "$name" in
    both|en|th) manifest="$W/trainB_aug-$name.jsonl" ;;
    noinit)     manifest="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl"; init=() ;;
    *) echo "usage: killtest.sh trainB both|en|th|noinit"; exit 1 ;;
  esac
  [ -s "$manifest" ] || { echo "missing $manifest: run 'prepB' first"; exit 1; }
  python -m scriptleak.nemo_tools.train --base-config "$BASE_CONFIG" \
      --train-manifest "$manifest" \
      --val-manifest "$W/th_central.dev.jsonl" "$W/en_dev.clean.jsonl" \
      --tokenizer "th=$W/tokenizers/th_bpe1024" "en=$W/tokenizers/en_bpe256" \
      ${init[@]+"${init[@]}"} --exp-dir "$W/exp/B_$name" --save-every-epochs "$SAVE_EVERY" \
      --max-epochs "$B_EPOCHS" --batch-size "$BATCH" --num-workers 8 --devices "$GPUS"
}

_dump_if_missing() {  # MODEL MANIFEST OUT
  if [ ! -s "$3/meta.json" ] || [ ! -s "$3/utts.jsonl" ]; then
    CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs --model "$1" --manifest "$2" --out "$3"
  fi
}

stage_evalB() {  # stage_evalB NAME [NAME ...]
  [ $# -ge 1 ] || { echo "usage: killtest.sh evalB base|both|en|th|noinit [...]"; exit 1; }
  local name m dd r
  for name in "$@"; do
    if [ "$name" = base ]; then m="$W/exp/th${TH_HOURS}_en${B_PCT}"; else m="$W/exp/B_$name"; fi
    [ -s "$m/final.nemo" ] || { echo "!! $m/final.nemo not found; skipping $name"; continue; }
    dd="$W/dumps/B_$name"; r="$W/results/B_$name"; mkdir -p "$r"
    _dump_if_missing "$m/final.nemo" "$W/th_test.heldout.jsonl" "$dd/heldout"
    python -m scriptleak.sweep --dump "$dd/heldout" --majority th --minority en --spoken th \
        --group-by stratum --methods greedy --out "$r/heldout.json" > /dev/null || echo "!! heldout failed for $name"
    if [ -s "$W/probeA/th_probes.jsonl" ]; then
      _dump_if_missing "$m/final.nemo" "$W/probeA/th_probes.jsonl" "$dd/probes"
      python -m scriptleak.sweep --dump "$dd/probes" --majority th --minority en --spoken th \
          --group-by stratum --methods greedy --out "$r/probes.json" > /dev/null || echo "!! probes failed for $name"
    fi
    if [ -s "$W/en_test.heldout.jsonl" ]; then
      _dump_if_missing "$m/final.nemo" "$W/en_test.heldout.jsonl" "$dd/en"
      python -m scriptleak.sweep --dump "$dd/en" --majority th --minority en --spoken en \
          --group-by stratum --methods greedy --out "$r/en.json" > /dev/null || echo "!! en failed for $name"
    fi
    local snap ep
    for snap in "$m"/epoch*.nemo; do
      [ -e "$snap" ] || continue
      ep="$(basename "$snap" .nemo)"
      _dump_if_missing "$snap" "$W/th_curve.jsonl" "$dd/curve_$ep"
      python -m scriptleak.sweep --dump "$dd/curve_$ep" --majority th --minority en --spoken th \
          --group-by stratum --methods greedy --out "$r/curve_$ep.json" > /dev/null || echo "!! curve $ep failed"
    done
  done
  {
    local all=() f n
    echo "################ Phase B: Thai test, held-out noise (leak rate / CER) ################"
    for f in "$W"/results/B_*/heldout.json; do [ -e "$f" ] && n="$(basename "$(dirname "$f")")" && all+=("${n#B_}=$f"); done
    [ ${#all[@]} -gt 0 ] && python -m scriptleak.compare "${all[@]}"
    echo; echo "################ Distortions never used in training (leak rate / CER) ################"
    all=(); for f in "$W"/results/B_*/probes.json; do [ -e "$f" ] && n="$(basename "$(dirname "$f")")" && all+=("${n#B_}=$f"); done
    [ ${#all[@]} -gt 0 ] && python -m scriptleak.compare "${all[@]}"
    echo; echo "################ English test (Thai-script rate / WER) ################"
    all=(); for f in "$W"/results/B_*/en.json; do [ -e "$f" ] && n="$(basename "$(dirname "$f")")" && all+=("${n#B_}=$f"); done
    [ ${#all[@]} -gt 0 ] && python -m scriptleak.compare --error wer "${all[@]}"
    for name in "$@"; do
      all=(); for f in "$W/results/B_$name"/curve_epoch*.json; do [ -e "$f" ] && all+=("$(basename "$f" .json | sed 's/curve_//')=$f"); done
      [ -e "$W/results/B_$name/heldout.json" ] && [ ${#all[@]} -gt 0 ] && all+=("final=$W/results/B_$name/heldout.json")
      if [ ${#all[@]} -gt 0 ]; then
        echo; echo "################ $name: leakage during training (leak rate / CER) ################"
        python -m scriptleak.compare "${all[@]}"
      fi
    done
  } 2>&1 | tee "$W/phaseB_summary.txt"
  echo "Summary saved to $W/phaseB_summary.txt"
}

case "${1:-}" in
  prepare)   stage_prepare ;;
  audit)     stage_audit ;;
  split)     stage_split ;;
  mix)       stage_mix ;;
  tokenizer) stage_tokenizer ;;
  train05)   train_one 05 ;;
  train20)   train_one 20 ;;
  dump)      stage_dump ;;
  results)   stage_results ;;
  probeA)    stage_probeA ;;
  noisefloor) stage_noisefloor ;;
  prepB)     stage_prepB ;;
  trainB)    stage_trainB "${2:-}" ;;
  evalB)     shift; stage_evalB "$@" ;;
  *) sed -n '2,22p' "$0"; exit 1 ;;
esac
