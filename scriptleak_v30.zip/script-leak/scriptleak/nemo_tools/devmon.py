"""Score script leakage on small real dev sets after every training epoch (v30).

A Lightning callback for nemo_tools.train. After each epoch, on the main
process only, a fixed random subset of each monitor set (default 1000
utterances; only utterances whose reference is purely in the spoken script)
is run through the CTC head, decoded greedily and with the utterance-level
script lock, and scored:

  leak   share of utterances with any letter of the other script
  err    CER (Thai, spaces ignored) or WER (English)

One JSON line per epoch goes to <exp_dir>/devmon.jsonl, and from
--monitor-save-from on the model is saved as mon_epochNNN.nemo, so that a
checkpoint chosen afterwards (scriptleak.esmon) can be tested. The other
processes wait at a barrier meanwhile.
"""

from __future__ import annotations

import json
import os
import random
from typing import Dict, List

import numpy as np

from ..audio import resample, to_mono
from ..decoding import greedy, utterance_lock
from ..manifest import read_manifest
from ..normalize import scoring_normalize
from ..realstats import EN, TH, spoken_other
from ..tokenmap import ids_to_text, token_groups


def pick_subset(path: str, set_name: str, n: int, seed: int = 0) -> List[Dict]:
    spoken, other = spoken_other(set_name)
    rows = []
    for r in read_manifest(path):
        ref = scoring_normalize(str(r.get("text", "")))
        if ref and spoken.script.count(ref) and not other.script.count(ref):
            rows.append(r)
    random.Random(seed).shuffle(rows)
    return rows[:n]


def score_logprobs(rows: List[Dict], logps: List[np.ndarray], vocab: List[str], set_name: str) -> Dict:
    """leak / error rate for greedy and lock decoding of one monitor set."""
    from ..pareto import edit_distance

    blank = len(vocab)
    groups = token_groups(vocab, TH, EN, blank_id=blank)
    spoken, other = spoken_other(set_name)
    english = spoken is EN
    out = {}
    for name, fn in (("greedy", lambda lp: greedy(lp, groups)), ("lock", lambda lp: utterance_lock(lp, groups))):
        leak, errs, n = 0, 0, 0
        for r, lp in zip(rows, logps):
            hyp = scoring_normalize(ids_to_text(fn(lp), vocab))
            ref = scoring_normalize(str(r.get("text", "")))
            leak += other.script.count(hyp) > 0
            ru = ref.split() if english else ref.replace(" ", "")
            hu = hyp.split() if english else hyp.replace(" ", "")
            errs += edit_distance(ru, hu)
            n += len(ru)
        out[name] = {"leak": leak / max(1, len(rows)), "err": errs / max(1, n)}
    return out


def make_callback(pl, sets: Dict[str, str], exp_dir: str, n: int = 1000, save_from: int = 10,
                  batch_size: int = 16):
    import soundfile as sf
    import torch

    subsets = {s: pick_subset(p, s, n) for s, p in sets.items()}
    log_path = os.path.join(exp_dir, "devmon.jsonl")

    class DevLeakMonitor(pl.Callback):
        def _logps(self, model, rows):
            sr = int(model.cfg.preprocessor.sample_rate)
            head = model.ctc_decoder
            dev = next(model.parameters()).device
            order = sorted(range(len(rows)), key=lambda i: -float(rows[i].get("duration", 0.0)))
            out = [None] * len(rows)
            for s in range(0, len(order), batch_size):
                idx = order[s:s + batch_size]
                wavs = []
                for i in idx:
                    a, r = sf.read(rows[i]["audio_filepath"], dtype="float32", always_2d=False)
                    wavs.append(torch.from_numpy(np.ascontiguousarray(resample(to_mono(a), r, sr))))
                lens = torch.tensor([len(w) for w in wavs], device=dev)
                sig = torch.nn.utils.rnn.pad_sequence(wavs, batch_first=True).to(dev)
                feat, feat_len = model.preprocessor(input_signal=sig, length=lens)
                enc, enc_len = model.encoder(audio_signal=feat, length=feat_len)
                lp = head(encoder_output=enc).float().cpu().numpy()
                for row, i in enumerate(idx):
                    out[i] = lp[row, : int(enc_len[row])]
            return out

        def on_train_epoch_end(self, trainer, pl_module):
            epoch = trainer.current_epoch + 1
            if trainer.is_global_zero:
                was_training = pl_module.training
                pl_module.eval()
                rec = {"epoch": epoch, "step": int(trainer.global_step)}
                try:
                    vocab = list(pl_module.ctc_decoder.vocabulary)
                    with torch.inference_mode():
                        for s, rows in subsets.items():
                            res = score_logprobs(rows, self._logps(pl_module, rows), vocab, s)
                            for m, v in res.items():
                                rec[f"{s}/{m}/leak"] = v["leak"]
                                rec[f"{s}/{m}/err"] = v["err"]
                    with open(log_path, "a", encoding="utf-8") as f:
                        f.write(json.dumps(rec) + "\n")
                    print(f"[devmon] epoch {epoch}: " + " ".join(f"{k}={v:.3f}" for k, v in rec.items()
                                                                  if isinstance(v, float)), flush=True)
                    if epoch >= save_from and epoch < trainer.max_epochs:
                        pl_module.save_to(os.path.join(exp_dir, f"mon_epoch{epoch:03d}.nemo"))
                except Exception as e:  # the monitor must never stop training
                    print(f"[devmon] WARNING epoch {epoch}: {type(e).__name__}: {e}", flush=True)
                finally:
                    if was_training:
                        pl_module.train()
            try:
                trainer.strategy.barrier()
            except Exception:  # noqa: BLE001
                pass

    return DevLeakMonitor()
