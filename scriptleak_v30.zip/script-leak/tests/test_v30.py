import json
import os

import numpy as np

from scriptleak import esmon
from scriptleak.nemo_tools.devmon import pick_subset, score_logprobs
from tests.test_v25 import BLANK, VOCAB, _fake_dump


def _row(e, lk, c=0.5, w=0.6):
    r = {"epoch": e}
    for s in esmon.SETS:
        r[f"{s}/lock/leak"] = lk / 2
        r[f"{s}/greedy/leak"] = lk / 2 + 0.05
    r[f"{esmon.SETS[0]}/lock/err"] = c
    r[f"{esmon.SETS[1]}/lock/err"] = w
    return r


def test_select_rules():
    rows = [_row(e, lk, c, w) for e, lk, c, w in
            [(10, 0.05, 0.80, 0.90), (15, 0.30, 0.60, 0.70), (20, 0.10, 0.55, 0.65), (25, 0.40, 0.55, 0.64),
             (30, 0.35, 0.54, 0.64), (35, 0.33, 0.54, 0.64), (40, 0.32, 0.54, 0.64), (45, 0.31, 0.54, 0.64),
             (50, 0.50, 0.54, 0.64)]]
    p = esmon.select(rows, saved=[10, 15, 20, 25, 30, 35, 40, 45], tol=0.02, patience=5)
    assert p["final"] == 50
    assert p["min-leak"] == 10            # lowest leak, accuracy ignored
    assert p["guarded"] == 20             # epoch 10 fails the accuracy guard
    assert p["es5"] == 20 and p["es5_stop"] == 45


def test_pick_subset_and_score(tmp_path):
    man = tmp_path / "m.jsonl"
    rows = [{"audio_filepath": f"/{i}.wav", "text": "สวัสดี" if i % 3 else "สวัสดี hello"} for i in range(30)]
    man.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in rows), encoding="utf-8")
    sub = pick_subset(str(man), "dev_lotus_th", 10)
    assert len(sub) == 10 and all("hello" not in r["text"] for r in sub)
    lp = np.full((6, len(VOCAB) + 1), -10.0, np.float32)
    lp[:, BLANK] = -0.1
    lp[2, 6] = -0.01            # "hello" wins one frame
    good = np.full_like(lp, -10.0)
    good[:, BLANK] = -0.1
    good[2, 3] = -0.01          # "สวัสดี"
    res = score_logprobs(sub[:2], [lp, good], VOCAB, "dev_lotus_th")
    assert res["greedy"]["leak"] == 0.5 and res["greedy"]["err"] > 0


def test_report(tmp_path, capsys):
    work = str(tmp_path)
    rng = np.random.default_rng(0)
    for l in ("rir_es", "rir_s1_es"):
        exp = os.path.join(work, "exp", f"B20_{l}")
        os.makedirs(exp)
        rows = [_row(e, 0.2 + 0.1 * np.sin(e)) for e in range(10, 51)]
        with open(os.path.join(exp, "devmon.jsonl"), "w") as f:
            f.write("\n".join(json.dumps(r) for r in rows))
        for e in range(10, 50):
            open(os.path.join(exp, f"mon_epoch{e:03d}.nemo"), "w").close()
        assert esmon.cmd_select(type("A", (), {"exp_dir": exp, "tol": 0.01, "patience": 5, "prune": True})()) == 0
        picks = json.load(open(os.path.join(exp, "esmon_picks.json")))
        assert len(esmon.saved_epochs(exp)) <= 6
        for k, e in picks.items():
            if k.endswith("_stop"):
                continue
            for s in esmon.TEST:
                _fake_dump(esmon._cand_dump(work, "20", l, e, 50, s), s, 20, rng, 0.5)
    args = type("A", (), {"work": work, "b_pct": "20", "labels": ["rir_es", "rir_s1_es"], "workers": 2, "out": None})()
    assert esmon.cmd_report(args) == 0
    out = capsys.readouterr().out
    assert "-- rir" in out and "guarded" in out and "Early stopping" in out
