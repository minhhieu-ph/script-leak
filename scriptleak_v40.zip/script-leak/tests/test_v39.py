import json, os
from scriptleak import collect


def test_collect(tmp_path):
    w = tmp_path / "work"; (w / "logs").mkdir(parents=True); (w / "exp" / "B20_rir_es").mkdir(parents=True)
    repo = tmp_path / "repo"; repo.mkdir()
    (w / "esC_en20_summary.txt").write_text("Dev curves\r  8/48\r\n  rir_es 5:3%\n", encoding="utf-8")
    (w / "results_summary.txt").write_text("phase A table\n", encoding="utf-8")
    (w / "weird_extra.txt").write_text("something else\n", encoding="utf-8")
    (w / "logs" / "extraC.log").write_text("ok\n!! cannot load x\n!! cannot load x\nEpoch 1: 50%|#####     | 3/6 [00:01<00:01, 2.0it/s]\n", encoding="utf-8")
    (w / "exp" / "B20_rir_es" / "devmon.jsonl").write_text('{"epoch":1}\n{"epoch":2}\n')
    (w / "exp" / "B20_rir_es" / "esmon_picks.json").write_text(json.dumps({"final": 50}))
    (w / "lid_voxlingua107.jsonl").write_text('{"a":1}\n{"a":2}\n')
    (repo / "audit.log").write_text("\n".join(f"line {i}" for i in range(100)), encoding="utf-8")
    assert collect.main(["--work", str(w), "--repo", str(repo)]) == 0
    t = (w / "ALL_RESULTS.txt").read_text(encoding="utf-8")
    assert t.index("results_summary.txt") < t.index("esC_en20_summary.txt")  # stage order
    assert "8/48" not in t and "rir_es 5:3%" in t
    assert "weird_extra.txt" in t and "something else" in t
    assert t.count("!! cannot load x") == 1 and "it/s" not in t
    assert "B20_rir_es" in t and '{"final": 50}' in t and "2 utterances" in t
    assert "line 99" in t and "line 10\n" not in t  # tail of repository logs
    assert "Not found" in t and "extraD_en20_summary.txt" in t
