"""Gather every result the project has written into one text file (v39).

  python -m scriptleak.collect --work $W [--repo .] [--out $W/ALL_RESULTS.txt]

Order: the summary of each stage in the order the stages were run (phase A -> v38),
then any other *.txt result in $W, then an inventory (files, models, early-stopping
picks), then an index of every log with its warnings ("!!" lines, tracebacks), and the
tail of the logs kept in the repository folder (prepare, audit, split, mix, realprep ...).
Progress bars and carriage returns are removed; numbers are copied as they were printed.
CPU only, seconds.
"""

from __future__ import annotations

import argparse
import datetime as dt
import glob
import json
import os
import re
import sys
from typing import List, Optional, Tuple

# (file name with {b} for B_PCT, title, stage, version)
STAGES: Tuple[Tuple[str, str, str, str], ...] = (
    ("results_summary.txt", "Phase A: leakage on synthetic tests, frame analysis (H1), method sweep", "results", "v1-v16"),
    ("probeA_summary.txt", "Phase A: distortion probes, no-speech probes, span acceptance test (G3/G4)", "probeA", "v1-v16"),
    ("phaseB_en{b}_summary.txt", "Phase B: noise recipes on held-out MUSAN, distortions, English test, adaptation", "evalB/nightB", "v16-v23"),
    ("real_en{b}_summary.txt", "Real audio: LOTUSDIS per microphone, AMI far-field, both directions, leakage taken apart", "realB", "v17-v23"),
    ("probeC_en{b}_summary.txt", "Babble, music, quiet talker, residual leaks (G5)", "probeC", "v19-v23"),
    ("seedC_en{b}_summary.txt", "Do seeds leak on the same utterances? 95% intervals (G9)", "seedC", "v24"),
    ("selectC_en{b}_summary.txt", "Averaged weights and dev-chosen checkpoints: dev vs test", "selectC", "v24"),
    ("calibC_en{b}_summary.txt", "Script-bias calibration b on the real dev set, dev size, MUSAN vs real", "calibC", "v25"),
    ("paretoC_en{b}_summary.txt", "Cost of every fix: far-field vs close-talk (IHM), mixed utterances", "paretoC", "v26"),
    ("comboC_en{b}_summary.txt", "Dev-chosen seed + lock, offline and real streaming", "comboC/streamC", "v27"),
    ("singleC_en{b}_summary.txt", "One training run: guarded checkpoint pick + lock, 95% intervals", "singleC", "v28-v29"),
    ("esC_en{b}_summary.txt", "Real-dev monitor every epoch: dev curves, picks, early stopping (v30 rule)", "esB/esC", "v30-v31"),
    ("baseC_en{b}_summary.txt", "Baselines: external LID mask (VoxLingua107), oracle mask, Spearman interval", "baseC", "v32-v33"),
    ("extraC_en{b}_summary.txt", "Second LID, LID from the first seconds, Typhoon, per microphone", "extraC", "v34"),
    ("esR_en{b}_summary.txt", "Corrected online early stopping, re-run on devmon.jsonl", "esR", "v35"),
    ("extraD_en{b}_summary.txt", "FINAL test tables: LIDs, MMS, prefixes, fusion, per mic, Typhoon, paired bootstrap", "scoreD/mmsD", "v35-v38"),
    ("extraE_dev_summary.txt", "FINAL dev tables: the same comparison on the real dev sets (replication)", "devE", "v36-v38"),
)

_PROGRESS = re.compile(r"^\s*\d+\s*/\s*\d+\s*$|\|[#█▏▎▍▌▋▊▉ ]{5,}\||it/s\]|s/it\]")
_WARN = re.compile(r"(^!!|Traceback|Error:|FAIL)")


def clean(text: str) -> str:
    out = []
    for line in text.replace("\r\n", "\n").split("\n"):
        if "\r" in line:
            line = line.split("\r")[-1]
        line = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", line)
        if _PROGRESS.search(line):
            continue
        out.append(line.rstrip())
    while out and not out[-1]:
        out.pop()
    return "\n".join(out)


def _stamp(path: str) -> str:
    st = os.stat(path)
    t = dt.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M")
    return f"{st.st_size:,} bytes, modified {t}"


def _read(path: str, max_kb: int = 0) -> str:
    with open(path, encoding="utf-8", errors="replace") as f:
        text = clean(f.read())
    if max_kb and len(text) > max_kb * 1024:
        keep = max_kb * 512
        text = text[:keep] + f"\n\n[... {len(text) - 2 * keep:,} characters cut ...]\n\n" + text[-keep:]
    return text


def _box(title: str) -> str:
    bar = "=" * 100
    return f"\n\n{bar}\n{title}\n{bar}\n"


def _section(n: int, title: str, path: str, stage: str, version: str) -> str:
    return (f"\n\n{'#' * 100}\n# {n:02d}. {title}\n# file: {os.path.basename(path)}  ({_stamp(path)})\n"
            f"# stage: killtest.sh {stage}   code: {version}\n{'#' * 100}\n")


def _inventory(work: str, b: str) -> List[str]:
    L = []
    files = sorted(p for p in glob.glob(os.path.join(work, "*")) if os.path.isfile(p))
    L.append(f"Files directly in {work}: {len(files)}")
    for p in files:
        L.append(f"  {os.path.basename(p):<42} {os.path.getsize(p):>14,} bytes")
    exps = sorted(glob.glob(os.path.join(work, "exp", "*")))
    if exps:
        L.append(f"\nTrained models in exp/: {len(exps)}")
        L.append(f"  {'model':<26} final.nemo  checkpoints  devmon epochs  early-stopping picks")
        for e in exps:
            if not os.path.isdir(e):
                continue
            name = os.path.basename(e)
            fin = "yes" if os.path.exists(os.path.join(e, "final.nemo")) else "-"
            ck = len(glob.glob(os.path.join(e, "*.nemo"))) - (fin == "yes")
            dm = os.path.join(e, "devmon.jsonl")
            nd = sum(1 for l in open(dm, encoding="utf-8") if l.strip()) if os.path.exists(dm) else 0
            pk = os.path.join(e, "esmon_picks.json")
            picks = ""
            if os.path.exists(pk):
                try:
                    picks = json.dumps(json.load(open(pk, encoding="utf-8")))
                except ValueError:
                    picks = "(unreadable)"
            L.append(f"  {name:<26} {fin:<11} {ck:>11}  {nd or '-':>13}  {picks}")
    lid = sorted(glob.glob(os.path.join(work, "lid_*.jsonl")))
    if lid:
        L.append("\nLanguage-identification outputs:")
        for p in lid:
            n = sum(1 for l in open(p, encoding="utf-8", errors="replace") if l.strip())
            L.append(f"  {os.path.basename(p):<34} {n:>7} utterances")
    d = os.path.join(work, "dumps")
    if os.path.isdir(d):
        n = len(glob.glob(os.path.join(d, "*", "*", "meta.json")))
        L.append(f"\nFrame-level dumps: {n} (dumps/<model>/<set>/), not copied into this file")
    return L


def _iter_lines(path: str):
    """Lines of a possibly huge log, read as a stream, progress bars and carriage returns removed."""
    with open(path, encoding="utf-8", errors="replace") as f:
        for raw in f:
            line = raw.rstrip("\n").split("\r")[-1]
            line = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", line).rstrip()
            if not _PROGRESS.search(line):
                yield line


def _log_index(paths: List[str]) -> List[str]:
    L = [f"{len(paths)} logs. For each: size, then its warning lines ('!!', Traceback, Error:, FAIL), "
         "deduplicated, at most 8."]
    for p in paths:
        seen, warn = set(), []
        try:
            for l in _iter_lines(p):
                s = l.strip()
                if _WARN.search(s) and s not in seen:
                    seen.add(s)
                    warn.append(s[:220])
        except OSError:
            continue
        L.append(f"\n  {p}  ({_stamp(p)}; {len(warn)} distinct warning lines)")
        L += [f"      {w}" for w in warn[:8]]
    return L


def _tail(path: str, n: int) -> Tuple[List[str], int]:
    from collections import deque

    q, k = deque(maxlen=n), 0
    for l in _iter_lines(path):
        q.append(l)
        k += 1
    return list(q), k


def collect(work: str, repo: Optional[str], b: str = "20", max_kb: int = 0, tail: int = 60) -> str:
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    head = [
        "ALL_RESULTS.txt: every result written by the scriptleak code, gathered by `python -m scriptleak.collect`",
        f"generated {now} from W = {work}" + (f", repository = {repo}" if repo else ""),
        "Project: script leakage in a compact bilingual Thai-English streaming ASR (NeMo FastConformer hybrid,",
        "~115M, Porjai Thai 300 h + LibriSpeech 20%); tests LOTUSDIS (Thai, 5 mics) and AMI (English, SDM/IHM).",
        "Leak = share of utterances with a letter of the other script. Th>L = Thai speech written in Latin,",
        "En>Th = English speech written in Thai script. CER for Thai with spaces removed, WER for English.",
        "The research summary (questions, hypotheses, conclusions) is README.md; a hand-written digest is",
        "docs/RESULTS_DIGEST.txt.",
    ]
    body, found, missing = [], [], []
    known = set()
    for i, (name, title, stage, version) in enumerate(STAGES, 1):
        fn = name.format(b=b)
        known.add(fn)
        p = os.path.join(work, fn)
        if os.path.exists(p):
            found.append(fn)
            body.append(_section(i, title, p, stage, version) + _read(p, max_kb))
        else:
            missing.append(f"{fn}  ({stage})")
    others = sorted(p for p in glob.glob(os.path.join(work, "*.txt")) + glob.glob(os.path.join(work, "results", "**", "*.txt"),
                                                                                    recursive=True)
                    if os.path.basename(p) not in known and os.path.basename(p) != "ALL_RESULTS.txt")
    if others:
        body.append(_box("OTHER RESULT FILES IN $W (not tied to a known stage)"))
        for j, p in enumerate(others, 1):
            body.append(_section(100 + j, os.path.relpath(p, work), p, "?", "?") + _read(p, max_kb))
    body.append(_box("INVENTORY"))
    body.append("\n".join(_inventory(work, b)))
    logs = sorted(glob.glob(os.path.join(work, "logs", "*.log")))
    repo_logs = []
    if repo:  # the repository folder and its parent (realdiag.log was written there)
        for d in (repo, os.path.dirname(os.path.abspath(repo))):
            repo_logs += sorted(glob.glob(os.path.join(d, "*.log")))
    body.append(_box("LOG INDEX ($W/logs and the repository folder)"))
    body.append("\n".join(_log_index(logs + repo_logs)))
    if repo_logs:
        body.append(_box(f"LAST {tail} LINES OF EACH LOG IN THE REPOSITORY FOLDER (prepare, audit, split, mix, ...)"))
        for p in repo_logs:
            lines, k = _tail(p, tail)
            body.append(f"\n----- {p} ({_stamp(p)}, {k} lines) -----\n" + "\n".join(lines))
    toc = ["", "Contents:"] + [f"  {i:02d}. {fn}" for i, fn in enumerate(found, 1)]
    if missing:
        toc += ["", "Not found (stage not run on this machine, or file removed):"] + [f"  - {m}" for m in missing]
    if others:
        toc += ["", f"Plus {len(others)} other result files, an inventory and a log index."]
    return "\n".join(head + toc) + "".join(body) + "\n\n(end)\n"


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--work", default=os.environ.get("W"))
    p.add_argument("--repo", default=".", help="folder with prepare.log, audit.log ...; its parent is read too ('' to skip)")
    p.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    p.add_argument("--out", default=None, help="default: $W/ALL_RESULTS.txt")
    p.add_argument("--max-kb", type=int, default=0, help="cut each file to this many KB (0 = keep whole)")
    p.add_argument("--tail", type=int, default=60)
    a = p.parse_args(argv)
    if not a.work or not os.path.isdir(a.work):
        p.error("--work (or $W) must be an existing folder")
    text = collect(a.work, a.repo or None, a.b_pct, a.max_kb, a.tail)
    out = a.out or os.path.join(a.work, "ALL_RESULTS.txt")
    with open(out, "w", encoding="utf-8") as f:
        f.write(text)
    print(f"wrote {out}: {len(text):,} characters, {text.count(chr(10)):,} lines")
    return 0


if __name__ == "__main__":
    sys.exit(main())
