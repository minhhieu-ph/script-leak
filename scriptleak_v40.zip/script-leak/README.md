# scriptleak: rò chữ viết trong ASR song ngữ Thái–Anh streaming nhỏ gọn

Đây là bản tóm tắt nghiên cứu, cập nhật ngày 27/11/2026 với code v40. Bảng gốc của mọi giai đoạn nằm trong
`ALL_RESULTS.txt`, do code sinh ra bằng `bash scripts/killtest.sh collect`. Bản tóm tắt viết tay theo
từng giai đoạn nằm trong [`docs/RESULTS_DIGEST.txt`](docs/RESULTS_DIGEST.txt). Hướng dẫn cài đặt và chạy từng bước nằm trong
[`docs/USAGE.md`](docs/USAGE.md) (README cũ đến v38).

**Tóm tắt một đoạn.** Một model ASR song ngữ nhỏ gọn Thái–Anh (NeMo FastConformer hybrid, khoảng 115M
tham số, cache-aware streaming) đôi khi viết cả câu tiếng Thái bằng chữ Latin, hoặc cả câu tiếng Anh bằng
chữ Thái. Trên âm thanh hội thoại thật, mức rò là 13–51% tùy seed và checkpoint, dù cùng công thức huấn
luyện. Đánh giá bằng nhiễu tổng hợp không dự đoán được điều này (Spearman −0,02). Nguyên nhân là model đoán
sai ngôn ngữ ở mức câu khi gặp âm thanh khác miền. Giải pháp là tách quyết định ngôn ngữ ra khỏi model ASR:
- **LID ngoài một mình** giảm rò 89–98%.
- **Gộp LID với niềm tin chữ viết của chính model**, không tinh chỉnh tham số nào, giảm thêm CER 0,7–1,1
  điểm so với greedy. Kết quả này đứng vững trên cả test lẫn dev.
- **Khi không được thêm model**, đo dev thật sau mỗi epoch rồi chọn checkpoint: rò giảm 53–59%.

---

## 1. Ràng buộc

- Chỉ dùng dữ liệu và model **công khai**, hoặc model tự huấn luyện từ dữ liệu công khai. Bài toán xuất phát
  từ thực tế công ty, nhưng không dùng model hay dữ liệu của công ty; công ty chỉ cấp GPU.
- Kubeflow (8× A100 40GB, ổ `/asr-shared`) bị xóa trước 16h ngày 27/11/2026. Sau mốc đó chỉ còn SPACE
  (1× B300, nền tảng nội bộ), và **không được mang log hay kết quả từ SPACE ra ngoài**. Vì vậy bài chỉ dùng
  các kết quả đã chạy xong trên Kubeflow, tức những gì có trong `ALL_RESULTS.txt`.
- Mục tiêu: Interspeech 2027, bài 4 trang. Hạn nộp 9/2/2027 (cổng mở 19/1), kháng nghị 13–20/4, kết quả
  2/6/2027. Đường lui: bản tạp chí (CSL hoặc Speech Communication) thêm cặp Mandarin–Anh, hoặc ICASSP 2028.

## 2. Câu hỏi nghiên cứu

1. **Hiện tượng và cách đo.** Trên âm thanh thật, rò chữ viết xảy ra bao nhiêu, theo cả hai chiều? Cách
   đánh giá thông thường (nhiễu tổng hợp, một seed) có đo đúng không?
2. **Nguyên nhân.** Rò sinh ra ở đâu và vì sao? Các khả năng: điều kiện âm học, khởi tạo, chia nhỏ xác
   suất, quỹ đạo huấn luyện.
3. **Giải pháp.** Có cách nào rẻ, không huấn luyện lại hoặc chỉ một lần huấn luyện, giảm rò mà không mất độ
   chính xác và dùng được trong streaming?

## 3. Thiết lập

| Thành phần | Cấu hình |
|---|---|
| Model | NeMo FastConformer hybrid transducer + CTC, cache-aware, ~115M tham số; tokenizer gộp BPE Thái 1024 + Anh 256; encoder khởi tạo từ model streaming tiếng Anh công khai của NVIDIA |
| Huấn luyện | Porjai (Thai Dialect Corpus, giọng trung tâm) ~300 giờ + LibriSpeech bằng 20% số giờ; hai khối đơn ngữ tách rời; 50 epoch; 8× A100 |
| Công thức | `clean` (không nhiễu), `both` (MUSAN ở cả hai khối), `th` / `en` (nhiễu ở một khối), `rir` (vang OpenSLR 28 + MUSAN, cân bằng), `p10_*` (10% câu có nhiễu), `noinit`, adapt 2 giai đoạn; 3 seed cho mỗi công thức chính |
| Test tổng hợp | Porjai test + MUSAN theo SNR, phương ngữ, méo chưa thấy, probe không lời nói |
| Test thật | LOTUSDIS test: 5 mic, 8.370 câu thuần Thái + 1.375 câu trộn. AMI eval: thu xa SDM 4.902 câu, thu gần IHM |
| Dev thật | LOTUSDIS validation 3.735 câu; AMI dev 5.301 câu |
| Metric | Rò = tỉ lệ câu có chữ của hệ kia (chỉ tính câu tham chiếu thuần một hệ), báo riêng Th>L và En>Th; CER Thái bỏ khoảng trắng; WER Anh |
| Thống kê | Bootstrap theo cụm người nói (LOTUSDIS) và cuộc họp (AMI), ghép cặp giữa phương pháp, gộp seed; Spearman có bootstrap và hoán vị |
| LID ngoài | SpeechBrain VoxLingua107 ECAPA (~20M, CPU); MMS-LID-126 (1B, GPU) |
| So sánh bối cảnh | Typhoon ASR Realtime (công khai, đơn ngữ Thái, ~10k giờ) |

## 4. Giả thuyết, thực nghiệm và kết luận

| Mã | Giả thuyết | Thực nghiệm | Kết quả | Kết luận |
|---|---|---|---|---|
| H1 | Xác suất bị chia nhỏ giữa nhiều token Thái nên token Latin lọt lên | Phân tích khung CTC; so CTC với transducer; giải mã `marg` | Tổng Thái > tổng Latin chỉ ở 0,3–1,7% khung rò; khối lượng tại khung rò: Latin 0,90, Thái 0,02; `marg` không đổi rò | **Bác bỏ**: model tự tin chọn Latin |
| G1a | Model dùng điều kiện âm học làm tín hiệu ngôn ngữ | Nhiễu chỉ ở khối Anh, chỉ ở khối Thái, hoặc cả hai | Nhiễu ở khối nào thì rò về khối đó; cân bằng thì ≤ 1,2% trên MUSAN | **Ủng hộ** trong họ nhiễu MUSAN; không đủ cho âm thanh thật |
| G1b | Dữ liệu không nhiễu: khối vốn ồn hơn kéo âm thanh ồn về phía nó | 3 seed `clean` + `base` | Chiều rò đổi theo seed và epoch | **Bác bỏ** |
| G2a | Encoder khởi tạo tiếng Anh tự ngả về tiếng Anh | So các công thức cùng encoder; `noinit` | Model cân bằng hết rò trên MUSAN; `noinit` không hội tụ | **Không phải cơ chế chính** (thiếu đối chứng) |
| G2b | Đường tắt từ giai đoạn dài không gỡ được | Adapt 5/15 epoch, gỡ và cấy | MUSAN 15,5% → 1,2–1,5%; thật 43,3% → 16,7–27,4% | **Bác bỏ**: gỡ được một phần |
| G3 | Chặn đoạn rò theo độ tin cậy | Đặc trưng span; AUC | AUC 0,93–0,95, nhưng giữ 97% tiếng Anh thật thì chỉ chặn 29–35% | **Không đủ** |
| G4 | Chặn theo độ hợp lý ngôn ngữ | n-gram ký tự, từ điển | 80% từ rò là từ tiếng Anh có thật | **Không tách được** |
| G5 | Không có lời nói thì model viết tiếng Anh | Im lặng, nhiễu, xì xào, nhạc, nói nhỏ | Nhiễu, xì xào < 2–4%; nhạc 5–19% | **Bác bỏ** với âm thanh không lời |
| G6 | Khối thiểu số càng nhỏ, đường tắt càng mạnh | en05 vs en20 (1 seed mỗi mức) | 8,4% vs 5,6% | **Chưa kết luận** (seed lấn át) |
| G7 | Đường tắt theo kênh, người nói, giọng | — | — | **Chưa thử** (thiếu nhãn) |
| G8 | Tăng cường cân bằng (`rir`) là cách sửa ổn định | `rir` × 3 seed, test thật | 12,9 / 21,7 / 45,9% | **Bác bỏ** với checkpoint cuối; chọn bằng dev thì 6,4–7,3% |
| G9 | Rò tái lập theo ngữ cảnh | Trùng câu giữa seed, qua mic, theo người nói | Gấp 6–700 lần ngẫu nhiên, kiểu lồng nhau; qua mic lift 1,0–1,4; người nói AMI r = 0,76–0,94 | **Một phần**: theo bản ghi/kênh và người nói, không theo nội dung |
| G10 | Rò chỉ là hệ quả của nhận dạng kém | Rò theo độ khó câu, theo mic | Câu dễ vẫn rò; mic xa (CER 89%) rò ~5%, mic gần (CER 63%) rò 37% | **Bác bỏ** |

**Chẩn đoán cuối:** model hoạt động như "đoán ngôn ngữ cả câu rồi nhận dạng". Rò là cú đoán sai đó khi
âm thanh khác miền. Bằng chứng: chữ sai hệ (18%) ≈ câu rò (18%); 99,4% chữ Latin là rò; model phiên âm từ
tiếng Anh sang chữ Thái thay vì chuyển mã. Quyết định ngôn ngữ của chính model chỉ đúng 26–63% câu Anh.

## 5. Phát hiện chính

1. **Nhiễu tổng hợp đánh giá sai.** Trên MUSAN, 6/6 model cân bằng rò dưới 1,2%; trên âm thanh thật chúng
   rò 13–51%. Spearman giữa MUSAN và thật trên 12 model là −0,02, 95% [−0,59; +0,64], p = 0,96. Chọn seed
   theo MUSAN thì với `clean` ra đúng seed tệ nhất (51,1%).
2. **Rò là bốc thăm theo seed và checkpoint.** Cùng công thức `rir`, 3 seed rò 12,9%, 21,7% và 45,9%; bất
   định do seed lớn gấp 2–5 lần khoảng tin cậy của tập test. Trong một lần train, rò có thể nhảy 39% → 82% →
   39% hoặc đổi chiều, trong khi CER/WER gần như đứng yên.
3. **Rò là lật chữ viết cả câu**, cao nhất ở mic chất lượng khá: mic cài áo rò 37%, mic xa 10 m ~5% vì
   model gần như không viết ra gì.
4. **Streaming thật cho kết quả bằng offline**: mọi số tổng hợp lệch ≤ 0,2 điểm.
5. **LID ngoài và model ASR sai ở hai chỗ khác nhau.** Ở mic xa, VoxLingua chỉ đúng 54–58% câu Thái còn lock
   của model đúng 95–96%. Ở mic gần thì ngược lại: LID 95–97%, model 66–82%.

## 6. Giải pháp và kết quả

Bảng dưới là model final, trung bình 3 seed, trên test. Δ là chênh lệch so với greedy, khoảng tin cậy 95%
từ bootstrap ghép cặp theo người nói/cuộc họp.

| Công thức | Greedy: rò / CER | LID VoxLingua: rò / CER | **Fusion**: rò / CER | Δ CER fusion, test | Δ CER fusion, dev | Oracle CER |
|---|---|---|---|---|---|---|
| clean | 39,0% / 78,6 | 2,3% / 78,2 | 5,5% / 77,5 | −1,1 [−1,4; −0,8] | −0,8 [−1,0; −0,6] | 77,2 |
| both | 25,3% / 73,3 | 1,5% / 73,2 | 3,5% / 72,2 | −1,1 [−1,3; −0,8] | −0,7 [−0,9; −0,5] | 72,0 |
| rir | 26,8% / 72,2 | 2,9% / 73,1 | 5,0% / 71,2 | −0,9 [−1,2; −0,6] | −0,8 [−1,1; −0,6] | 70,8 |
| th | 17,3% / 66,5 | 0,4% / 67,6 | 1,7% / 66,5 | −0,0 [−0,2; +0,1] | +0,1 [0,0; +0,2] | 66,3 |

- **Giải pháp chính: tách quyết định ngôn ngữ ra khỏi model ASR.**
  - *LID một mình* (chặn token của hệ kia theo LID ở mức câu) cho rò thấp nhất. Nhưng CER tệ hơn greedy ở
    rir/th trên test và ở cả 4 công thức trên dev (+0,5 đến +2,5), vì LID sai ở mic xa làm câu ra rỗng.
  - *Fusion*: P(Anh) = trung bình của LID và tỉ lệ khối lượng chữ Latin của model, ngưỡng 0,5, không tinh
    chỉnh. CER thấp hơn LID 0,7–1,8 điểm (test) và 1,3–3,4 điểm (dev); đổi lại rò tăng 1,3–3,3 điểm.
  - Với LID ~20M tham số, fusion cho CER ngang hoặc tốt hơn MMS 1B dùng một mình.
  - LID chỉ cần 2 giây đầu câu, nên dùng được trong streaming. Tuy vậy fusion 2 giây yếu hơn trên dev.
  - Không cần huấn luyện lại và hết phụ thuộc seed. Trần là oracle: chỉ giảm CER 1,0–1,4 điểm, vì sửa hệ
    chữ không cứu được nội dung câu.
- **Không thêm model: chọn checkpoint bằng dev thật.**
  - *Chọn thưa* (5–10 epoch một lần; dev CER/WER ≤ final + 1 điểm, rò dev thấp nhất) rồi lock: rò giảm
    15–71% (rir 26,8 → 7,7%).
  - *Đo dev sau mỗi epoch* (1.000 câu): clean 39,4 → 18,6%, rir 18,1 → 7,5%; CER còn tốt hơn final 6,6–14,1
    điểm; khoảng chênh giữa seed co 40,8 → 8,4 điểm (clean) và 18,7 → 1,8 điểm (rir).
  - *Dừng sớm* (luật sửa ở v35): dừng ở epoch 15–19 trên 50, tức bớt 62–70% thời gian train. Mới kiểm
    chứng trên test được 2/6 run.

## 7. Đóng góp

Theo hiểu biết của chúng tôi, bài có các đóng góp sau:
1. Phân tích có hệ thống đầu tiên về rò chữ viết hai chiều ở ASR streaming song ngữ nhỏ gọn Thái–Anh trên
   âm thanh hội thoại thật, thu xa và thu gần, nhiều seed, có khoảng tin cậy.
2. Bằng chứng rằng đánh giá bằng nhiễu tổng hợp không dự đoán được rò thật, thậm chí chọn nhầm model tệ nhất.
3. Bằng chứng rằng rò bất ổn theo seed và checkpoint trong khi CER/WER ổn định, nên so công thức bằng một
   seed là không đáng tin.
4. Đặc trưng hóa dạng lỗi (lật chữ viết cả câu, cao nhất ở mic khá), kèm các kết quả âm có kiểm soát.
5. Giải pháp thực tế đã kiểm chứng:
   - LID ngoài giảm rò 89–98%.
   - Fusion không tham số giảm CER khoảng 1 điểm so với greedy, lặp lại trên dev.
   - Đo dev mỗi epoch rồi chọn checkpoint giảm rò 53–59%.

Khi viết, nói nhẹ. Không gọi LID-mask hay chọn checkpoint là "phương pháp mới": đã có Watanabe et al. 2017,
Kim & Seltzer 2018. Gộp điểm LID cũng là thực hành quen thuộc. Chỉ nói CER giảm khoảng 1 điểm, không nói sửa
hệ chữ cứu được nội dung, và không nói "chứng minh không tương quan".

## 8. Kết quả âm (giữ trong bài, kèm lý do)

| Cách sửa | Kết quả | Vì sao không dùng |
|---|---|---|
| Hiệu chỉnh độ lệch chữ viết b, chọn trên dev | Rò giảm ~40% nhưng WER AMI thu xa +9–12 điểm; trên thu gần WER +16–19 và En>Th 3 → 14% | Rò không phải độ lệch prior cố định; không chuyển được giữa điều kiện âm |
| Trung bình trọng số checkpoint | rir_s2 45,9 → 29,4% nhưng clean_s1 39,0 → 50,9% | Không ổn định |
| Giải mã `marg` | 39,0 → 38,9% | Khớp với việc bác bỏ H1 |
| Khóa sớm theo 12/25 khung của chính model | Gần như không giảm, CER tăng | Niềm tin của model trong 1–2 giây chưa đủ; LID ngoài thì đủ |
| Chặn theo độ tin cậy (G3), theo LM (G4) | Chặn 29–35%; không tách được | Model rò ra tiếng Anh "hợp lý" |
| Lock theo xác suất của chính model | Chỉ giảm 14–23% | Quyết định đó đúng 26–63% câu Anh |
| Dừng sớm online bản v30 | Không bao giờ dừng | Lỗi thiết kế: so với cả epoch 1–9 không lưu checkpoint; đã sửa ở v35 |

## 9. Hạn chế

- **Độ chính xác tuyệt đối thấp**: CER Thái 65–90%, WER Anh 58–87% trên âm thanh thật, vì model huấn luyện
  trên giọng đọc sạch nhưng chạy trên hội thoại. Ngay cả oracle cũng chỉ giảm CER 1–1,4 điểm.
- **Phạm vi hẹp**: một cặp ngôn ngữ, một kiến trúc, một cỡ model. Model không chuyển mã trong câu nên chưa
  đo được cái giá thật của khóa mức câu trên câu trộn.
- **Ít seed**: 3 seed mỗi công thức. Spearman với n = 12 có khoảng tin cậy rộng. Bootstrap chỉ tính bất
  định của tập test.
- **Dev cùng miền với test.** Chưa thử dev khác miền.
- **Streaming**: khóa chỉ sửa bản cuối câu, bản tạm thời vẫn có thể rò. Fusion 2 giây yếu hơn trên dev.
- **Dừng sớm chỉ kiểm chứng một phần**: luật sửa viết sau khi thấy lỗi; checkpoint không được chọn đã bị
  xóa nên chỉ có số test ở 2/6 run.
- **Fusion là ý tưởng hình thành sau khi xem bảng theo mic trên test.** Không có tham số nào được tinh chỉnh
  và kết quả lặp lại trên dev, nhưng vẫn là phân tích hậu kiểm.
- **Metric**: rò thấp có thể che câu rỗng, nên mọi bảng đều kèm CER/WER. Chưa báo cáo SFR. Chưa kiểm tra
  quy ước chính tả từ mượn của Porjai/LOTUSDIS.
- **Thiết kế**: `base` 40 epoch so với 50; `noinit` không hội tụ; adapt chỉ 1 lần chạy mỗi loại; chưa có
  nhãn chủ đề.

## 10. Việc còn lại (không cần GPU)

- Bản nháp tiếng Anh 4 trang + 2 trang tài liệu tham khảo trước 19/1/2027.
- Tính SFR theo đúng định nghĩa của bài gốc. Có thể tính offline từ `baselines*_en20.json` nếu đủ trường;
  nếu không thì ghi vào hạn chế.
- Kiểm tra quy ước chính tả từ mượn trước khi viết về câu trộn.
- Bản mở rộng (tạp chí): cặp Mandarin–Anh, đảo vai đa số/thiểu số.

## 11. Tái lập: các giai đoạn và file kết quả

Mọi giai đoạn chạy bằng `bash scripts/killtest.sh STAGE` sau khi `export D=$PWD/data W=$PWD/data/work`
(chi tiết trong `docs/USAGE.md`).

| Giai đoạn | Phiên bản | Việc | File kết quả trong `$W` |
|---|---|---|---|
| prepare, audit, split, mix, tokenizer, train05/20, dump, results, probeA | v1–v16 | Giai đoạn A: dữ liệu, huấn luyện en05/en20, rò tổng hợp, H1, quét phương pháp, G3/G4 | `results_summary.txt`, `probeA_summary.txt`, `results/en*/` |
| noisefloor, prepB, trainB, evalB, nightB | v16–v18 | Giai đoạn B: công thức nhiễu | `phaseB_en20_summary.txt` |
| realprep, realB, probeC, adaptB, nightC, marathon, getrir, prepR, marathon2 | v17–v23 | Âm thanh thật, probe không lời, adapt, rir, seed | `real_en20_summary.txt`, `probeC_en20_summary.txt` |
| seedC, realdev, selectC | v24 | Trùng câu giữa seed, khoảng tin cậy, dev thật, chọn checkpoint | `seedC_en20_summary.txt`, `selectC_en20_summary.txt`, `selection_en20.json` |
| calibC, ihmC, paretoC | v25–v26 | Hiệu chỉnh b, AMI thu gần, giá của từng cách sửa | `calibC_en20_summary.txt`, `paretoC_en20_summary.txt` |
| comboC, streamC, singleC | v27–v29 | Dev chọn + lock, streaming thật, một lần huấn luyện | `comboC_en20_summary.txt`, `singleC_en20_summary.txt`, `singlerun_en20.json` |
| esB, esC | v30–v31 | Huấn luyện lại có đo dev mỗi epoch | `exp/*_es/devmon.jsonl`, `esC_en20_summary.txt` |
| baseC, extraC | v32–v34 | LID ngoài, oracle, MMS, LID N giây, Typhoon, theo mic | `baseC_en20_summary.txt`, `extraC_en20_summary.txt`, `lid_*.jsonl`, `typhoon_*.jsonl` |
| esR, scoreD, mmsD, devE | v35–v38 | Dừng sớm đã sửa, fusion, MMS, kiểm chứng dev, bootstrap | `esR_en20_summary.txt`, `extraD_en20_summary.txt`, `extraE_dev_summary.txt`, `baselines3_en20.json`, `baselines_dev_en20.json` |

Gom tất cả: `bash scripts/killtest.sh collect` (v39–v40, CPU, vài giây) ghi `$W/ALL_RESULTS.txt` và chép ra thư
mục repo. File gồm summary của từng giai đoạn theo thứ tự chạy, các file kết quả khác, danh mục model và
file, chỉ mục log kèm dòng cảnh báo, và phần cuối của các log trong thư mục repo.

Gói kết quả tải về máy cá nhân trước khi mất Kubeflow: `scriptleak_results_final.tgz`. Gói gồm
`*summary*.txt`, `*.json`, `lid_*.jsonl`, `typhoon_*.jsonl`, `logs/`, `exp/*/devmon.jsonl`,
`exp/*/esmon_picks.json`, `exp/*/resolved_config.yaml`, `tokenizers/` và `real/*.jsonl`. Dump xác suất theo
khung **không** có trong gói (quá lớn), nên mọi phân tích cần dump đều không chạy lại được.

## 12. Cấu trúc code

- `scriptleak/`: phân tích, chỉ cần numpy/scipy.
  - `decoding` (greedy, lock, mask, bias, marg)
  - `baselines` (LID, fusion, bootstrap theo cụm)
  - `esmon` (chọn checkpoint, dừng sớm)
  - `pareto`, `calib`, `selection`, `singlerun`, `combo`
  - `seedvar`, `realstats`, `realdiag`, `retention`, `spans`
  - …
- `scriptleak/nemo_tools/`: phần cần NeMo/GPU.
  - `train` (kèm `devmon` đo dev mỗi epoch)
  - `dump_logprobs`, `stream_dump`, `avg_ckpt`, `typhoon_eval`, `build_tokenizer`, `check_env`
- `scripts/killtest.sh`: mọi giai đoạn. `scripts/setup_env.sh`, `scripts/download_data.sh`.
- `scriptleak/collect.py`: gom mọi kết quả vào `ALL_RESULTS.txt` (v39).
- `tests/`: `python -m pytest -q` (137 passed, 2 skipped ở v39).

## 13. Ghi chú quy trình (để tiếp tục sau này)

- **Đóng gói code**: mỗi lần sửa code, đóng gói thành `scriptleak_vN.zip` (N tăng dần), thư mục gốc bên
  trong là `script-leak`.
- **Cập nhật trên máy chạy**: upload zip lên GitHub (`minhhieu-ph/script-leak`), `git pull`, chuyển zip ra
  thư mục cha rồi `unzip -o`.
  - Không `unzip -o` đè lên `script-leak` khi một stage bash đang chạy, vì bash đọc script dần dần. Khi đó
    giải nén vào thư mục riêng.
  - `git pull` chỉ thêm file zip thì an toàn.
- **Nguyên tắc viết**: giả thuyết yếu hoặc bị bác bỏ vẫn giữ trong bài, nêu rõ đã thử gì, vì sao chưa đủ,
  và thực tế nào ngăn cản.
- **Khi cần nhớ lại toàn bộ dự án**: gửi README.md này cùng `ALL_RESULTS.txt` (và `docs/RESULTS_DIGEST.txt`).
