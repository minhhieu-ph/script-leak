"""Convert public corpora to raw NeMo-style manifests.

These manifests are *raw*: run `scriptleak.audit` on them afterwards to get
the spoken-form subset.

  python -m scriptleak.prepare librispeech --root /data/LibriSpeech \
      --subsets train-clean-100 train-clean-360 --out en_train.raw.jsonl

  python -m scriptleak.prepare aishell1 --root /data/data_aishell \
      --split train --out zh_train.raw.jsonl

  python -m scriptleak.prepare hf --dataset CMKL/Porjai-Thai-voice-dataset-central \
      --split train --text-col sentence --audio-out /data/porjai_central/wav \
      --out th_central.raw.jsonl --copy-cols speaker_id

  python -m scriptleak.prepare hf-columns --dataset CMKL/Porjai-Thai-voice-dataset-korat

  python -m scriptleak.prepare hf --dataset nectec/LOTUSDIS --split test \
      --data-files "data/test-*" --text-col sentence --copy-cols speaker_id mic \
      --audio-out /data/lotusdis/test/wav --out lotus_test.raw.jsonl

  python -m scriptleak.prepare gigaspeech2 --tsv $D/gigaspeech2/data/th/test.tsv \
      --audio-dir $D/gigaspeech2/data/th/test --out th_gs2_test.raw.jsonl

  python -m scriptleak.prepare tsv --tsv meta.tsv --audio-root /data/wav \
      --path-col path --text-col text --out any.raw.jsonl

The hf converter writes 16 kHz mono wav files.
Needs soundfile to read durations (and `datasets` for the hf converter).
"""

from __future__ import annotations

import argparse
import csv
import glob
import os
import sys
from typing import Callable, Dict, Iterator, List, Optional

import numpy as np

from .audio import resample, to_mono
from .manifest import read_manifest, write_manifest


def audio_duration(path: str) -> float:
    import soundfile as sf

    info = sf.info(path)
    return float(info.frames) / float(info.samplerate)


def librispeech_entries(root: str, subsets: List[str],
                        duration_fn: Callable[[str], float] = audio_duration) -> Iterator[Dict]:
    """LibriSpeech layout: <root>/<subset>/<spk>/<chap>/<spk>-<chap>.trans.txt
    with lines "<utt-id> <TEXT>" and audio <utt-id>.flac beside it."""
    for subset in subsets:
        pattern = os.path.join(root, subset, "*", "*", "*.trans.txt")
        files = sorted(glob.glob(pattern))
        if not files:
            raise FileNotFoundError(f"No transcripts match {pattern}")
        for trans in files:
            folder = os.path.dirname(trans)
            with open(trans, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    utt, _, text = line.partition(" ")
                    audio = os.path.join(folder, utt + ".flac")
                    yield {
                        "audio_filepath": audio,
                        "duration": duration_fn(audio),
                        "text": text,
                        "utt_id": utt,
                        "speaker": utt.split("-")[0],
                        "source": f"librispeech/{subset}",
                    }


def aishell1_entries(root: str, split: str,
                     duration_fn: Callable[[str], float] = audio_duration) -> Iterator[Dict]:
    """AISHELL-1 layout: <root>/transcript/aishell_transcript_v0.8.txt with
    lines "<utt-id> <words...>", audio at <root>/wav/<split>/<spk>/<utt-id>.wav."""
    trans_path = os.path.join(root, "transcript", "aishell_transcript_v0.8.txt")
    text_by_id: Dict[str, str] = {}
    with open(trans_path, "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split(maxsplit=1)
            if len(parts) == 2:
                text_by_id[parts[0]] = parts[1]
    wavs = sorted(glob.glob(os.path.join(root, "wav", split, "*", "*.wav")))
    if not wavs:
        raise FileNotFoundError(f"No wav files under {os.path.join(root, 'wav', split)}")
    for wav in wavs:
        utt = os.path.splitext(os.path.basename(wav))[0]
        if utt not in text_by_id:
            continue  # a few AISHELL-1 files have no transcript
        yield {
            "audio_filepath": wav,
            "duration": duration_fn(wav),
            "text": text_by_id[utt],
            "utt_id": utt,
            "speaker": os.path.basename(os.path.dirname(wav)),
            "source": f"aishell1/{split}",
        }


def tsv_entries(tsv: str, audio_root: str, path_col: str, text_col: str,
                copy_cols: List[str], delimiter: str = "\t",
                duration_fn: Callable[[str], float] = audio_duration) -> Iterator[Dict]:
    with open(tsv, "r", encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f, delimiter=delimiter):
            audio = os.path.join(audio_root, row[path_col]) if audio_root else row[path_col]
            entry = {"audio_filepath": audio, "duration": duration_fn(audio), "text": row[text_col]}
            for c in copy_cols:
                entry[c] = row.get(c)
            yield entry


AUDIO_EXTS = (".wav", ".flac", ".opus", ".ogg", ".mp3")


def gigaspeech2_entries(tsv: str, audio_dir: str,
                        duration_fn: Callable[[str], float] = audio_duration) -> Iterator[Dict]:
    """GigaSpeech 2 dev/test: a TSV of "<segment_id>\t<text>" and a tar of
    <segment_id>.<ext> audio files extracted somewhere under audio_dir."""
    by_id: Dict[str, str] = {}
    for root, _, files in os.walk(audio_dir):
        for name in files:
            stem, ext = os.path.splitext(name)
            if ext.lower() in AUDIO_EXTS:
                by_id[stem] = os.path.join(root, name)
    if not by_id:
        raise FileNotFoundError(f"No audio files ({', '.join(AUDIO_EXTS)}) under {audio_dir}")
    missing = 0
    with open(tsv, "r", encoding="utf-8") as f:
        for line in f:
            seg, sep, text = line.rstrip("\n").partition("\t")
            if not sep:
                continue
            if seg not in by_id:
                missing += 1
                continue
            yield {"audio_filepath": by_id[seg], "duration": duration_fn(by_id[seg]),
                   "text": text, "utt_id": seg, "source": "gigaspeech2"}
    if missing:
        print(f"warning: {missing} segments in {tsv} have no audio file", file=sys.stderr)


def _raw_audio(ds, audio_cols=None):
    """Turn off the `datasets` audio decoder (it needs torchcodec + ffmpeg in
    recent versions). Audio cells then come back as {"bytes", "path"} and we
    decode them with soundfile."""
    from datasets import Audio

    feats = getattr(ds, "features", None)
    names = [k for k, v in feats.items() if isinstance(v, Audio)] if feats else list(audio_cols or [])
    for name in names:
        ds = ds.cast_column(name, Audio(decode=False))
    return ds


def _read_audio_cell(cell):
    """(float32 samples, sampling rate) from an undecoded audio cell."""
    import io

    import soundfile as sf

    if isinstance(cell, dict) and cell.get("bytes"):
        return sf.read(io.BytesIO(cell["bytes"]), dtype="float32")
    if isinstance(cell, dict) and cell.get("path"):
        return sf.read(cell["path"], dtype="float32")
    if isinstance(cell, dict) and "array" in cell:  # already decoded
        return np.asarray(cell["array"], dtype=np.float32), int(cell["sampling_rate"])
    raise ValueError(f"Cannot read audio cell of type {type(cell).__name__}")


def _short(v):
    if isinstance(v, dict):
        return f"<{', '.join(v.keys())}>"
    if isinstance(v, (bytes, bytearray)):
        return f"<{len(v)} bytes>"
    return v


def hf_columns(dataset: str, config: Optional[str], split: str, rows: int = 3) -> List[Dict]:
    """The first rows (audio omitted) without downloading the whole dataset."""
    from datasets import load_dataset

    args = (dataset, config) if config else (dataset,)
    ds = _raw_audio(load_dataset(*args, split=split, streaming=True), ["audio"])
    out = []
    for i, row in enumerate(ds):
        if i >= rows:
            break
        out.append({k: _short(v) for k, v in row.items()})
    return out


def _load_hf(dataset: str, config: Optional[str], split: str, audio_col: str,
             data_files: Optional[str] = None):
    """data_files (a glob inside the repo, e.g. "data/test-*") downloads only
    the files of that split instead of every split of the dataset."""
    from datasets import load_dataset

    if data_files:
        # The dataset card still lists every split, so the split check would
        # fail ("ExpectedMoreSplitsError") although the files we asked for are fine.
        ds = load_dataset(dataset, data_files={split: data_files}, split=split,
                          verification_mode="no_checks")
    elif config:
        ds = load_dataset(dataset, config, split=split)
    else:
        ds = load_dataset(dataset, split=split)
    return _raw_audio(ds, [audio_col])


def _hf_worker(job: Dict) -> Dict:
    """Convert rows [start, end) and write one part manifest. Finished parts
    are skipped, so an interrupted run can simply be started again."""
    import soundfile as sf

    part = f"{job['out']}.part{job['k']:03d}"
    if os.path.exists(part):
        entries = list(read_manifest(part))
        return {"k": job["k"], "n": len(entries), "bad": 0,
                "hours": sum(e["duration"] for e in entries) / 3600.0, "skipped": True}
    ds = _load_hf(job["dataset"], job["config"], job["split"], job["audio_col"], job.get("data_files"))
    ds = ds.select(range(job["start"], job["end"]))
    sr_out = job["target_sr"]
    max_sec = job["max_hours"] * 3600.0 if job["max_hours"] else None
    total, bad, entries = 0.0, 0, []
    for off, row in enumerate(ds):
        if max_sec is not None and total >= max_sec:
            break
        i = job["start"] + off
        try:
            wav, sr = _read_audio_cell(row[job["audio_col"]])
            wav = resample(to_mono(np.asarray(wav, dtype=np.float32)), sr, sr_out)
        except Exception as e:  # one broken file must not stop a 700 h job
            bad += 1
            if bad <= 5:
                print(f"warning: row {i}: {e}", file=sys.stderr)
            continue
        path = os.path.join(job["audio_out"], f"{i // 10000:04d}", f"{job['split']}_{i:08d}.wav")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        sf.write(path, wav, sr_out, subtype="PCM_16")
        entry = {"audio_filepath": path, "duration": len(wav) / float(sr_out),
                 "text": row[job["text_col"]], "source": f"{job['dataset']}/{job['split']}"}
        for c in job["copy_cols"]:
            entry[c] = row.get(c)
        entries.append(entry)
        total += entry["duration"]
    write_manifest(part + ".tmp", entries)
    os.replace(part + ".tmp", part)
    return {"k": job["k"], "n": len(entries), "bad": bad, "hours": total / 3600.0, "skipped": False}


def hf_convert(dataset: str, config: Optional[str], split: str, audio_col: str, text_col: str,
               audio_out: str, out: str, copy_cols: List[str], limit: Optional[int] = None,
               target_sr: int = 16000, num_workers: int = 8,
               max_hours: Optional[float] = None, data_files: Optional[str] = None) -> int:
    """Any Hugging Face audio dataset -> 16 kHz mono 16-bit wav + manifest.

    The rows are cut into `num_workers` contiguous ranges that are converted in
    parallel. `max_hours` is split evenly over the ranges, so the kept subset
    is spread over the whole corpus rather than taken from its beginning."""
    import multiprocessing as mp

    ds = _load_hf(dataset, config, split, audio_col, data_files)  # downloads once, before forking
    for col in [text_col, audio_col] + list(copy_cols):
        if col not in ds.column_names:
            raise SystemExit(f"Column '{col}' not found. Columns: {ds.column_names}")
    n = len(ds) if limit is None else min(limit, len(ds))
    del ds
    num_workers = max(1, min(num_workers, n))
    os.makedirs(audio_out, exist_ok=True)
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    bounds = [n * k // num_workers for k in range(num_workers + 1)]
    jobs = [{"k": k, "start": bounds[k], "end": bounds[k + 1], "dataset": dataset, "config": config,
             "split": split, "audio_col": audio_col, "text_col": text_col, "audio_out": audio_out,
             "out": out, "copy_cols": list(copy_cols), "target_sr": target_sr,
             "max_hours": (max_hours / num_workers) if max_hours else None,
             "data_files": data_files}
            for k in range(num_workers)]
    if num_workers == 1:
        stats = [_hf_worker(jobs[0])]
    else:
        with mp.get_context("spawn").Pool(num_workers) as pool:
            stats = []
            for st in pool.imap_unordered(_hf_worker, jobs):
                stats.append(st)
                print(f"  part {st['k']:03d}: {st['n']} utterances, {st['hours']:.1f} h"
                      + (" (already done)" if st["skipped"] else ""), flush=True)
    total = 0
    with open(out, "w", encoding="utf-8") as fo:
        for k in range(num_workers):
            with open(f"{out}.part{k:03d}", "r", encoding="utf-8") as fi:
                for line in fi:
                    fo.write(line)
                    total += 1
    for k in range(num_workers):
        os.remove(f"{out}.part{k:03d}")
    bad = sum(s["bad"] for s in stats)
    print(f"{dataset}: {total} utterances, {sum(s['hours'] for s in stats):.1f} h"
          + (f", {bad} unreadable rows skipped" if bad else ""))
    return total


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="corpus", required=True)

    a = sub.add_parser("librispeech")
    a.add_argument("--root", required=True)
    a.add_argument("--subsets", nargs="+", required=True)
    a.add_argument("--out", required=True)

    a = sub.add_parser("aishell1")
    a.add_argument("--root", required=True)
    a.add_argument("--split", required=True, choices=["train", "dev", "test"])
    a.add_argument("--out", required=True)

    a = sub.add_parser("tsv")
    a.add_argument("--tsv", required=True)
    a.add_argument("--audio-root", default="")
    a.add_argument("--path-col", required=True)
    a.add_argument("--text-col", required=True)
    a.add_argument("--copy-cols", nargs="*", default=[])
    a.add_argument("--delimiter", default="\t")
    a.add_argument("--out", required=True)

    a = sub.add_parser("gigaspeech2")
    a.add_argument("--tsv", required=True)
    a.add_argument("--audio-dir", required=True)
    a.add_argument("--out", required=True)

    a = sub.add_parser("hf-columns", help="print the columns and first row of a Hugging Face dataset")
    a.add_argument("--dataset", required=True)
    a.add_argument("--config")
    a.add_argument("--split", default="train")
    a.add_argument("--rows", type=int, default=3)

    a = sub.add_parser("hf")
    a.add_argument("--dataset", required=True)
    a.add_argument("--config")
    a.add_argument("--split", required=True)
    a.add_argument("--audio-col", default="audio")
    a.add_argument("--text-col", required=True)
    a.add_argument("--audio-out", required=True)
    a.add_argument("--copy-cols", nargs="*", default=[])
    a.add_argument("--limit", type=int)
    a.add_argument("--target-sr", type=int, default=16000)
    a.add_argument("--num-workers", type=int, default=8)
    a.add_argument("--max-hours", type=float,
                   help="stop after about this many hours (spread over the corpus)")
    a.add_argument("--data-files", help='only these files of the repo, e.g. "data/test-*"')
    a.add_argument("--out", required=True)

    args = p.parse_args(argv)
    if args.corpus == "hf-columns":
        for i, row in enumerate(hf_columns(args.dataset, args.config, args.split, args.rows)):
            print(f"--- row {i}")
            for k, v in row.items():
                print(f"{k}: {v}")
        return 0
    if args.corpus == "hf":
        hf_convert(args.dataset, args.config, args.split, args.audio_col, args.text_col,
                   args.audio_out, args.out, args.copy_cols, args.limit, args.target_sr,
                   args.num_workers, args.max_hours, args.data_files)
        print(f"Wrote {args.out}")
        return 0
    if args.corpus == "gigaspeech2":
        n = write_manifest(args.out, gigaspeech2_entries(args.tsv, args.audio_dir))
        print(f"Wrote {n} entries to {args.out}")
        return 0
    if args.corpus == "librispeech":
        entries = librispeech_entries(args.root, args.subsets)
    elif args.corpus == "aishell1":
        entries = aishell1_entries(args.root, args.split)
    elif args.corpus == "tsv":
        entries = tsv_entries(args.tsv, args.audio_root, args.path_col, args.text_col,
                              args.copy_cols, args.delimiter)
    else:
        raise SystemExit(f"unknown corpus {args.corpus}")
    n = write_manifest(args.out, entries)
    print(f"Wrote {n} entries to {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
