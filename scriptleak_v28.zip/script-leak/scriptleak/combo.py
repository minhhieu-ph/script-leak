"""The proposed recipe end to end: pick the seed on a small real dev set, then
lock the script of each utterance when it is re-decoded at its end (v27).

For offline dumps and, when they exist, real streaming dumps (stream_<set>,
written by nemo_tools.stream_dump), per recipe:
  random seed, greedy        what one usually reports (mean over seeds)
  random seed, lock          the lock alone
  dev picks, greedy          seed chosen on dev (v24)
  dev picks, lock            seed chosen on dev with lock, tested with lock: the proposal
  best seed (oracle)         greedy, best seed chosen on the test set itself
with the CER (Thai) and WER (English) of each, plus how close streaming is to
offline (same greedy text, leak rates).

CPU only.  python -m scriptleak.combo --work $W
"""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import sys
from typing import Dict, List, Optional

import numpy as np

from .pareto import score_dump, rates
from .realstats import DEFAULT_GROUPS, parse_groups

DEV = ("dev_lotus_th", "dev_ami_en")
TEST = ("real_lotus_th", "real_ami_en")
NAMES = ["greedy", "lock"]
MODES = {"offline": "", "streaming": "stream_"}


def _job(args):
    path, set_name = args
    try:
        return path, score_dump(path, set_name, NAMES)
    except Exception as e:  # noqa: BLE001
        return path, f"{type(e).__name__}: {e}"


def _texts(path: str) -> Dict[str, str]:
    out = {}
    with open(os.path.join(path, "utts.jsonl"), encoding="utf-8") as f:
        for l in f:
            if l.strip():
                r = json.loads(l)
                out[str(r.get("audio_filepath"))] = str(r.get("pred_ctc", ""))
    return out


def run(work: str, b_pct: str, groups: Dict[str, List[str]], workers: int = 16, log=print) -> Dict:
    labels = [l for ls in groups.values() for l in ls]
    d = lambda l, s: os.path.join(work, "dumps", f"B{b_pct}_{l}", s)
    jobs = [(d(l, pre + s), s) for l in labels for pre in MODES.values() for s in DEV + TEST
            if os.path.exists(os.path.join(d(l, pre + s), "meta.json"))]
    log(f"scoring {len(jobs)} dumps ...")
    got = {}
    with mp.get_context("spawn").Pool(max(1, workers)) as pool:
        for path, r in pool.imap_unordered(_job, jobs):
            if isinstance(r, str):
                log(f"!! {path}: {r}")
            else:
                got[path] = rates(r)
    res: Dict = {"modes": {}}
    for mode, pre in MODES.items():
        M = {}
        for l in labels:
            if all(d(l, pre + s) in got for s in DEV + TEST):
                M[l] = {s: got[d(l, pre + s)] for s in DEV + TEST}
        if not M:
            continue
        out = {}
        for g, ls in groups.items():
            ls = [l for l in ls if l in M]
            if not ls:
                continue
            def test(l, i):
                r = M[l]
                return {"sum": float(r[TEST[0]]["leak"][i] + r[TEST[1]]["leak"][i]),
                        "Th>L": float(r[TEST[0]]["leak"][i]), "En>Th": float(r[TEST[1]]["leak"][i]),
                        "CER": float(r[TEST[0]]["err"][i]), "WER": float(r[TEST[1]]["err"][i])}
            def dev(l, i):
                return float(M[l][DEV[0]]["leak"][i] + M[l][DEV[1]]["leak"][i])
            rows = {}
            for name, i in (("random seed, greedy", 0), ("random seed, lock", 1)):
                v = [test(l, i) for l in ls]
                rows[name] = {k: float(np.mean([x[k] for x in v])) for k in v[0]}
                rows[name]["sd"] = float(np.std([x["sum"] for x in v], ddof=1)) if len(v) > 1 else 0.0
            for name, i in (("dev picks, greedy", 0), ("dev picks, lock", 1)):
                pick = min(ls, key=lambda l: dev(l, i))
                rows[name] = dict(test(pick, i), pick=pick)
            pick = min(ls, key=lambda l: test(l, 0)["sum"])
            rows["best seed (oracle)"] = dict(test(pick, 0), pick=pick)
            out[g] = rows
        res["modes"][mode] = out
    # streaming vs offline, greedy text
    agree = {}
    for l in labels:
        per = {}
        for s in DEV + TEST:
            a, b = d(l, s), d(l, "stream_" + s)
            if os.path.exists(os.path.join(a, "utts.jsonl")) and os.path.exists(os.path.join(b, "utts.jsonl")):
                ta, tb = _texts(a), _texts(b)
                keys = [k for k in ta if k in tb]
                per[s] = float(np.mean([ta[k] == tb[k] for k in keys])) if keys else None
        if per:
            agree[l] = per
    res["agreement"] = agree
    return res


def report(res: Dict) -> List[str]:
    L = []
    for mode, groups in res["modes"].items():
        L.append(f"\n################ {mode}: test sets (Thai->Latin on LOTUSDIS + English->Thai on AMI) ################")
        L.append(f"  {'recipe':<6} {'':<22} {'Th>L':>6} {'En>Th':>6} {'sum':>6} {'(sd)':>6} {'CER Th':>7} {'WER En':>7}  pick")
        for g, rows in groups.items():
            for name, v in rows.items():
                L.append(f"  {g:<6} {name:<22} {v['Th>L']:6.1%} {v['En>Th']:6.1%} {v['sum']:6.1%} "
                         + (f"{v['sd']:6.1%}" if "sd" in v else f"{'':>6}")
                         + f" {v['CER']:7.1%} {v['WER']:7.1%}  {v.get('pick', '')}")
            base = rows["random seed, greedy"]["sum"]
            prop = rows["dev picks, lock"]["sum"]
            if base > 0:
                L.append(f"  {g:<6} -> proposal vs random seed: {base:.1%} -> {prop:.1%} ({(prop - base) / base:+.0%})")
    if res.get("agreement"):
        L.append("\nStreaming vs offline: share of utterances with the same greedy CTC text")
        sets = sorted({s for v in res["agreement"].values() for s in v})
        L.append(f"  {'model':<10} " + " ".join(f"{s:>14}" for s in sets))
        for l, v in res["agreement"].items():
            L.append(f"  {l:<10} " + " ".join(f"{v[s]:14.1%}" if v.get(s) is not None else f"{'-':>14}" for s in sets))
    return L


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--work", default=os.environ.get("W"))
    p.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    p.add_argument("--groups", nargs="*", default=DEFAULT_GROUPS)
    p.add_argument("--workers", type=int, default=int(os.environ.get("CALIB_WORKERS", "16")))
    p.add_argument("--out")
    args = p.parse_args(argv)
    if not args.work:
        p.error("--work (or $W) is required")
    res = run(args.work, args.b_pct, parse_groups(args.groups), args.workers)
    if not res["modes"]:
        print("no model has dev and test dumps (run 'selectC' first)")
        return 1
    print("\n".join(report(res)))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
