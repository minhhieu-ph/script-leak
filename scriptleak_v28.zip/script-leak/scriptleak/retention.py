"""Does the model keep the English words that really are in a Thai sentence?

The other half of the trade-off: a fix that stops leakage by never writing
Latin letters would also lose names and loanwords that the reference writes in
Latin. This scores utterances whose reference mixes Thai and Latin words.

For each hypothesis field (pred_ctc, pred_transducer):
  latin_recall   share of the reference's Latin words that the hypothesis
                 also has (multiset match, order ignored)
  latin_utts     share of utterances whose hypothesis has any Latin letter
  extra_latin    share of the hypothesis's Latin words not in the reference
  cer            character error rate over the whole text, spaces ignored

  python -m scriptleak.retention score --manifest dumps/X/lotus_mixed/utts.jsonl \\
      --group-by stratum --out results/X/lotus_mixed.json
  python -m scriptleak.retention table base=results/base/lotus_mixed.json both=...
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter, OrderedDict
from typing import Dict, List, Optional

from .manifest import read_manifest
from .metrics import cer
from .normalize import scoring_normalize

_LATIN_WORD = re.compile(r"[a-z]+(?:'[a-z]+)*")
HYP_FIELDS = ("pred_ctc", "pred_transducer")


def latin_words(text: str) -> List[str]:
    return _LATIN_WORD.findall(scoring_normalize(text))


def score_rows(rows: List[Dict], hyp_field: str, ref_field: str = "text") -> Dict:
    ref_n = hyp_n = matched = with_latin = 0
    refs, hyps = [], []
    for r in rows:
        ref, hyp = scoring_normalize(str(r.get(ref_field, ""))), scoring_normalize(str(r.get(hyp_field, "")))
        rw, hw = Counter(latin_words(ref)), Counter(latin_words(hyp))
        m = sum((rw & hw).values())
        ref_n += sum(rw.values())
        hyp_n += sum(hw.values())
        matched += m
        with_latin += 1 if hw else 0
        refs.append(ref)
        hyps.append(hyp)
    n = len(rows)
    return {
        "utterances": n,
        "ref_latin_words": ref_n,
        "latin_recall": matched / ref_n if ref_n else 0.0,
        "latin_utts": with_latin / n if n else 0.0,
        "extra_latin": (hyp_n - matched) / hyp_n if hyp_n else 0.0,
        "cer": cer(refs, hyps, ignore_spaces=True),
    }


def score(rows: List[Dict], group_by: Optional[str] = None) -> Dict:
    fields = [f for f in HYP_FIELDS if any(f in r for r in rows)]
    groups: "OrderedDict[str, List[Dict]]" = OrderedDict([("ALL", rows)])
    if group_by:
        for r in rows:
            groups.setdefault(str(r.get(group_by)), []).append(r)
    return {f: {g: score_rows(rs, f) for g, rs in groups.items()} for f in fields}


def format_score(res: Dict) -> str:
    lines = []
    for field, groups in res.items():
        lines.append(f"[{field}]")
        lines.append(f"  {'group':<28} {'utts':>6} {'words':>6} {'recall':>7} {'latin':>7} {'extra':>7} {'CER':>7}")
        for g, r in groups.items():
            lines.append(f"  {g:<28} {r['utterances']:>6} {r['ref_latin_words']:>6} {r['latin_recall']:>7.1%} "
                         f"{r['latin_utts']:>7.1%} {r['extra_latin']:>7.1%} {r['cer']:>7.1%}")
    return "\n".join(lines)


def table(items: List[str], group: str = "ALL") -> str:
    rows = []
    for item in items:
        name, path = item.split("=", 1)
        try:
            with open(path, "r", encoding="utf-8") as f:
                rows.append((name, json.load(f)))
        except (OSError, ValueError) as e:
            rows.append((name, {"error": str(e)}))
    if not rows:
        return "nothing to compare"
    width = max(8, max(len(n) for n, _ in rows))
    head = f"{'model':<{width}}  " + "  ".join(f"{f.replace('pred_', ''):>26}" for f in HYP_FIELDS)
    lines = [head, f"{'':<{width}}  " + "  ".join(f"{'recall / latin / CER':>26}" for _ in HYP_FIELDS)]
    for name, res in rows:
        cells = []
        for f in HYP_FIELDS:
            r = res.get(f, {}).get(group) if isinstance(res.get(f), dict) else None
            cells.append(f"{r['latin_recall']:>7.1%} / {r['latin_utts']:>6.1%} / {r['cer']:>6.1%}" if r else "-")
        lines.append(f"{name:<{width}}  " + "  ".join(f"{c:>26}" for c in cells))
    lines.append("\n(recall: reference English words kept in Latin; latin: utterances with any Latin output)")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("score")
    a.add_argument("--manifest", required=True, help="utts.jsonl of a dump, or any manifest with predictions")
    a.add_argument("--group-by")
    a.add_argument("--out")
    a = sub.add_parser("table")
    a.add_argument("results", nargs="+", metavar="NAME=PATH")
    a.add_argument("--group", default="ALL")
    args = p.parse_args(argv)
    if args.cmd == "table":
        print(table(args.results, args.group))
        return 0
    rows = list(read_manifest(args.manifest))
    res = score(rows, args.group_by)
    print(format_score(res))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
