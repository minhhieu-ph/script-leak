"""Test sets with real noise: LOTUSDIS (far-field meetings) and GigaSpeech 2 (YouTube).

Every condition in phases A and B was synthetic: MUSAN noise or white noise
mixed into clean read speech. These two public Thai corpora were recorded in
real conditions, so a model that only learned "MUSAN means English" would show
it here.

  # GigaSpeech 2 is gated: accept the terms on its Hugging Face page and log in
  python -m scriptleak.real fetch-gs2 --out-dir $D/gigaspeech2

  # AMI meetings, far-field single microphone (real noisy English, CC-BY 4.0)
  python -m scriptleak.real ami --out-dir $D/ami --split eval --out ami_eval.raw.jsonl
  python -m scriptleak.real build-en --manifest ami_eval.raw.jsonl --name ami --out ami.en.jsonl

  # split a raw manifest into Thai-only and Thai+Latin references
  python -m scriptleak.real build --manifest lotus_test.raw.jsonl --name lotus \\
      --stratum-field mic --keep-frac 0.35 --out-thai lotus.th.jsonl \\
      --out-mixed lotus.mixed.jsonl --report lotus.build.json

The Thai-only file is scored for leakage like every other Thai test set. The
mixed file holds utterances whose reference itself has English words in Latin
script (names, loanwords); it is scored with scriptleak.retention, which asks
whether the model keeps those words instead of writing them in Thai.
"""

from __future__ import annotations

import argparse
import dataclasses
import hashlib
import json
import os
import sys
import tarfile
import unicodedata
from collections import Counter
from typing import Dict, Iterable, List, Optional, Tuple

from .languages import get_language
from .manifest import read_manifest, write_manifest
from .normalize import _APOSTROPHES, _prepare, normalize
from .scripts import LATIN, THAI

GS2_REPO = "speechcolab/gigaspeech2"
AMI_REPO = "edinburghcstr/ami"
GS2_FILES = ("data/th/test.tsv", "data/th/test.tar.gz")
_TH_REJECT = get_language("th").reject_chars


# ------------------------------------------------------------------ references

def mixed_normalize(text: str) -> Tuple[Optional[str], str]:
    """Normalise a reference that may mix Thai and Latin letters.

    Returns (text, kind) with kind "thai", "mixed" or a rejection reason.
    The rules follow scriptleak.normalize: anything whose spoken form is
    ambiguous (digits, symbols, other scripts) rejects the utterance. Latin
    letters are lower-cased; Thai word spaces are kept."""
    text = _prepare(text).lower()
    out: List[str] = []
    n_thai = n_latin = 0
    for ch in text:
        if ch.isspace():
            out.append(" ")
        elif ch in _TH_REJECT:
            return None, _TH_REJECT[ch]
        elif THAI.contains(ch):
            out.append(ch)
            n_thai += 1
        elif "a" <= ch <= "z":
            out.append(ch)
            n_latin += 1
        elif LATIN.contains(ch):
            return None, "accented_latin"
        elif ch in _APOSTROPHES:
            out.append("'")
        else:
            cat = unicodedata.category(ch)
            if cat[0] == "N":
                return None, "digit"
            if cat[0] == "P" and ch not in "%&@#/":
                out.append(" ")
                continue
            if cat[0] in "SL" or ch in "%&@#/":
                return None, "symbol_or_other_script"
            return None, "unknown_char"
    norm = " ".join(w.strip("'") for w in "".join(out).split())
    norm = " ".join(norm.split())
    if not norm:
        return None, "empty"
    if n_latin == 0:
        return norm, "thai"
    if n_thai == 0:
        return None, "latin_only"
    return norm, "mixed"


def _keep(entry: Dict, frac: float, group_fields: List[str]) -> bool:
    """Deterministic sample keyed on group_fields, so the same segment is kept
    for every microphone that recorded it."""
    if frac >= 1.0:
        return True
    key = "\x1f".join(str(entry.get(f, "")) for f in group_fields)
    h = int(hashlib.sha256(key.encode("utf-8")).hexdigest()[:8], 16)
    return h / 0xFFFFFFFF < frac


def build(entries: Iterable[Dict], name: str, stratum_field: Optional[str] = None,
          keep_frac: float = 1.0, group_fields: Optional[List[str]] = None,
          min_dur: float = 0.3, max_dur: float = 30.0,
          text_field: str = "text") -> Tuple[List[Dict], List[Dict], Dict]:
    """(thai_only, mixed, report). Thai-only references are normalised exactly
    like the Porjai test set (strict Thai, word spaces kept)."""
    th = dataclasses.replace(get_language("th"), remove_spaces=False)
    group_fields = group_fields or [text_field]
    thai: List[Dict] = []
    mixed: List[Dict] = []
    reasons: Counter = Counter()
    secs: Counter = Counter()
    n = 0
    for e in entries:
        n += 1
        dur = float(e.get("duration", 0.0))
        if dur < min_dur or dur > max_dur:
            reasons["duration"] += 1
            continue
        if not _keep(e, keep_frac, group_fields):
            reasons["not_sampled"] += 1
            continue
        raw = str(e.get(text_field, ""))
        text, kind = mixed_normalize(raw)
        if kind == "thai":
            res = normalize(raw, th)  # the strict rules, so Thai-only sets match Porjai's
            if not res.ok:
                reasons[res.reasons[0]] += 1
                continue
            text = res.text
        elif kind != "mixed":
            reasons[kind] += 1
            continue
        stratum = f"{name}/{e.get(stratum_field)}" if stratum_field else name
        out = dict(e)
        out.update({text_field: text, "text_raw": raw, "lang": "th", "stratum": stratum,
                    "text_key": text.replace(" ", "")})
        (thai if kind == "thai" else mixed).append(out)
        secs[kind] += dur
    per_stratum: Dict[str, Dict[str, int]] = {}
    for kind, rows in (("thai", thai), ("mixed", mixed)):
        for r in rows:
            per_stratum.setdefault(r["stratum"], {"thai": 0, "mixed": 0})[kind] += 1
    report = {
        "name": name, "utterances_in": n,
        "thai_only": len(thai), "thai_only_hours": round(secs["thai"] / 3600.0, 2),
        "mixed": len(mixed), "mixed_hours": round(secs["mixed"] / 3600.0, 2),
        "dropped": dict(reasons.most_common()),
        "per_stratum": dict(sorted(per_stratum.items())),
    }
    return thai, mixed, report


def format_build(report: Dict) -> str:
    lines = [f"{report['name']}: {report['utterances_in']} utterances in",
             f"  Thai-only references : {report['thai_only']:>7} ({report['thai_only_hours']} h)",
             f"  Thai + Latin words   : {report['mixed']:>7} ({report['mixed_hours']} h)",
             "  dropped: " + (", ".join(f"{k} {v}" for k, v in report["dropped"].items()) or "none")]
    if len(report["per_stratum"]) > 1:
        lines.append("  per stratum (thai-only / mixed):")
        for s, c in report["per_stratum"].items():
            lines.append(f"    {s:<28} {c['thai']:>6} / {c['mixed']:>5}")
    return "\n".join(lines)


def split_by_stratum(entries: List[Dict], out_dir: str) -> List[str]:
    """One manifest per stratum (for noisefloor). Returns NAME=PATH items."""
    os.makedirs(out_dir, exist_ok=True)
    groups: Dict[str, List[Dict]] = {}
    for e in entries:
        groups.setdefault(e["stratum"], []).append(e)
    items = []
    for s, rows in sorted(groups.items()):
        path = os.path.join(out_dir, s.replace("/", "_") + ".jsonl")
        write_manifest(path, rows)
        items.append(f"{s}={path}")
    return items


# ------------------------------------------------------------------ GigaSpeech 2

def safe_extract(tar_path: str, dest: str) -> int:
    """Extract regular files only, refusing paths that leave dest."""
    dest_abs = os.path.realpath(dest)
    n = 0
    with tarfile.open(tar_path, "r:*") as tf:
        for m in tf:
            if not m.isfile():
                continue
            target = os.path.realpath(os.path.join(dest_abs, m.name))
            if not target.startswith(dest_abs + os.sep):
                raise ValueError(f"unsafe path in archive: {m.name}")
            os.makedirs(os.path.dirname(target), exist_ok=True)
            src = tf.extractfile(m)
            if src is None:
                continue
            with open(target + ".tmp", "wb") as f:
                while True:
                    buf = src.read(1 << 20)
                    if not buf:
                        break
                    f.write(buf)
            os.replace(target + ".tmp", target)
            n += 1
    return n


def fetch_gs2(out_dir: str) -> Tuple[str, str]:
    """Download and extract the GigaSpeech 2 Thai test set. Returns (tsv,
    audio_dir). Skips whatever is already there."""
    audio_dir = os.path.join(out_dir, "data", "th", "test")
    tsv = os.path.join(out_dir, "data", "th", "test.tsv")
    done = os.path.join(audio_dir, ".extracted")
    if os.path.exists(done) and os.path.exists(tsv):
        print(f"GigaSpeech 2 test already in {audio_dir}")
        return tsv, audio_dir
    try:
        from huggingface_hub import hf_hub_download
    except ImportError as e:
        raise SystemExit("huggingface_hub is missing (it comes with `datasets`)") from e
    paths = {}
    for f in GS2_FILES:
        try:
            paths[f] = hf_hub_download(GS2_REPO, f, repo_type="dataset", local_dir=out_dir)
        except Exception as e:  # noqa: BLE001
            msg = str(e).splitlines()[0] if str(e) else type(e).__name__
            raise SystemExit(
                f"Could not download {f} from {GS2_REPO}: {msg}\n"
                "GigaSpeech 2 is gated. Open https://huggingface.co/datasets/speechcolab/gigaspeech2,\n"
                "accept the terms with your account, then run `huggingface-cli login` (or set HF_TOKEN)\n"
                "on this machine and start this step again.") from e
    os.makedirs(audio_dir, exist_ok=True)
    n = safe_extract(paths["data/th/test.tar.gz"], audio_dir)
    open(done, "w").close()
    print(f"Extracted {n} files to {audio_dir}")
    return paths["data/th/test.tsv"], audio_dir


# ------------------------------------------------------------------ AMI (real noisy English)

def ami_key(name: str) -> Optional[Tuple[str, str, str, str]]:
    """(meeting, speaker, begin, end) from an AMI segment id or wav name, e.g.
    AMI_EN2002a_H00_MEE071_0000557_0000594 or eval_ami_en2002a_sdm1_mee071_0000557_0000594.wav.
    The microphone part differs between the annotation and the far-field audio,
    so it is left out of the key."""
    stem = os.path.basename(name)
    if stem.lower().endswith(".wav"):
        stem = stem[:-4]
    parts = stem.lower().split("_")
    if "ami" not in parts:
        return None
    i = parts.index("ami")
    rest = parts[i + 1:]
    if len(rest) < 5:
        return None
    meeting, speaker, begin, end = rest[0], rest[-3], rest[-2], rest[-1]
    return meeting, speaker, begin, end


def ami_entries(text_path: str, audio_dir: str, duration_fn=None) -> Iterable[Dict]:
    """Annotation lines "<segment id> <TEXT>" matched to extracted far-field wavs."""
    if duration_fn is None:
        from .prepare import audio_duration as duration_fn
    by_key: Dict[Tuple[str, str, str, str], str] = {}
    for root, _, files in os.walk(audio_dir):
        for f in files:
            if f.lower().endswith(".wav"):
                k = ami_key(f)
                if k:
                    by_key[k] = os.path.join(root, f)
    if not by_key:
        raise FileNotFoundError(f"no AMI wav files under {audio_dir}")
    missing = 0
    with open(text_path, "r", encoding="utf-8") as fh:
        for line in fh:
            seg, _, text = line.strip().partition(" ")
            k = ami_key(seg)
            if not k or not text:
                continue
            path = by_key.get(k)
            if path is None:
                missing += 1
                continue
            yield {"audio_filepath": path, "duration": duration_fn(path), "text": text,
                   "utt_id": seg, "meeting": k[0], "speaker_id": k[1], "source": "ami"}
    if missing:
        print(f"note: {missing} annotated AMI segments have no far-field wav (other splits or mics)")


_SPLIT_ALIASES = {"eval": ("eval", "test"), "test": ("test", "eval"), "dev": ("dev", "validation"),
                  "train": ("train",)}


def _pick_parquet(files: List[str], mic: str, split: str) -> List[str]:
    names = _SPLIT_ALIASES.get(split, (split,))
    out = []
    for f in files:
        if not f.endswith(".parquet"):
            continue
        parts = f.lower().split("/")
        if not any(mic in p for p in parts):
            continue
        tail = "/".join(parts[parts.index(mic) + 1:]) if mic in parts else "/".join(parts)
        if any(n in tail for n in names):
            out.append(f)
    return sorted(out)


def fetch_ami(out_dir: str, split: str = "eval", mic: str = "sdm") -> Dict:
    """Find and download one AMI split, whatever form the repository has now.

    Returns {"kind": "text", "text": path, "audio_dir": dir} for the tar + transcript
    layout, or {"kind": "parquet", "files": [local paths]} for parquet files (on the
    main branch, or on the automatic refs/convert/parquet branch)."""
    try:
        from huggingface_hub import hf_hub_download, list_repo_files
    except ImportError as e:
        raise SystemExit("huggingface_hub is missing (it comes with `datasets`)") from e
    names = _SPLIT_ALIASES.get(split, (split,))
    files = list_repo_files(AMI_REPO, repo_type="dataset")

    texts = [f for f in files if f.startswith("annotations/") and f.endswith("/text")
             and f.split("/")[1] in names]
    tars = sorted(f for f in files if f.endswith(".tar.gz") and f.startswith(f"audio/{mic}/")
                  and f.split("/")[2] in names)
    if texts and tars:
        audio_dir = os.path.join(out_dir, "audio", mic, split, "extracted")
        done = os.path.join(audio_dir, ".extracted")
        text = hf_hub_download(AMI_REPO, texts[0], repo_type="dataset", local_dir=out_dir)
        if not os.path.exists(done):
            os.makedirs(audio_dir, exist_ok=True)
            n = 0
            for t in tars:
                n += safe_extract(hf_hub_download(AMI_REPO, t, repo_type="dataset", local_dir=out_dir), audio_dir)
                print(f"  {os.path.basename(t)}: extracted", flush=True)
            open(done, "w").close()
            print(f"AMI {mic}/{split}: {len(tars)} meetings, {n} files")
        return {"kind": "text", "text": text, "audio_dir": audio_dir}

    for revision in (None, "refs/convert/parquet"):
        rfiles = files if revision is None else list_repo_files(AMI_REPO, repo_type="dataset", revision=revision)
        pq = _pick_parquet(rfiles, mic, split)
        if pq:
            where = "main" if revision is None else revision
            print(f"AMI {mic}/{split}: {len(pq)} parquet file(s) on {where}: {pq[0]}{' ...' if len(pq) > 1 else ''}")
            local = [hf_hub_download(AMI_REPO, f, repo_type="dataset", revision=revision,
                                     local_dir=os.path.join(out_dir, "parquet")) for f in pq]
            return {"kind": "parquet", "files": local}

    shown = "\n  ".join(files[:40])
    raise SystemExit(f"Could not find AMI {mic}/{split} in {AMI_REPO}. First files of the repository:\n  {shown}")


def build_en(entries: Iterable[Dict], name: str, keep_frac: float = 1.0,
             group_fields: Optional[List[str]] = None, min_dur: float = 0.5,
             max_dur: float = 30.0, text_field: str = "text") -> Tuple[List[Dict], Dict]:
    """Spoken-form English subset (LibriSpeech rules) of a real-condition set."""
    en = get_language("en")
    group_fields = group_fields or [text_field]
    out: List[Dict] = []
    reasons: Counter = Counter()
    n = 0
    secs = 0.0
    for e in entries:
        n += 1
        dur = float(e.get("duration", 0.0))
        if dur < min_dur or dur > max_dur:
            reasons["duration"] += 1
            continue
        if not _keep(e, keep_frac, group_fields):
            reasons["not_sampled"] += 1
            continue
        raw = str(e.get(text_field, ""))
        res = normalize(raw, en)
        if not res.ok:
            reasons[res.reasons[0]] += 1
            continue
        rec = dict(e)
        rec.update({text_field: res.text, "text_raw": raw, "lang": "en", "stratum": name})
        out.append(rec)
        secs += dur
    report = {"name": name, "utterances_in": n, "english": len(out), "english_hours": round(secs / 3600.0, 2),
              "dropped": dict(reasons.most_common())}
    return out, report


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("fetch-gs2", help="download + extract the GigaSpeech 2 Thai test set")
    a.add_argument("--out-dir", required=True)

    a = sub.add_parser("ami", help="download AMI far-field audio of one split and write a raw manifest")
    a.add_argument("--out-dir", required=True)
    a.add_argument("--split", default="eval", choices=["train", "dev", "eval"])
    a.add_argument("--mic", default="sdm", choices=["sdm", "ihm"])
    a.add_argument("--num-workers", type=int, default=8)
    a.add_argument("--out", required=True)

    a = sub.add_parser("build-en", help="raw English manifest -> spoken-form English manifest")
    a.add_argument("--manifest", required=True)
    a.add_argument("--name", required=True)
    a.add_argument("--keep-frac", type=float, default=1.0)
    a.add_argument("--min-dur", type=float, default=0.5)
    a.add_argument("--max-dur", type=float, default=30.0)
    a.add_argument("--out", required=True)
    a.add_argument("--report")
    a.add_argument("--strata-dir")

    a = sub.add_parser("build", help="raw manifest -> Thai-only and Thai+Latin manifests")
    a.add_argument("--manifest", required=True)
    a.add_argument("--name", required=True, help="prefix of the stratum, e.g. lotus")
    a.add_argument("--stratum-field", help="field appended to the stratum, e.g. mic")
    a.add_argument("--keep-frac", type=float, default=1.0,
                   help="keep this share of segments (same segments for every stratum)")
    a.add_argument("--group-fields", nargs="*", default=["speaker_id", "text"],
                   help="fields that identify one segment across microphones")
    a.add_argument("--min-dur", type=float, default=0.3)
    a.add_argument("--max-dur", type=float, default=30.0)
    a.add_argument("--out-thai", required=True)
    a.add_argument("--out-mixed", required=True)
    a.add_argument("--report")
    a.add_argument("--strata-dir", help="also write one Thai-only manifest per stratum here")

    args = p.parse_args(argv)
    if args.cmd == "fetch-gs2":
        tsv, audio_dir = fetch_gs2(args.out_dir)
        print(f"tsv: {tsv}\naudio: {audio_dir}")
        return 0
    if args.cmd == "ami":
        got = fetch_ami(args.out_dir, args.split, args.mic)
        if got["kind"] == "text":
            n = write_manifest(args.out, ami_entries(got["text"], got["audio_dir"]))
            print(f"Wrote {n} AMI {args.mic}/{args.split} segments to {args.out}")
            return 0
        from .prepare import _load_hf, hf_convert

        cols = _load_hf("parquet", None, "test", "audio", got["files"]).column_names
        text_col = "text" if "text" in cols else next((c for c in cols if "text" in c or "sentence" in c), None)
        if text_col is None:
            raise SystemExit(f"no transcript column among {cols}")
        copy = [c for c in ("meeting_id", "speaker_id", "audio_id", "microphone_id") if c in cols]
        hf_convert("parquet", None, "test", "audio", text_col,
                   os.path.join(args.out_dir, "wav", args.mic, args.split), args.out, copy,
                   num_workers=args.num_workers, data_files=got["files"])
        rows = list(read_manifest(args.out))
        for r in rows:  # same field names as the tar layout
            r.setdefault("meeting", str(r.get("meeting_id", "")).lower())
            r["source"] = "ami"
        write_manifest(args.out, rows)
        print(f"Wrote {len(rows)} AMI {args.mic}/{args.split} segments to {args.out}")
        return 0
    if args.cmd == "build-en":
        rows, report = build_en(read_manifest(args.manifest), args.name, args.keep_frac,
                                ["meeting", "speaker_id", "text"], args.min_dur, args.max_dur)
        write_manifest(args.out, rows)
        print(f"{report['name']}: {report['utterances_in']} in, {report['english']} spoken-form English "
              f"({report['english_hours']} h); dropped: "
              + (", ".join(f"{k} {v}" for k, v in report["dropped"].items()) or "none"))
        if args.report:
            with open(args.report, "w", encoding="utf-8") as f:
                json.dump(report, f, ensure_ascii=False, indent=2)
        if args.strata_dir:
            split_by_stratum(rows, args.strata_dir)
        return 0
    thai, mixed, report = build(read_manifest(args.manifest), args.name, args.stratum_field,
                                args.keep_frac, args.group_fields, args.min_dur, args.max_dur)
    write_manifest(args.out_thai, thai)
    write_manifest(args.out_mixed, mixed)
    print(format_build(report))
    if args.report:
        with open(args.report, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
    if args.strata_dir:
        split_by_stratum(thai, args.strata_dir)
    return 0


if __name__ == "__main__":
    sys.exit(main())
