"""Can a small real dev set pick a model that leaks less on the real test set? (v24)

The real-audio leak rate swings between seeds and between checkpoints of one
run. Two cheap remedies, both used here without any new training:
  - averaging the weights of the last checkpoints of a run ("avg")
  - choosing among seeds / checkpoints by the two-direction leak rate on a
    small real DEV set (LOTUSDIS validation, AMI dev), never on the test set

For every candidate (a final model, its average, or a saved checkpoint) the
two-direction leak rate is read on dev and on test. Then:
  - correlation between dev and test over all candidates
  - per recipe: test leak of a random seed (mean of finals) vs the candidate
    the dev set picks, among finals and among all candidates
  - per run: final vs averaged weights

  python -m scriptleak.selection --work $W --groups rir=rir,rir_s1,rir_s2 ...
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys
from typing import Dict, List, Optional

import numpy as np

from .realstats import DEFAULT_GROUPS, leak_flags, load_utts, parse_groups

DEV = ("dev_lotus_th", "dev_ami_en")
TEST = ("real_lotus_th", "real_ami_en")


def candidate_dir(work: str, b_pct: str, label: str, cand: str, set_name: str) -> str:
    if cand == "final":
        return os.path.join(work, "dumps", f"B{b_pct}_{label}", set_name)
    if cand == "avg":
        return os.path.join(work, "dumps", f"B{b_pct}_{label}_avg", set_name)
    return os.path.join(work, "dumps", f"B{b_pct}_{label}", f"sel_{cand}_{set_name}")


def rate(path: str, set_name: str, field: str) -> Optional[float]:
    f = os.path.join(path, "utts.jsonl")
    if not os.path.exists(f):
        return None
    with open(f, encoding="utf-8") as fh:
        rows = [json.loads(l) for l in fh if l.strip()]
    flags = leak_flags(rows, set_name, field)
    return float(np.mean(list(flags.values()))) if flags else None


def candidates(work: str, b_pct: str, label: str) -> List[str]:
    out = ["final"]
    if os.path.isdir(os.path.join(work, "dumps", f"B{b_pct}_{label}_avg")):
        out.append("avg")
    eps = set()
    for d in glob.glob(os.path.join(work, "dumps", f"B{b_pct}_{label}", "sel_epoch*_dev_lotus_th")):
        m = re.search(r"sel_(epoch\d+)_", d)
        if m:
            eps.add(m.group(1))
    return out + sorted(eps)


def ranks(x: np.ndarray) -> np.ndarray:
    r = np.empty(len(x))
    r[np.argsort(x)] = np.arange(len(x))
    return r


def run(work: str, b_pct: str, groups: Dict[str, List[str]], field: str) -> Dict:
    table = []
    for g, labels in groups.items():
        for label in labels:
            for cand in candidates(work, b_pct, label):
                row = {"group": g, "label": label, "cand": cand}
                for s in DEV + TEST:
                    row[s] = rate(candidate_dir(work, b_pct, label, cand, s), s, field)
                if all(row[s] is not None for s in DEV + TEST):
                    row["dev"] = row[DEV[0]] + row[DEV[1]]
                    row["test"] = row[TEST[0]] + row[TEST[1]]
                    table.append(row)
    res: Dict = {"candidates": table, "groups": {}}
    if len(table) >= 3:
        d = np.array([r["dev"] for r in table])
        t = np.array([r["test"] for r in table])
        res["pearson"] = float(np.corrcoef(d, t)[0, 1])
        res["spearman"] = float(np.corrcoef(ranks(d), ranks(t))[0, 1])
    for g in groups:
        rows = [r for r in table if r["group"] == g]
        finals = [r for r in rows if r["cand"] == "final"]
        if not finals:
            continue
        info = {"random_seed": float(np.mean([r["test"] for r in finals])),
                "worst_seed": float(max(r["test"] for r in finals)),
                "best_seed_oracle": float(min(r["test"] for r in finals))}
        pick = min(finals, key=lambda r: r["dev"])
        info["dev_picks_final"] = {"label": pick["label"], "test": pick["test"]}
        pick = min(rows, key=lambda r: r["dev"])
        info["dev_picks_any"] = {"label": pick["label"], "cand": pick["cand"], "test": pick["test"]}
        avgs = [r for r in rows if r["cand"] == "avg"]
        if avgs:
            info["mean_avg"] = float(np.mean([r["test"] for r in avgs]))
            info["avg_vs_final"] = [{"label": a["label"], "avg": a["test"],
                                     "final": next(f["test"] for f in finals if f["label"] == a["label"])}
                                    for a in avgs if any(f["label"] == a["label"] for f in finals)]
        res["groups"][g] = info
    return res


def report(res: Dict) -> List[str]:
    L = [f"{'recipe':<7} {'model':<12} {'candidate':<10} {'dev Th>L':>9} {'dev En>Th':>10} {'dev sum':>8} "
         f"{'test Th>L':>10} {'test En>Th':>11} {'test sum':>9}"]
    for r in res["candidates"]:
        L.append(f"{r['group']:<7} {r['label']:<12} {r['cand']:<10} {r['dev_lotus_th']:9.1%} {r['dev_ami_en']:10.1%} "
                 f"{r['dev']:8.1%} {r['real_lotus_th']:10.1%} {r['real_ami_en']:11.1%} {r['test']:9.1%}")
    if "spearman" in res:
        L.append(f"\nDev vs test over {len(res['candidates'])} candidates: Pearson {res['pearson']:.2f}, "
                 f"Spearman {res['spearman']:.2f}")
    if res["groups"]:
        L.append("\nPer recipe, test leak (sum of both directions):")
        L.append(f"  {'recipe':<7} {'random seed':>12} {'worst seed':>11} {'best (oracle)':>14} "
                 f"{'dev picks final':>16} {'dev picks any':>24} {'mean of avg':>12}")
        for g, v in res["groups"].items():
            any_ = f"{v['dev_picks_any']['test']:.1%} ({v['dev_picks_any']['label']}/{v['dev_picks_any']['cand']})"
            L.append(f"  {g:<7} {v['random_seed']:12.1%} {v['worst_seed']:11.1%} {v['best_seed_oracle']:14.1%} "
                     f"{v['dev_picks_final']['test']:16.1%} {any_:>24} "
                     + (f"{v['mean_avg']:12.1%}" if "mean_avg" in v else f"{'-':>12}"))
        L.append("\nAveraged weights vs final, per run (test sum):")
        for g, v in res["groups"].items():
            for a in v.get("avg_vs_final", []):
                L.append(f"  {a['label']:<12} final {a['final']:6.1%} -> avg {a['avg']:6.1%}")
    return L


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--work", default=os.environ.get("W"))
    p.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    p.add_argument("--groups", nargs="*", default=DEFAULT_GROUPS)
    p.add_argument("--field", default="pred_ctc")
    p.add_argument("--out")
    args = p.parse_args(argv)
    if not args.work:
        p.error("--work (or $W) is required")
    res = run(args.work, args.b_pct, parse_groups(args.groups), args.field)
    if not res["candidates"]:
        print("no candidate has dumps on all four sets (run 'selectC' first)")
        return 1
    print("\n".join(report(res)))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
