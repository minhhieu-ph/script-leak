"""Leakage on a real-condition test set, taken apart (v21).

  python -m scriptleak.realdiag --work $W --set real_lotus_th --spoken th --ref th
  python -m scriptleak.realdiag --work $W --set real_ami_en --spoken en --ref en

For each model with a dump of the set:
  A. per stratum (microphone): share of empty outputs, leak rate over all
     utterances, leak rate over the utterances where the model wrote something
  B. leak rate by how hard the utterance is. Hardness is the error of a
     REFERENCE model (--ref) on the same utterance, not of the model scored:
     an utterance that leaks gets a high error by construction, so binning a
     model by its own error would hide its leaks. Pick a reference model that
     rarely leaks on this language (th for Thai speech, en for English). Its
     own row is binned by itself and is marked.
  C. leak rate by utterance duration
  D. of the leaking utterances: other script only, or mixed into the spoken one
and one summary row per model.

Leak = the hypothesis has letters of the other script (the reference has none).
Error is character-level with spaces removed, for both languages.
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import sys
from collections import defaultdict
from typing import Dict, List, Optional

from .languages import get_language
from .metrics import edit_distance
from .normalize import scoring_normalize

FIELDS = (("pred_ctc", "CTC"), ("pred_transducer", "RNNT"))
CER_BINS = ("<30%", "30-60%", "60-90%", ">=90%")
DUR_BINS = ("<1.5s", "1.5-4s", "4-8s", ">=8s")


def cer_bin(c: float) -> str:
    return CER_BINS[0] if c < 0.3 else CER_BINS[1] if c < 0.6 else CER_BINS[2] if c < 0.9 else CER_BINS[3]


def dur_bin(d: float) -> str:
    return DUR_BINS[0] if d < 1.5 else DUR_BINS[1] if d < 4 else DUR_BINS[2] if d < 8 else DUR_BINS[3]


def pct(n: int, d: int) -> str:
    return f"{100.0 * n / d:5.1f}%" if d else "    -"


def utt_key(r: Dict) -> str:
    return str(r.get("audio_filepath") or r.get("key"))


def utt_error(ref: str, hyp: str) -> float:
    ref, hyp = ref.replace(" ", ""), hyp.replace(" ", "")
    return edit_distance(ref, hyp) / len(ref) if ref else 0.0


def load(work: str, b_pct: str, label: str, set_name: str) -> List[Dict]:
    with open(os.path.join(work, "dumps", f"B{b_pct}_{label}", set_name, "utts.jsonl"), encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def analyse(rows: List[Dict], field: str, spoken, other, hardness: Optional[Dict[str, float]]) -> Dict:
    per = defaultdict(lambda: {"n": 0, "empty": 0, "leak": 0, "nonempty": 0})
    by_hard = defaultdict(lambda: [0, 0])
    by_dur = defaultdict(lambda: [0, 0])
    only_other = mixed = 0
    for r in rows:
        ref = scoring_normalize(str(r.get("text", "")))
        if other.script.count(ref) or not spoken.script.count(ref):
            continue
        hyp = scoring_normalize(str(r.get(field, "")))
        leak = other.script.count(hyp) > 0
        for g in (str(r.get("stratum", "ALL")), "ALL"):
            c = per[g]
            c["n"] += 1
            c["empty"] += not hyp.strip()
            c["leak"] += leak
            c["nonempty"] += bool(hyp.strip())
        h = hardness.get(utt_key(r)) if hardness is not None else None
        if h is None:
            h = utt_error(ref, hyp)
        by_hard[cer_bin(h)][0] += 1
        by_hard[cer_bin(h)][1] += leak
        d = float(r.get("duration", 0.0))
        by_dur[dur_bin(d)][0] += 1
        by_dur[dur_bin(d)][1] += leak
        if leak:
            if spoken.script.count(hyp):
                mixed += 1
            else:
                only_other += 1
    return {"per": dict(per), "hard": dict(by_hard), "dur": dict(by_dur),
            "only_other": only_other, "mixed": mixed}


def report(res: Dict, label: str, ref_label: str, other_name: str) -> List[str]:
    out = [f"--- {label}" + ("   (reference model: hardness is its own error)" if label == ref_label else "")]
    out.append(f"A. {'stratum':<16}{'n':>6} {'empty':>7} {'leak/all':>9} {'leak/non-empty':>15}")
    strata = sorted(g for g in res["per"] if g != "ALL") + ["ALL"]
    for g in strata:
        c = res["per"][g]
        out.append(f"   {g:<16}{c['n']:>6} {pct(c['empty'], c['n']):>7} {pct(c['leak'], c['n']):>9} "
                   f"{pct(c['leak'], c['nonempty']):>15}")
    out.append(f"B. leak by hardness ({ref_label} error): " + "  ".join(
        f"{b} {pct(res['hard'].get(b, [0, 0])[1], res['hard'].get(b, [0, 0])[0])} (n={res['hard'].get(b, [0, 0])[0]})"
        for b in CER_BINS))
    out.append("C. leak by duration: " + "  ".join(
        f"{b} {pct(res['dur'].get(b, [0, 0])[1], res['dur'].get(b, [0, 0])[0])} (n={res['dur'].get(b, [0, 0])[0]})"
        for b in DUR_BINS))
    out.append(f"D. leaking utterances: {other_name} only {res['only_other']}, mixed with the spoken script {res['mixed']}")
    return out


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--work", default=os.environ.get("W"), help="the work directory ($W)")
    p.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    p.add_argument("--set", required=True, help="dump name, e.g. real_lotus_th or real_ami_en")
    p.add_argument("--spoken", required=True, help="language spoken in the set (th or en)")
    p.add_argument("--majority", default="th")
    p.add_argument("--minority", default="en")
    p.add_argument("--ref", help="reference model label for hardness (default: th for Thai, en for English)")
    p.add_argument("--models", nargs="*", help="labels to include (default: every model with this dump)")
    p.add_argument("--out", help="write every result as JSON here")
    args = p.parse_args(argv)
    if not args.work:
        p.error("--work (or $W) is required")

    spoken = get_language(args.spoken)
    other = get_language(args.minority if args.spoken == args.majority else args.majority)
    ref_label = args.ref or args.spoken
    labels = args.models or sorted(
        d.split(f"B{args.b_pct}_", 1)[1].split(os.sep)[0]
        for d in glob.glob(os.path.join(args.work, "dumps", f"B{args.b_pct}_*", args.set, "utts.jsonl")))
    if not labels:
        print(f"no dump named {args.set} found under {args.work}/dumps")
        return 1

    everything: Dict = {}
    for field, head in FIELDS:
        hardness = None
        try:
            hardness = {utt_key(r): utt_error(scoring_normalize(str(r.get("text", ""))),
                                              scoring_normalize(str(r.get(field, ""))))
                        for r in load(args.work, args.b_pct, ref_label, args.set) if field in r}
        except OSError:
            print(f"(reference model {ref_label} has no {args.set} dump: hardness falls back to each model's own error)")
        print(f"\n==================== {args.set}, {head} head ====================")
        summary = []
        for label in labels:
            try:
                rows = load(args.work, args.b_pct, label, args.set)
            except OSError as e:
                print(f"({label}: {e})")
                continue
            if not any(field in r for r in rows):
                continue
            res = analyse(rows, field, spoken, other, hardness)
            everything.setdefault(head, {})[label] = res
            print()
            print("\n".join(report(res, label, ref_label, other.name)))
            a = res["per"].get("ALL", {"n": 0, "empty": 0, "leak": 0, "nonempty": 0})
            easy = [res["hard"].get(b, [0, 0]) for b in CER_BINS[:2]]
            en_, el_ = sum(x[0] for x in easy), sum(x[1] for x in easy)
            summary.append((label, a, el_, en_))
        if summary:
            print(f"\n=== {args.set}, {head}: summary ('easy' = {ref_label} error below 60% on the same utterance)")
            print(f"   {'model':<12} {'n':>6} {'empty':>7} {'leak/all':>9} {'leak/non-empty':>15} {'leak|easy':>10} {'n easy':>7}")
            for label, a, el_, en_ in summary:
                mark = " *" if label == ref_label else ""
                print(f"   {label:<12} {a['n']:>6} {pct(a['empty'], a['n']):>7} {pct(a['leak'], a['n']):>9} "
                      f"{pct(a['leak'], a['nonempty']):>15} {pct(el_, en_):>10} {en_:>7}{mark}")
            print(f"   (* reference model: its 'easy' utterances are chosen by its own errors)")
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(everything, f, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
