"""Script-bias calibration on a real dev set, and how small that dev set can be (v25).

Greedy CTC writes the other script in an utterance as soon as one frame's best
token belongs to it. Adding a constant b to the log-probabilities of every
English (Latin) token therefore moves each utterance across a single
threshold:

  Thai speech leaks into Latin    iff  b > m_u = min_t [ max(blank, Thai, neutral)_t - Latin_t ]
  English speech leaks into Thai  iff  b < n_u = max over frames whose best non-Latin token is Thai
                                                   of [ Thai_t - Latin_t ]

so the leak rate of a dump is known exactly for every b from one pass over it.
Per model, b is chosen on the dev sets (LOTUSDIS validation + AMI dev) to
minimise the sum of the two directions, then applied unchanged to the test
sets (LOTUSDIS test + AMI eval). Also reported:

  - the same with one b shared by all models
  - the CER (Thai) / WER (English) cost of the chosen b on the test sets
  - how often a dev subset of n utterances per direction picks the best seed,
    and how well a b chosen on it transfers
  - choosing the seed by the synthetic-noise test sets (MUSAN) instead
  - share of output characters written in the wrong script, by sentence length

CPU only; reads the frame dumps written by dump_logprobs.

  python -m scriptleak.calib --work $W
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import multiprocessing as mp
from typing import Dict, List, Optional, Tuple

import numpy as np

from .decoding import collapse
from .dumpio import iter_dump, read_meta
from .metrics import cer, wer
from .normalize import scoring_normalize
from .realstats import DEFAULT_GROUPS, TH, EN, parse_groups, spoken_other
from .tokenmap import BLANK, MAJ, MIN, NEUTRAL, ids_to_text, token_groups

DEV = ("dev_lotus_th", "dev_ami_en")
TEST = ("real_lotus_th", "real_ami_en")
GRID = np.round(np.arange(-10.0, 10.0001, 0.1), 2)
SIZES = (100, 250, 500, 1000, 2000)
ZERO = int(np.flatnonzero(GRID == 0.0)[0])


# ------------------------------------------------------------------ per dump

def _group_best(logp: np.ndarray, idx: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    if idx.size == 0:
        return np.full(logp.shape[0], -np.inf, np.float32), np.full(logp.shape[0], -1, np.int32)
    sub = logp[:, idx]
    a = sub.argmax(axis=1)
    return sub[np.arange(len(a)), a].astype(np.float32), idx[a].astype(np.int32)


def summarise_dump(dump_dir: str, set_name: str) -> Dict:
    """One pass over a dump. Keeps, for every utterance whose reference is
    purely in the spoken script, its threshold and the per-frame best token of
    each group (enough to decode any b later)."""
    meta = read_meta(dump_dir)
    vocab, blank = meta["vocab"], int(meta["blank_id"])
    groups = token_groups(vocab, TH, EN, blank_id=blank)
    idx = {g: np.flatnonzero(groups == g) for g in (MAJ, MIN, NEUTRAL)}
    spoken, other = spoken_other(set_name)
    english = spoken is EN
    keys, refs, thr, lens, base_leak = [], [], [], [], []
    scores, ids, bounds = [], [], [0]
    for rec, logp in iter_dump(dump_dir):
        ref = scoring_normalize(str(rec.get("text", "")))
        if other.script.count(ref) or not spoken.script.count(ref):
            continue
        s_th, i_th = _group_best(logp, idx[MAJ])
        s_en, i_en = _group_best(logp, idx[MIN])
        s_ne, i_ne = _group_best(logp, idx[NEUTRAL])
        s_bl = logp[:, blank].astype(np.float32)
        if english:
            rest = np.maximum(s_bl, s_ne)
            mask = s_th > rest
            t = float((s_th - s_en)[mask].max()) if mask.any() else -np.inf
        else:
            t = float((np.maximum(np.maximum(s_bl, s_th), s_ne) - s_en).min()) if len(s_en) else np.inf
        keys.append(str(rec.get("audio_filepath")))
        refs.append(ref)
        thr.append(t)
        lens.append(len(ref.replace(" ", "")) if not english else len(ref.split()))
        base_leak.append(other.script.count(scoring_normalize(str(rec.get("pred_ctc", "")))) > 0)
        scores.append(np.stack([s_bl, s_th, s_en, s_ne], 1))
        ids.append(np.stack([np.full(len(s_bl), blank, np.int32), i_th, i_en, i_ne], 1))
        bounds.append(bounds[-1] + len(s_bl))
    return {"set": set_name, "english": english, "keys": keys, "refs": refs,
            "thr": np.array(thr, np.float64), "lens": np.array(lens), "base_leak": np.array(base_leak, bool),
            "scores": np.concatenate(scores) if scores else np.zeros((0, 4), np.float32),
            "ids": np.concatenate(ids) if ids else np.zeros((0, 4), np.int32),
            "bounds": np.array(bounds), "vocab": vocab, "blank": blank}


def leak_mask(s: Dict, b: float) -> np.ndarray:
    return s["thr"] > b if s["english"] else s["thr"] < b


def leak_rate(s: Dict, b: float) -> float:
    return float(leak_mask(s, b).mean()) if len(s["thr"]) else float("nan")


def fast_curve(thr: np.ndarray, english: bool, grid: np.ndarray = GRID) -> np.ndarray:
    """Leak rate at every b of the grid (exactly leak_rate, via sorting)."""
    if len(thr) == 0:
        return np.full(len(grid), np.nan)
    t = np.sort(thr)
    if english:
        return 1.0 - np.searchsorted(t, grid, side="right") / len(t)
    return np.searchsorted(t, grid, side="left") / len(t)


def curve(s: Dict, grid: np.ndarray = GRID) -> np.ndarray:
    return fast_curve(s["thr"], s["english"], grid)


def decode_texts(s: Dict, b: float) -> List[str]:
    sc = s["scores"].copy()
    sc[:, 2] += b
    pick = s["ids"][np.arange(len(sc)), sc.argmax(axis=1)]
    out = []
    for i in range(len(s["bounds"]) - 1):
        out.append(ids_to_text(collapse(pick[s["bounds"][i]:s["bounds"][i + 1]], s["blank"]), s["vocab"]))
    return out


def error_rate(s: Dict, hyps: List[str]) -> float:
    hyps = [scoring_normalize(h) for h in hyps]
    return wer(s["refs"], hyps) if s["english"] else cer(s["refs"], hyps, ignore_spaces=True)


def wrong_script_share(s: Dict, hyps: List[str]) -> np.ndarray:
    """Per utterance: share of letters in the hypothesis that are in the other script."""
    spoken, other = spoken_other(s["set"])
    out = []
    for h in hyps:
        o, p = other.script.count(h), spoken.script.count(h)
        out.append(o / (o + p) if o + p else 0.0)
    return np.array(out)


def best_b(dev_curves: List[np.ndarray], grid: np.ndarray = GRID) -> float:
    tot = np.sum(dev_curves, axis=0)
    cands = np.flatnonzero(np.isclose(tot, tot.min()))
    return float(grid[cands[np.argmin(np.abs(grid[cands]))]])


# ------------------------------------------------------------------ driver

def _dump_dir(work: str, b_pct: str, label: str, set_name: str) -> str:
    return os.path.join(work, "dumps", f"B{b_pct}_{label}", set_name)


def _job(args):
    path, set_name = args
    try:
        return path, summarise_dump(path, set_name)
    except Exception as e:  # one bad dump must not stop the rest
        return path, f"{type(e).__name__}: {e}"


def _synthetic(work: str, b_pct: str, label: str) -> Optional[float]:
    """Mean over noisy strata of the two-direction leak rate on the MUSAN test sets."""
    r = os.path.join(work, "results", f"B{b_pct}_{label}")
    try:
        th = json.load(open(os.path.join(r, "heldout.json"), encoding="utf-8"))
        en = json.load(open(os.path.join(r, "en.json"), encoding="utf-8"))
    except (OSError, ValueError):
        return None
    th, en = th.get("greedy", th), en.get("greedy", en)
    strata = [k for k in th if k != "clean" and k in en and isinstance(th[k], dict) and "slr_u" in th[k]]
    if not strata:
        return None
    return float(np.mean([th[k]["slr_u"] + en[k]["slr_u"] for k in strata]))


def run(work: str, b_pct: str, groups: Dict[str, List[str]], workers: int = 8,
        repeats: int = 200, seed: int = 0, log=print) -> Dict:
    labels = [l for ls in groups.values() for l in ls]
    jobs = [(_dump_dir(work, b_pct, l, s), s) for l in labels for s in DEV + TEST
            if os.path.exists(os.path.join(_dump_dir(work, b_pct, l, s), "meta.json"))]
    log(f"reading {len(jobs)} dumps with {workers} workers ...")
    S: Dict[str, Dict] = {}
    with mp.get_context("spawn").Pool(max(1, workers)) as pool:
        for n, (path, s) in enumerate(pool.imap_unordered(_job, jobs), 1):
            if isinstance(s, str):
                log(f"!! {path}: {s}")
            else:
                S[path] = s
            if n % 8 == 0 or n == len(jobs):
                log(f"  {n}/{len(jobs)}")
    res: Dict = {"models": {}, "groups": {}, "grid": GRID.tolist()}
    ok = []
    for l in labels:
        d = {s: S.get(_dump_dir(work, b_pct, l, s)) for s in DEV + TEST}
        if any(v is None for v in d.values()):
            log(f"   {l}: missing dumps, skipped")
            continue
        ok.append(l)
        res["models"][l] = {"_s": d, "curves": {s: curve(d[s]) for s in DEV + TEST}}
    if not ok:
        return res
    # sanity: b = 0 must reproduce the stored greedy output
    agree = [float(np.mean((res["models"][l]["_s"][s]["thr"] > 0 if res["models"][l]["_s"][s]["english"]
                            else res["models"][l]["_s"][s]["thr"] < 0) == res["models"][l]["_s"][s]["base_leak"]))
             for l in ok for s in DEV + TEST]
    res["agreement_b0"] = float(np.min(agree))
    # one b for all models
    b_glob = best_b([res["models"][l]["curves"][s] for l in ok for s in DEV])
    res["b_global"] = b_glob
    for l in ok:
        m = res["models"][l]
        b = best_b([m["curves"][s] for s in DEV])
        m["b"] = b
        m["synthetic"] = _synthetic(work, b_pct, l)
        for tag, bb in (("b0", 0.0), ("cal", b), ("glob", b_glob)):
            m[tag] = {s: leak_rate(m["_s"][s], bb) for s in DEV + TEST}
            m[tag]["dev"] = m[tag][DEV[0]] + m[tag][DEV[1]]
            m[tag]["test"] = m[tag][TEST[0]] + m[tag][TEST[1]]
        for s in TEST:
            h0, h1 = decode_texts(m["_s"][s], 0.0), decode_texts(m["_s"][s], b)
            m.setdefault("err", {})[s] = (error_rate(m["_s"][s], h0), error_rate(m["_s"][s], h1))
            m.setdefault("share", {})[s] = (wrong_script_share(m["_s"][s], h0), wrong_script_share(m["_s"][s], h1))
    rng = np.random.default_rng(seed)
    for g, ls in groups.items():
        ls = [l for l in ls if l in ok]
        if not ls:
            continue
        info = {}
        for tag in ("b0", "cal", "glob"):
            t = np.array([res["models"][l][tag]["test"] for l in ls])
            info[tag] = {"mean": float(t.mean()), "sd": float(t.std(ddof=1)) if len(t) > 1 else 0.0,
                         "min": float(t.min()), "max": float(t.max())}
        pick = min(ls, key=lambda l: res["models"][l]["b0"]["dev"])
        info["dev_pick"] = {"label": pick, "test": res["models"][pick]["b0"]["test"]}
        pick = min(ls, key=lambda l: res["models"][l]["cal"]["dev"])
        info["dev_pick_cal"] = {"label": pick, "test": res["models"][pick]["cal"]["test"]}
        syn = [l for l in ls if res["models"][l]["synthetic"] is not None]
        if len(syn) == len(ls):
            pick = min(ls, key=lambda l: res["models"][l]["synthetic"])
            info["synthetic_pick"] = {"label": pick, "test": res["models"][pick]["b0"]["test"]}
        info["oracle"] = min(res["models"][l]["b0"]["test"] for l in ls)
        # dev size: n utterances per direction, drawn with replacement-free sampling
        oracle_l = min(ls, key=lambda l: res["models"][l]["b0"]["test"])
        sizes = {}
        for n in SIZES:
            hits, sel_t, cal_t = 0, [], []
            for _ in range(repeats):
                devs = {s: rng.choice(len(res["models"][ls[0]]["_s"][s]["thr"]),
                                      size=min(n, len(res["models"][ls[0]]["_s"][s]["thr"])), replace=False)
                        for s in DEV}
                cs = {}
                for l in ls:
                    st = res["models"][l]["_s"]
                    cs[l] = [fast_curve(st[s]["thr"][devs[s]] if len(st[s]["thr"]) == len(res["models"][ls[0]]["_s"][s]["thr"])
                                        else st[s]["thr"], st[s]["english"]) for s in DEV]
                p = min(ls, key=lambda l: sum(c[ZERO] for c in cs[l]))
                hits += p == oracle_l
                sel_t.append(res["models"][p]["b0"]["test"])
                for l in ls:
                    bb = best_b(cs[l])
                    st = res["models"][l]["_s"]
                    cal_t.append(leak_rate(st[TEST[0]], bb) + leak_rate(st[TEST[1]], bb))
            sizes[n] = {"p_oracle": hits / repeats, "select_test": float(np.mean(sel_t)),
                        "cal_test": float(np.mean(cal_t)), "cal_test_p90": float(np.percentile(cal_t, 90))}
        info["dev_size"] = sizes
        info["dev_n"] = {s: int(len(res["models"][ls[0]]["_s"][s]["thr"])) for s in DEV}
        res["groups"][g] = info
    syn = [l for l in ok if res["models"][l]["synthetic"] is not None]
    if len(syn) >= 4:
        x = np.array([res["models"][l]["synthetic"] for l in syn])
        y = np.array([res["models"][l]["b0"]["test"] for l in syn])
        rk = lambda v: np.argsort(np.argsort(v))
        res["synthetic_vs_real"] = {"n": len(syn), "spearman": float(np.corrcoef(rk(x), rk(y))[0, 1])}
    # length effect: wrong-script share vs any-leak rate, all models pooled
    bins = {"th": ((0, 6), (7, 15), (16, 30), (31, 10**9)), "en": ((0, 3), (4, 8), (9, 15), (16, 10**9))}
    res["length"] = {}
    for s in TEST:
        st0 = res["models"][ok[0]]["_s"][s]
        lens = st0["lens"]
        key = "en" if st0["english"] else "th"
        rows = []
        for lo, hi in bins[key]:
            sel = (lens >= lo) & (lens <= hi)
            if not sel.any():
                continue
            anyl = np.mean([leak_mask(res["models"][l]["_s"][s], 0.0)[sel].mean() for l in ok
                            if len(res["models"][l]["_s"][s]["thr"]) == len(lens)])
            share = np.mean([res["models"][l]["share"][s][0][sel].mean() for l in ok
                             if len(res["models"][l]["share"][s][0]) == len(lens)])
            rows.append({"bin": f"{lo}-{hi if hi < 10**9 else ''}", "n": int(sel.sum()),
                         "any_leak": float(anyl), "wrong_share": float(share)})
        res["length"][s] = {"unit": "words" if key == "en" else "Thai characters", "rows": rows}
    return res


def report(res: Dict) -> List[str]:
    L = []
    if "agreement_b0" in res:
        L.append(f"Check: with b = 0 the thresholds reproduce the stored greedy output on "
                 f"{res['agreement_b0']:.2%} of utterances (worst dump).")
        L.append(f"One b shared by all models (chosen on dev): {res['b_global']:+.1f}  "
                 f"(b > 0 favours Latin, b < 0 favours Thai)")
    L.append("\nPer model, test sets (Thai->Latin on LOTUSDIS / English->Thai on AMI, sum):")
    L.append(f"  {'model':<10} {'b':>5}   {'as trained':>23}   {'b chosen on dev':>23}   {'shared b':>9}"
             f"   {'CER Thai':>15}   {'WER English':>15}")
    for l, m in res["models"].items():
        if "b0" not in m:
            continue
        f = lambda d: f"{d[TEST[0]]:5.1%}/{d[TEST[1]]:5.1%} {d['test']:6.1%}"
        e = m["err"]
        L.append(f"  {l:<10} {m['b']:+5.1f}   {f(m['b0']):>23}   {f(m['cal']):>23}   {m['glob']['test']:9.1%}"
                 f"   {e[TEST[0]][0]:6.1%}->{e[TEST[0]][1]:6.1%}   {e[TEST[1]][0]:6.1%}->{e[TEST[1]][1]:6.1%}")
    L.append("\nPer recipe, test sum over seeds (mean, sd, range):")
    for g, v in res["groups"].items():
        for tag, name in (("b0", "as trained"), ("cal", "b per model"), ("glob", "shared b")):
            x = v[tag]
            L.append(f"  {g:<6} {name:<12} mean {x['mean']:6.1%}  sd {x['sd']:5.1%}  range {x['min']:5.1%}-{x['max']:5.1%}")
        extra = f"  {g:<6} oracle seed {v['oracle']:.1%} | dev picks {v['dev_pick']['test']:.1%} ({v['dev_pick']['label']})" \
                f" | dev picks after b {v['dev_pick_cal']['test']:.1%} ({v['dev_pick_cal']['label']})"
        if "synthetic_pick" in v:
            extra += f" | MUSAN picks {v['synthetic_pick']['test']:.1%} ({v['synthetic_pick']['label']})"
        L.append(extra)
    if "synthetic_vs_real" in res:
        r = res["synthetic_vs_real"]
        L.append(f"\nMUSAN (synthetic noise) vs real test, final models: Spearman {r['spearman']:.2f} over {r['n']} models")
    L.append("\nHow small can the dev set be? (n utterances per direction, random subsets; "
             "n at or above the dev size = the whole dev set)")
    for g, v in list(res["groups"].items())[:1]:
        L.append("  dev size: " + ", ".join(f"{s} {n}" for s, n in v.get("dev_n", {}).items()))
    L.append(f"  {'recipe':<6} {'n':>5}  {'P(dev picks best seed)':>23}  {'test of picked':>15}  "
             f"{'test after b (mean)':>20}  {'(90th pct)':>11}")
    for g, v in res["groups"].items():
        for n, x in v["dev_size"].items():
            L.append(f"  {g:<6} {n:>5}  {x['p_oracle']:23.0%}  {x['select_test']:15.1%}  {x['cal_test']:20.1%}  "
                     f"{x['cal_test_p90']:11.1%}")
    L.append("\nLength: share of utterances with any leak vs share of output letters in the wrong script (b = 0, all models)")
    for s, v in res.get("length", {}).items():
        L.append(f"  {s} (length in {v['unit']})")
        for r in v["rows"]:
            L.append(f"    {r['bin']:>8}  n={r['n']:>5}  any leak {r['any_leak']:6.1%}  wrong-script letters {r['wrong_share']:6.2%}")
    return L


def _jsonable(res: Dict) -> Dict:
    out = {k: v for k, v in res.items() if k != "models"}
    out["models"] = {}
    for l, m in res["models"].items():
        out["models"][l] = {k: v for k, v in m.items() if k not in ("_s", "curves", "share")}
        out["models"][l]["curves"] = {s: c.tolist() for s, c in m.get("curves", {}).items()}
    return out


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--work", default=os.environ.get("W"))
    p.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    p.add_argument("--groups", nargs="*", default=DEFAULT_GROUPS)
    p.add_argument("--workers", type=int, default=int(os.environ.get("CALIB_WORKERS", "16")))
    p.add_argument("--repeats", type=int, default=200)
    p.add_argument("--out")
    args = p.parse_args(argv)
    if not args.work:
        p.error("--work (or $W) is required")
    res = run(args.work, args.b_pct, parse_groups(args.groups), args.workers, args.repeats)
    if not res["groups"]:
        print("no model has dumps on all four dev/test sets (run 'selectC' first)")
        return 1
    print("\n".join(report(res)))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(_jsonable(res), f, ensure_ascii=False, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
