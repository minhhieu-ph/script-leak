"""How noisy is each training block?

Phase A suggests the model ties background noise to the minority language.
That needs the minority block to be noisier than the majority block. This
measures it directly on a sample of each manifest, with two crude numbers per
utterance from 25 ms frame energies:

  floor_db    level of the quiet frames (5th percentile), in dB full scale
  range_db    loud frames minus quiet frames (95th - 5th percentile): a rough
              signal-to-noise ratio; clean studio speech has a large range

  python -m scriptleak.noisefloor --manifest th=th_central.train.jsonl en=en_train.clean.jsonl
"""

from __future__ import annotations

import argparse
import sys
from typing import Dict, List, Optional

import numpy as np

from .audio import to_mono
from .manifest import read_manifest


def frame_db(x: np.ndarray, sr: int, win: float = 0.025, hop: float = 0.010) -> np.ndarray:
    n, h = max(1, int(win * sr)), max(1, int(hop * sr))
    if len(x) < n:
        return np.zeros(0)
    idx = np.arange(0, len(x) - n + 1, h)
    c = np.concatenate([[0.0], np.cumsum(np.square(x, dtype=np.float64))])
    e = (c[idx + n] - c[idx]) / n
    return 10.0 * np.log10(np.maximum(e, 1e-12))


DIGITAL_SILENCE_DB = -90.0


def utterance_stats(x: np.ndarray, sr: int) -> Optional[Dict[str, float]]:
    """floor_db / range_db: over all frames (as in v14).
    silence_share: share of frames below -90 dBFS, i.e. digital silence such as
    zero padding, which no microphone produces.
    snr_db: 95th minus 10th percentile of the frames that are NOT digital
    silence, a crude SNR that padding cannot inflate."""
    db = frame_db(x, sr)
    if len(db) < 10:
        return None
    lo, hi = np.percentile(db, [5, 95])
    live = db[db > DIGITAL_SILENCE_DB]
    out = {"floor_db": float(lo), "range_db": float(hi - lo),
           "silence_share": float(1.0 - len(live) / len(db))}
    if len(live) >= 10:
        a, b = np.percentile(live, [10, 95])
        out["snr_db"] = float(b - a)
        out["live_floor_db"] = float(a)
    return out


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--manifest", nargs="+", required=True, metavar="NAME=PATH")
    p.add_argument("--sample", type=int, default=1000)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args(argv)

    import soundfile as sf

    print(f"{'block':<16} {'n':>5} {'floor dB':>9} {'range dB':>9} {'silence':>8} {'live floor':>11} "
          f"{'SNR dB':>7} {'SNR 10%-90%':>13}")
    print("(medians over utterances; 'live' = frames above -90 dBFS, so zero padding does not count)")
    for item in args.manifest:
        name, path = item.split("=", 1)
        entries = list(read_manifest(path))
        if len(entries) > args.sample:
            pick = np.random.default_rng(args.seed).choice(len(entries), args.sample, replace=False)
            entries = [entries[i] for i in pick.tolist()]
        rows = []
        for e in entries:
            x, sr = sf.read(e["audio_filepath"], dtype="float32", always_2d=False)
            st = utterance_stats(to_mono(x), sr)
            if st:
                rows.append(st)
        if not rows:
            print(f"{name:<16} no readable audio")
            continue
        fl = np.array([r["floor_db"] for r in rows])
        rg = np.array([r["range_db"] for r in rows])
        si = np.array([r["silence_share"] for r in rows])
        sn = np.array([r["snr_db"] for r in rows if "snr_db" in r])
        lf = np.array([r["live_floor_db"] for r in rows if "live_floor_db" in r])
        snr_txt = f"{np.median(sn):>7.1f} {np.percentile(sn, 10):>6.1f}-{np.percentile(sn, 90):<6.1f}" if len(sn) else "      -"
        print(f"{name:<16} {len(rows):>5} {np.median(fl):>9.1f} {np.median(rg):>9.1f} {np.mean(si):>8.1%} "
              f"{(np.median(lf) if len(lf) else float('nan')):>11.1f} {snr_txt}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
