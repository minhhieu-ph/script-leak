"""Noise augmentation of a training manifest, done once, on disk.

Phase B asks a causal question: does the model leak because background noise
goes with one language in the training data? So the noise must be put on
chosen language blocks only, and it must come from noise files that are never
used for testing (noise.noise_split == "train").

Step 1 writes a noisy copy for a share of the utterances of every language:

  python -m scriptleak.augment make --manifest train_th300_en20.jsonl \\
      --noise-dir /data/musan/noise --out-dir /data/aug/base \\
      --out train_th300_en20.aug.jsonl --prob 0.5 --snr-min 0 --snr-max 20

Each chosen utterance keeps its original path in `clean_filepath`. Which
utterances are chosen, the noise file and the SNR depend only on the audio
path and --seed, so the three variants below share the same noisy files.

Step 2 picks the blocks that stay noisy (the others go back to clean audio):

  python -m scriptleak.augment select --manifest train_th300_en20.aug.jsonl \\
      --langs th en --out train_aug-both.jsonl     # both blocks
  python -m scriptleak.augment select ... --langs en --out train_aug-en.jsonl

`make-rir` (v23) puts room reverberation on a share of the utterances of EVERY
language, plus background noise on most of those: a closer match to far-field
recordings than additive noise alone, and balanced across blocks by design.

  python -m scriptleak.augment make-rir --manifest train_th300_en20.jsonl \
      --rir-dir /data/RIRS_NOISES --noise-dir /data/musan --out-dir /data/aug_rir \
      --out train_rir-both.jsonl --prob 0.5 --noise-prob 0.7

`filter-heldout` keeps the test utterances whose noise file is in the "test"
split (and everything that has no noise file):

  python -m scriptleak.augment filter-heldout --manifest th_test.strata.jsonl \\
      --out th_test.heldout.jsonl
"""

from __future__ import annotations

import argparse
import glob
import os
import sys
from collections import Counter
from typing import Dict, List, Optional

import numpy as np

from .audio import resample, to_mono
from .manifest import read_manifest, write_manifest
from .noise import _seed_for, mix_at_snr, noise_split


def plan(entry: Dict, noise_files: List[str], prob: float, snr_min: float, snr_max: float,
         seed: int) -> Optional[Dict]:
    """The augmentation of one utterance, or None if it stays clean."""
    rng = np.random.default_rng(_seed_for(entry["audio_filepath"], seed))
    if rng.random() >= prob:
        return None
    return {"noise_file": noise_files[int(rng.integers(0, len(noise_files)))],
            "snr": float(snr_min + (snr_max - snr_min) * rng.random())}


def _work(job: Dict) -> Dict:
    import soundfile as sf

    e, pl = job["entry"], job["plan"]
    out = dict(e)
    if pl is None:
        return out
    path = job["out_path"]
    if not os.path.exists(path):
        speech, sr = sf.read(e["audio_filepath"], dtype="float32", always_2d=False)
        noise, nsr = sf.read(pl["noise_file"], dtype="float32", always_2d=False)
        noise = resample(to_mono(noise), nsr, sr)
        rng = np.random.default_rng(_seed_for(e["audio_filepath"], job["seed"] + 1))
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp.wav"
        sf.write(tmp, mix_at_snr(to_mono(speech), noise, pl["snr"], rng), sr, subtype="PCM_16")
        os.replace(tmp, path)
    out.update({"clean_filepath": e["audio_filepath"], "audio_filepath": path,
                "noise_file": pl["noise_file"], "aug_snr": round(pl["snr"], 2)})
    return out


def make(args) -> int:
    files = sorted(glob.glob(os.path.join(args.noise_dir, "**", "*.wav"), recursive=True))
    files = [f for f in files if noise_split(f) == "train"]
    if not files:
        raise SystemExit(f"No training-split noise files under {args.noise_dir}")
    entries = list(read_manifest(args.manifest))
    jobs = []
    for i, e in enumerate(entries):
        pl = plan(e, files, args.prob, args.snr_min, args.snr_max, args.seed)
        jobs.append({"entry": e, "plan": pl, "seed": args.seed,
                     "out_path": os.path.join(args.out_dir, f"{i // 10000:04d}", f"{i:08d}.wav")})
    n_aug = sum(j["plan"] is not None for j in jobs)
    print(f"{len(files)} training-split noise files; {n_aug}/{len(jobs)} utterances get noise", flush=True)
    if args.num_workers <= 1:
        out = [_work(j) for j in jobs]
    else:
        import multiprocessing as mp

        out = []
        with mp.get_context("spawn").Pool(args.num_workers) as pool:
            for k, r in enumerate(pool.imap(_work, jobs, chunksize=64), 1):
                out.append(r)
                if k % 20000 == 0:
                    print(f"  {k}/{len(jobs)}", flush=True)
    write_manifest(args.out, out)
    by = Counter(str(e.get("lang", "?")) for e in out if "clean_filepath" in e)
    print(f"Wrote {args.out}; noisy utterances per language: {dict(by)}")
    return 0


def rir_files(rir_dir: str) -> List[str]:
    """Room impulse responses of the OpenSLR 28 package (simulated and real),
    without its noise recordings, training split only."""
    out = []
    for f in sorted(glob.glob(os.path.join(rir_dir, "**", "*.wav"), recursive=True)):
        low = f.lower()
        if "pointsource_noises" in low or "noise" in os.path.basename(low):
            continue
        if noise_split(f) == "train":
            out.append(f)
    return out


def apply_rir(x: np.ndarray, h: np.ndarray) -> np.ndarray:
    """Reverberate x with h, aligned on the direct path (the RIR peak), same
    length and level as x."""
    from scipy.signal import fftconvolve

    from .noise import rms

    h = to_mono(h).astype(np.float64)
    if len(h) == 0 or not np.any(h):
        return x.astype(np.float32)
    peak = int(np.argmax(np.abs(h)))
    y = fftconvolve(x.astype(np.float64), h)[peak:peak + len(x)]
    if len(y) < len(x):
        y = np.pad(y, (0, len(x) - len(y)))
    r = rms(y)
    y = y * (rms(x) / r) if r > 0 else y
    m = float(np.max(np.abs(y))) if len(y) else 0.0
    if m > 0.999:
        y = y * (0.999 / m)
    return y.astype(np.float32)


def plan_rir(entry: Dict, rirs: List[str], noises: List[str], prob: float, noise_prob: float,
             snr_min: float, snr_max: float, seed: int) -> Optional[Dict]:
    rng = np.random.default_rng(_seed_for(entry["audio_filepath"], seed + 500))
    if rng.random() >= prob:
        return None
    pl = {"rir_file": rirs[int(rng.integers(0, len(rirs)))]}
    if noises and rng.random() < noise_prob:
        pl.update({"noise_file": noises[int(rng.integers(0, len(noises)))],
                   "snr": float(snr_min + (snr_max - snr_min) * rng.random())})
    return pl


def _work_rir(job: Dict) -> Dict:
    import soundfile as sf

    e, pl = job["entry"], job["plan"]
    out = dict(e)
    if pl is None:
        return out
    path = job["out_path"]
    if not os.path.exists(path):
        speech, sr = sf.read(e["audio_filepath"], dtype="float32", always_2d=False)
        h, hsr = sf.read(pl["rir_file"], dtype="float32", always_2d=True)
        h = resample(h[:, 0], hsr, sr)
        y = apply_rir(to_mono(speech), h)
        if "noise_file" in pl:
            noise, nsr = sf.read(pl["noise_file"], dtype="float32", always_2d=False)
            noise = resample(to_mono(noise), nsr, sr)
            rng = np.random.default_rng(_seed_for(e["audio_filepath"], job["seed"] + 501))
            y = mix_at_snr(y, noise, pl["snr"], rng)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp.wav"
        sf.write(tmp, y, sr, subtype="PCM_16")
        os.replace(tmp, path)
    out.update({"clean_filepath": e["audio_filepath"], "audio_filepath": path, "rir_file": pl["rir_file"]})
    if "noise_file" in pl:
        out.update({"noise_file": pl["noise_file"], "aug_snr": round(pl["snr"], 2)})
    return out


def make_rir(args) -> int:
    rirs = rir_files(args.rir_dir)
    if not rirs:
        raise SystemExit(f"No room impulse responses under {args.rir_dir}")
    noises = []
    for sub in args.noise_subdirs:
        noises += sorted(f for f in glob.glob(os.path.join(args.noise_dir, sub, "**", "*.wav"), recursive=True)
                         if noise_split(f) == "train")
    entries = list(read_manifest(args.manifest))
    jobs = []
    for i, e in enumerate(entries):
        pl = plan_rir(e, rirs, noises, args.prob, args.noise_prob, args.snr_min, args.snr_max, args.seed)
        jobs.append({"entry": e, "plan": pl, "seed": args.seed,
                     "out_path": os.path.join(args.out_dir, f"{i // 10000:04d}", f"{i:08d}.wav")})
    n_aug = sum(j["plan"] is not None for j in jobs)
    n_noise = sum(1 for j in jobs if j["plan"] and "noise_file" in j["plan"])
    print(f"{len(rirs)} training-split RIRs, {len(noises)} noise/music files; "
          f"{n_aug}/{len(jobs)} utterances reverberated, {n_noise} of them also get noise", flush=True)
    import multiprocessing as mp

    out = []
    with mp.get_context("spawn").Pool(max(1, args.num_workers)) as pool:
        for k, r in enumerate(pool.imap(_work_rir, jobs, chunksize=64), 1):
            out.append(r)
            if k % 20000 == 0:
                print(f"  {k}/{len(jobs)}", flush=True)
    write_manifest(args.out, out)
    by = Counter(str(e.get("lang", "?")) for e in out if "clean_filepath" in e)
    print(f"Wrote {args.out}; augmented utterances per language: {dict(by)}")
    return 0


def select_entries(entries: List[Dict], langs: List[str]) -> List[Dict]:
    """Keep the noisy copy only for the given languages."""
    out = []
    for e in entries:
        e = dict(e)
        if "clean_filepath" in e and str(e.get("lang")) not in langs:
            e["audio_filepath"] = e.pop("clean_filepath")
            e.pop("noise_file", None)
            e.pop("aug_snr", None)
        out.append(e)
    return out


def select(args) -> int:
    out = select_entries(list(read_manifest(args.manifest)), args.langs)
    write_manifest(args.out, out)
    by = Counter(str(e.get("lang", "?")) for e in out if "clean_filepath" in e)
    print(f"Wrote {args.out}; noisy utterances per language: {dict(by)}")
    return 0


def heldout_entries(entries: List[Dict]) -> List[Dict]:
    return [e for e in entries if not e.get("noise_file") or noise_split(e["noise_file"]) == "test"]


def filter_heldout(args) -> int:
    entries = list(read_manifest(args.manifest))
    out = heldout_entries(entries)
    write_manifest(args.out, out)
    by = Counter(str(e.get("stratum", "?")) for e in out)
    print(f"Wrote {args.out}: {len(out)}/{len(entries)} utterances; per stratum {dict(sorted(by.items()))}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("make")
    a.add_argument("--manifest", required=True)
    a.add_argument("--noise-dir", required=True)
    a.add_argument("--out-dir", required=True)
    a.add_argument("--out", required=True)
    a.add_argument("--prob", type=float, default=0.5)
    a.add_argument("--snr-min", type=float, default=0.0)
    a.add_argument("--snr-max", type=float, default=20.0)
    a.add_argument("--seed", type=int, default=0)
    a.add_argument("--num-workers", type=int, default=16)
    a = sub.add_parser("make-rir")
    a.add_argument("--manifest", required=True)
    a.add_argument("--rir-dir", required=True, help="OpenSLR 28 (RIRS_NOISES) folder")
    a.add_argument("--noise-dir", required=True, help="MUSAN folder")
    a.add_argument("--noise-subdirs", nargs="*", default=["noise", "music"])
    a.add_argument("--out-dir", required=True)
    a.add_argument("--out", required=True)
    a.add_argument("--prob", type=float, default=0.5)
    a.add_argument("--noise-prob", type=float, default=0.7)
    a.add_argument("--snr-min", type=float, default=0.0)
    a.add_argument("--snr-max", type=float, default=20.0)
    a.add_argument("--seed", type=int, default=0)
    a.add_argument("--num-workers", type=int, default=16)
    a = sub.add_parser("select")
    a.add_argument("--manifest", required=True)
    a.add_argument("--langs", nargs="*", required=True)
    a.add_argument("--out", required=True)
    a = sub.add_parser("filter-heldout")
    a.add_argument("--manifest", required=True)
    a.add_argument("--out", required=True)
    args = p.parse_args(argv)
    return {"make": make, "make-rir": make_rir, "select": select,
            "filter-heldout": filter_heldout}[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
