"""Probe test sets for phase A: which distortions make the model leak?

From clean majority-language utterances this writes one stratum per
distortion (the clean copy is kept as stratum "clean"):

  white10, white0     white noise at 10 and 0 dB SNR
  reverb              a synthetic room (exponentially decaying noise, RT60 0.6 s)
  tel                 telephone band, 300-3400 Hz
  clip                hard clipping at 10% of the peak
  gain-20/-30/-40     the level lowered by 20, 30, 40 dB (quiet audio)

and, in a second manifest, audio without any speech (empty reference):

  noise_only          5 s cuts of the noise files at a normal speech level
  noise_quiet         the same cuts 30 dB lower
  silence             near-digital silence

  python -m scriptleak.probes --manifest th_central.test.jsonl \\
      --noise-dir /data/musan/noise --out-dir /data/probeA \\
      --out-manifest th_probes.jsonl --out-nonspeech nonspeech.jsonl --max-utts 2000

Deterministic for a given --seed. Needs soundfile and scipy.
"""

from __future__ import annotations

import argparse
import glob
import os
import sys
from typing import Callable, Dict, List, Optional

import numpy as np

from .audio import resample, to_mono
from .manifest import read_manifest, write_manifest
from .noise import _seed_for, fit_noise, rms

SPEECH_RMS = 0.05  # a typical level of read speech in [-1, 1] samples


def add_white(x: np.ndarray, snr_db: float, rng: np.random.Generator) -> np.ndarray:
    r = rms(x)
    if r == 0.0:
        return x.copy()
    noise = rng.standard_normal(len(x)).astype(np.float32)
    return _no_clip(x + noise * (r / (rms(noise) * 10.0 ** (snr_db / 20.0))))


def reverb(x: np.ndarray, sr: int, rng: np.random.Generator, rt60: float = 0.6) -> np.ndarray:
    from scipy.signal import fftconvolve

    n = int(rt60 * sr)
    t = np.arange(n) / float(sr)
    h = rng.standard_normal(n) * np.exp(-6.908 * t / rt60) * 0.3
    h[0] = 1.0
    y = fftconvolve(x.astype(np.float64), h)[: len(x)].astype(np.float32)
    r = rms(y)
    return _no_clip(y * (rms(x) / r)) if r > 0 else y


def telephone(x: np.ndarray, sr: int) -> np.ndarray:
    from scipy.signal import butter, sosfiltfilt

    hi = min(3400.0, 0.45 * sr)
    sos = butter(4, [300.0, hi], btype="bandpass", fs=sr, output="sos")
    return _no_clip(sosfiltfilt(sos, x.astype(np.float64)).astype(np.float32))


def clip(x: np.ndarray, fraction: float = 0.1) -> np.ndarray:
    peak = float(np.max(np.abs(x))) if len(x) else 0.0
    if peak == 0.0:
        return x.copy()
    lim = fraction * peak
    return np.clip(x, -lim, lim).astype(np.float32)


def gain(x: np.ndarray, db: float) -> np.ndarray:
    return (x * 10.0 ** (db / 20.0)).astype(np.float32)


def _no_clip(x: np.ndarray) -> np.ndarray:
    peak = float(np.max(np.abs(x))) if len(x) else 0.0
    return (x * (0.999 / peak) if peak > 0.999 else x).astype(np.float32)


def distortions(sr: int) -> "Dict[str, Callable[[np.ndarray, np.random.Generator], np.ndarray]]":
    return {
        "white10": lambda x, rng: add_white(x, 10.0, rng),
        "white0": lambda x, rng: add_white(x, 0.0, rng),
        "reverb": lambda x, rng: reverb(x, sr, rng),
        "tel": lambda x, rng: telephone(x, sr),
        "clip": lambda x, rng: clip(x),
        "gain-20": lambda x, rng: gain(x, -20.0),
        "gain-30": lambda x, rng: gain(x, -30.0),
        "gain-40": lambda x, rng: gain(x, -40.0),
    }


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--manifest", required=True, help="clean majority-language test manifest")
    p.add_argument("--noise-dir", help="noise .wav files for the no-speech strata")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--out-manifest", required=True)
    p.add_argument("--out-nonspeech", help="manifest of the no-speech strata (needs --noise-dir)")
    p.add_argument("--max-utts", type=int, default=2000)
    p.add_argument("--nonspeech-utts", type=int, default=1000)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--stratum-field", default="stratum")
    args = p.parse_args(argv)

    import soundfile as sf

    entries = list(read_manifest(args.manifest))
    if len(entries) > args.max_utts:
        pick = np.random.default_rng(args.seed).choice(len(entries), args.max_utts, replace=False)
        entries = [entries[i] for i in sorted(pick.tolist())]

    out: List[Dict] = []
    sr_seen = 16000
    for i, e in enumerate(entries):
        x, sr = sf.read(e["audio_filepath"], dtype="float32", always_2d=False)
        x = to_mono(x)
        sr_seen = sr
        clean = dict(e)
        clean[args.stratum_field] = "clean"
        out.append(clean)
        for k, (name, fn) in enumerate(distortions(sr).items()):
            rng = np.random.default_rng(_seed_for(e["audio_filepath"], args.seed + 10 + k))
            path = os.path.join(args.out_dir, name, f"{i:07d}.wav")
            os.makedirs(os.path.dirname(path), exist_ok=True)
            sf.write(path, fn(x, rng), sr, subtype="PCM_16")
            d = dict(e)
            d["audio_filepath"] = path
            d[args.stratum_field] = name
            out.append(d)
        if (i + 1) % 500 == 0:
            print(f"{i + 1}/{len(entries)} utterances", flush=True)
    write_manifest(args.out_manifest, out)
    print(f"Wrote {len(out)} entries to {args.out_manifest}")

    if args.out_nonspeech:
        if not args.noise_dir:
            raise SystemExit("--out-nonspeech needs --noise-dir")
        files = sorted(glob.glob(os.path.join(args.noise_dir, "**", "*.wav"), recursive=True))
        if not files:
            raise SystemExit(f"No .wav files under {args.noise_dir}")
        lang = entries[0].get("lang") if entries else None
        rng = np.random.default_rng(args.seed + 99)
        ns: List[Dict] = []
        seconds = 5.0
        for i in range(args.nonspeech_utts):
            path_in = files[int(rng.integers(0, len(files)))]
            noise, nsr = sf.read(path_in, dtype="float32", always_2d=False)
            seg = fit_noise(resample(to_mono(noise), nsr, sr_seen), int(seconds * sr_seen), rng)
            r = rms(seg)
            seg = seg * (SPEECH_RMS / r) if r > 0 else seg
            variants = {
                "noise_only": _no_clip(seg),
                "noise_quiet": gain(_no_clip(seg), -30.0),
                "silence": (rng.standard_normal(len(seg)) * 1e-4).astype(np.float32),
            }
            for name, y in variants.items():
                if name == "silence" and i >= args.nonspeech_utts // 5:
                    continue
                path = os.path.join(args.out_dir, name, f"{i:07d}.wav")
                os.makedirs(os.path.dirname(path), exist_ok=True)
                sf.write(path, y, sr_seen, subtype="PCM_16")
                rec = {"audio_filepath": path, "duration": seconds, "text": "",
                       args.stratum_field: name, "noise_file": path_in}
                if lang:
                    rec["lang"] = lang
                ns.append(rec)
        write_manifest(args.out_nonspeech, ns)
        print(f"Wrote {len(ns)} entries to {args.out_nonspeech}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
