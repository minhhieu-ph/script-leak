"""A small character n-gram language model (stupid backoff).

Used as the "does this read like the language?" score of the acceptance test:
a leaked Latin span such as "sh wonge" scores low under an English model,
while a real English phrase scores high. Pure Python, no dependencies, small
enough to run on a device.

  lm = CharNgram(order=5).fit(["the cat sat", "on the mat"])
  lm.score("the mat")      # mean log10 probability per character
"""

from __future__ import annotations

import math
from typing import Dict, Iterable

EMPTY_SCORE = -10.0


class CharNgram:
    def __init__(self, order: int = 5, backoff: float = 0.4):
        if order < 1:
            raise ValueError("order must be at least 1")
        self.order = order
        self.backoff = backoff
        self.ngrams: Dict[str, int] = {}    # context + char -> count
        self.contexts: Dict[str, int] = {}  # context -> count
        self.chars = set()
        self.total = 0

    def fit(self, texts: Iterable[str]) -> "CharNgram":
        ngrams, contexts = self.ngrams, self.contexts
        for text in texts:
            text = " ".join(str(text).split())
            if not text:
                continue
            s = " " + text + " "
            for i in range(1, len(s)):
                ch = s[i]
                self.chars.add(ch)
                self.total += 1
                for k in range(0, min(self.order - 1, i) + 1):
                    ctx = s[i - k:i]
                    key = ctx + ch
                    ngrams[key] = ngrams.get(key, 0) + 1
                    contexts[ctx] = contexts.get(ctx, 0) + 1
        return self

    def _logprob(self, ctx: str, ch: str) -> float:
        penalty = 0.0
        for k in range(min(self.order - 1, len(ctx)), -1, -1):
            c = ctx[len(ctx) - k:] if k else ""
            n = self.ngrams.get(c + ch, 0)
            if n:
                return penalty + math.log10(n / self.contexts[c])
            penalty += math.log10(self.backoff)
        # unseen character
        return penalty + math.log10(1.0 / (self.total + len(self.chars) + 1))

    def score(self, text: str) -> float:
        """Mean log10 probability per character (higher = more plausible).
        The text is scored as a whole phrase, with its boundaries."""
        text = " ".join(str(text).split())
        if not text or not self.total:
            return EMPTY_SCORE
        s = " " + text + " "
        lp = 0.0
        for i in range(1, len(s)):
            lp += self._logprob(s[max(0, i - self.order + 1):i], s[i])
        return lp / (len(s) - 1)

    def vocabulary(self, texts: Iterable[str]) -> set:
        """Convenience: the set of words in `texts` (for a lexicon feature)."""
        words = set()
        for t in texts:
            words.update(str(t).split())
        return words
