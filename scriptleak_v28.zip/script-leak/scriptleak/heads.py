"""Do the CTC and transducer heads leak on the same utterances?

Phase A measured the frame-level mechanism on the CTC head only. This
cross-tabulates, per stratum, which head writes minority-script letters on
majority-language speech (reference without minority letters):

  python -m scriptleak.heads --manifest dumps/B20_both/heldout_rnnt/utts.jsonl \\
      --majority th --minority en --group-by stratum
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import OrderedDict
from typing import Dict, List, Optional

from .languages import get_language
from .manifest import read_manifest
from .normalize import scoring_normalize


def crosstab(rows: List[Dict], minority, majority, group_by: Optional[str] = None,
             a: str = "pred_ctc", b: str = "pred_transducer") -> "OrderedDict[str, Dict]":
    out: "OrderedDict[str, Dict]" = OrderedDict()
    for r in rows:
        ref = scoring_normalize(str(r.get("text", "")))
        if minority.script.count(ref) or not majority.script.count(ref) or b not in r:
            continue
        la = minority.script.count(scoring_normalize(str(r.get(a, "")))) > 0
        lb = minority.script.count(scoring_normalize(str(r.get(b, "")))) > 0
        for g in ["ALL"] + ([str(r.get(group_by))] if group_by else []):
            c = out.setdefault(g, {"n": 0, "ctc": 0, "rnnt": 0, "both": 0, "ctc_only": 0, "rnnt_only": 0})
            c["n"] += 1
            c["ctc"] += la
            c["rnnt"] += lb
            c["both"] += la and lb
            c["ctc_only"] += la and not lb
            c["rnnt_only"] += lb and not la
    return out


def format_crosstab(t: Dict) -> str:
    lines = [f"{'stratum':<14} {'n':>6} {'CTC':>7} {'RNNT':>7} {'both':>7} {'CTC only':>9} {'RNNT only':>10} {'overlap':>8}"]
    for g, c in t.items():
        n = max(c["n"], 1)
        union = c["ctc"] + c["rnnt"] - c["both"]
        ov = f"{c['both'] / union:>8.0%}" if union else f"{'-':>8}"
        lines.append(f"{g:<14} {c['n']:>6} {c['ctc'] / n:>7.2%} {c['rnnt'] / n:>7.2%} {c['both'] / n:>7.2%} "
                     f"{c['ctc_only'] / n:>9.2%} {c['rnnt_only'] / n:>10.2%} {ov}")
    lines.append("(overlap: utterances where both heads leak / where at least one leaks)")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--manifest", required=True)
    p.add_argument("--majority", required=True)
    p.add_argument("--minority", required=True)
    p.add_argument("--group-by")
    p.add_argument("--out")
    args = p.parse_args(argv)
    t = crosstab(list(read_manifest(args.manifest)), get_language(args.minority),
                 get_language(args.majority), args.group_by)
    if not t:
        print("no utterance with both heads' output (dump made without --transducer?)")
        return 1
    print(format_crosstab(t))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(t, f, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
