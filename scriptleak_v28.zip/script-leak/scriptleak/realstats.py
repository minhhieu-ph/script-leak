"""Shared helpers for the v24 analyses of real-condition dumps."""

from __future__ import annotations

import json
import os
from typing import Dict, List, Optional

from .languages import get_language
from .normalize import scoring_normalize

TH, EN = get_language("th"), get_language("en")

# Thai fillers and particles: an utterance made only of these is "filler-like".
FILLERS = ("เอ่อ", "อืม", "อือ", "อ่า", "อ้า", "เออ", "อ๋อ", "ฮะ", "ครับผม", "ครับ", "ค่ะ", "คะ", "ค่า",
           "นะ", "เนาะ", "อะ", "ใช่", "โอเค", "ฮ่า", "อ่ะ", "จ้ะ", "จ้า")


def load_utts(work: str, b_pct: str, label: str, set_name: str) -> Optional[List[Dict]]:
    path = os.path.join(work, "dumps", f"B{b_pct}_{label}", set_name, "utts.jsonl")
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]


def spoken_other(set_name: str):
    return (EN, TH) if set_name.endswith("_en") or "ami" in set_name else (TH, EN)


def leak_flags(rows: List[Dict], set_name: str, field: str = "pred_ctc") -> Dict[str, bool]:
    """audio_filepath -> does the hypothesis contain the other script? Only
    utterances whose reference is purely in the spoken script."""
    spoken, other = spoken_other(set_name)
    out = {}
    for r in rows:
        ref = scoring_normalize(str(r.get("text", "")))
        if other.script.count(ref) or not spoken.script.count(ref):
            continue
        out[str(r.get("audio_filepath"))] = other.script.count(scoring_normalize(str(r.get(field, "")))) > 0
    return out


def filler_like(text: str) -> bool:
    s = str(text).replace(" ", "")
    for f in sorted(FILLERS, key=len, reverse=True):
        s = s.replace(f, "")
    return s == "" and str(text).strip() != ""


def parse_groups(items: List[str]) -> Dict[str, List[str]]:
    """["rir=rir,rir_s1,rir_s2", ...] -> {"rir": [...]}"""
    out = {}
    for it in items:
        name, _, labels = it.partition("=")
        out[name] = [l for l in labels.split(",") if l]
    return out


DEFAULT_GROUPS = ["clean=clean,clean_s1,clean_s2", "both=both,both_s1,both_s2",
                  "rir=rir,rir_s1,rir_s2", "th=th,th_s1,th_s2"]
