"""Probe sets for the hypotheses phase A could not settle (v19).

With speech (one copy of each clean Thai test utterance per stratum):

  clean
  noise10, noise0     MUSAN noise at 10 and 0 dB SNR (held-out noise files)
  soft10, soft0       the SAME noise segment at the level it has in noise20,
                      and the speech 10 or 20 dB quieter: a quiet talker in a
                      room whose background stays put. Same SNR as noise10 and
                      noise0, but 10-20 dB lower overall. Comparing the two
                      pairs separates "low SNR" from "low level".
  babth10, babth0     babble of 4 other Thai talkers (other test sentences)
  babmx10, babmx0     babble of 4 talkers from MUSAN speech (several languages,
                      much of it English)
  music10, music0     MUSAN music

Without speech (empty reference, 5 s):

  noise_only          MUSAN noise at a normal speech level (control)
  babth_only          Thai babble at a normal speech level
  babth_far           the same, 20 dB lower
  babmx_only          multilingual babble
  music_only          music

Latin output on Thai babble is wrong whatever was said in it. On the MUSAN
babble it may be a correct transcription of English talkers, so it is
reported apart. Only noise/music/speech files whose name falls in the
held-out 20% (scriptleak.noise.noise_split) are used.

  python -m scriptleak.probes2 --manifest th_central.test.jsonl --musan-dir $D/musan \\
      --out-dir $D/probeC_audio --out-manifest th_probes.jsonl --out-nonspeech nonspeech.jsonl
"""

from __future__ import annotations

import argparse
import glob
import os
import sys
from typing import Dict, List, Optional

import numpy as np

from .audio import resample, to_mono
from .manifest import read_manifest, write_manifest
from .noise import _seed_for, fit_noise, noise_split, rms
from .probes import SPEECH_RMS, _no_clip

BABBLE_TALKERS = 4


def scale_to(x: np.ndarray, target_rms: float) -> np.ndarray:
    r = rms(x)
    return (x * (target_rms / r)).astype(np.float32) if r > 0 else x.astype(np.float32)


def mix_snr(speech: np.ndarray, bg: np.ndarray, snr_db: float) -> np.ndarray:
    """speech + bg scaled to the given SNR; bg must already have len(speech)."""
    rs = rms(speech)
    if rs == 0.0 or rms(bg) == 0.0:
        return speech.astype(np.float32)
    return _no_clip(speech + scale_to(bg, rs / 10.0 ** (snr_db / 20.0)))


def soft(speech: np.ndarray, bg: np.ndarray, drop_db: float, ref_snr_db: float = 20.0) -> np.ndarray:
    """Background at the level it has at ref_snr_db SNR, speech drop_db quieter:
    the result has SNR ref_snr_db - drop_db and a lower overall level."""
    rs = rms(speech)
    if rs == 0.0 or rms(bg) == 0.0:
        return speech.astype(np.float32)
    bg = scale_to(bg, rs / 10.0 ** (ref_snr_db / 20.0))
    return _no_clip(speech * 10.0 ** (-drop_db / 20.0) + bg)


class Pool:
    """Audio files read on demand and cached, resampled to sr."""

    def __init__(self, paths: List[str], sr: int, cache: int = 256):
        self.paths, self.sr, self._cache, self._max = paths, sr, {}, cache

    def __len__(self) -> int:
        return len(self.paths)

    def read(self, i: int) -> np.ndarray:
        if i not in self._cache:
            import soundfile as sf

            x, sr = sf.read(self.paths[i], dtype="float32", always_2d=False)
            if len(self._cache) >= self._max:
                self._cache.pop(next(iter(self._cache)))
            self._cache[i] = resample(to_mono(x), sr, self.sr)
        return self._cache[i]

    def segment(self, n: int, rng: np.random.Generator, exclude: Optional[set] = None) -> np.ndarray:
        for _ in range(20):
            i = int(rng.integers(0, len(self.paths)))
            if exclude and i in exclude:
                continue
            return fit_noise(self.read(i), n, rng)
        return fit_noise(self.read(int(rng.integers(0, len(self.paths)))), n, rng)


def babble(pool: Pool, n: int, rng: np.random.Generator, talkers: int = BABBLE_TALKERS,
           exclude: Optional[set] = None) -> np.ndarray:
    """Sum of `talkers` segments, each at the same level."""
    out = np.zeros(n, dtype=np.float64)
    for _ in range(talkers):
        out += scale_to(pool.segment(n, rng, exclude), 1.0)
    return out.astype(np.float32)


def heldout_files(d: str) -> List[str]:
    files = sorted(glob.glob(os.path.join(d, "**", "*.wav"), recursive=True))
    return [f for f in files if noise_split(f) == "test"]


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--manifest", required=True, help="clean Thai test manifest")
    p.add_argument("--musan-dir", required=True, help="folder with noise/, music/, speech/")
    p.add_argument("--out-dir", required=True)
    p.add_argument("--out-manifest", required=True)
    p.add_argument("--out-nonspeech", required=True)
    p.add_argument("--max-utts", type=int, default=1000)
    p.add_argument("--nonspeech-utts", type=int, default=500)
    p.add_argument("--seed", type=int, default=0)
    args = p.parse_args(argv)

    import soundfile as sf

    pool_entries = list(read_manifest(args.manifest))
    entries = pool_entries
    if len(entries) > args.max_utts:
        pick = np.random.default_rng(args.seed).choice(len(entries), args.max_utts, replace=False)
        entries = [entries[i] for i in sorted(pick.tolist())]
    sr = int(sf.info(entries[0]["audio_filepath"]).samplerate)

    pools: Dict[str, Pool] = {}
    for kind in ("noise", "music", "speech"):
        files = heldout_files(os.path.join(args.musan_dir, kind))
        if files:
            pools[kind] = Pool(files, sr)
            print(f"MUSAN {kind}: {len(files)} held-out files")
        else:
            print(f"WARNING: no held-out files under {args.musan_dir}/{kind}; its strata are skipped")
    th_pool = Pool([e["audio_filepath"] for e in pool_entries], sr)
    key_of = [str(e.get("text_key", e.get("text", ""))) for e in pool_entries]
    index_by_key: Dict[str, set] = {}
    for i, k in enumerate(key_of):
        index_by_key.setdefault(k, set()).add(i)

    def write(name: str, i: int, y: np.ndarray) -> str:
        path = os.path.join(args.out_dir, name, f"{i:07d}.wav")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        sf.write(path, y, sr, subtype="PCM_16")
        return path

    out: List[Dict] = []
    for i, e in enumerate(entries):
        x, xsr = sf.read(e["audio_filepath"], dtype="float32", always_2d=False)
        x = resample(to_mono(x), xsr, sr)
        n = len(x)
        rng = np.random.default_rng(_seed_for(e["audio_filepath"], args.seed + 200))
        variants: Dict[str, np.ndarray] = {}
        if "noise" in pools:
            seg = pools["noise"].segment(n, rng)
            variants.update({"noise10": mix_snr(x, seg, 10), "noise0": mix_snr(x, seg, 0),
                             "soft10": soft(x, seg, 10), "soft0": soft(x, seg, 20)})
        same = index_by_key.get(str(e.get("text_key", e.get("text", ""))), set())
        bab = babble(th_pool, n, rng, exclude=same)
        variants.update({"babth10": mix_snr(x, bab, 10), "babth0": mix_snr(x, bab, 0)})
        if "speech" in pools:
            bab = babble(pools["speech"], n, rng)
            variants.update({"babmx10": mix_snr(x, bab, 10), "babmx0": mix_snr(x, bab, 0)})
        if "music" in pools:
            mus = pools["music"].segment(n, rng)
            variants.update({"music10": mix_snr(x, mus, 10), "music0": mix_snr(x, mus, 0)})
        rec = dict(e)
        rec["stratum"] = "clean"
        out.append(rec)
        for name, y in variants.items():
            rec = dict(e)
            rec.update({"audio_filepath": write(name, i, y), "stratum": name})
            out.append(rec)
        if (i + 1) % 200 == 0:
            print(f"{i + 1}/{len(entries)} utterances", flush=True)
    write_manifest(args.out_manifest, out)
    print(f"Wrote {len(out)} entries to {args.out_manifest}")

    lang = entries[0].get("lang", "th")
    n = int(5.0 * sr)
    ns: List[Dict] = []
    for i in range(args.nonspeech_utts):
        rng = np.random.default_rng(_seed_for(f"nonspeech{i}", args.seed + 300))
        variants = {}
        if "noise" in pools:
            variants["noise_only"] = scale_to(pools["noise"].segment(n, rng), SPEECH_RMS)
        bab = scale_to(babble(th_pool, n, rng), SPEECH_RMS)
        variants["babth_only"] = bab
        variants["babth_far"] = (bab * 0.1).astype(np.float32)
        if "speech" in pools:
            variants["babmx_only"] = scale_to(babble(pools["speech"], n, rng), SPEECH_RMS)
        if "music" in pools:
            variants["music_only"] = scale_to(pools["music"].segment(n, rng), SPEECH_RMS)
        for name, y in variants.items():
            ns.append({"audio_filepath": write(name, i, _no_clip(y)), "duration": 5.0, "text": "",
                       "stratum": name, "lang": lang})
    write_manifest(args.out_nonspeech, ns)
    print(f"Wrote {len(ns)} entries to {args.out_nonspeech}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
