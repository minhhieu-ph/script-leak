"""Put the results of several models side by side.

Reads the JSON files written by `scriptleak.sweep --out` and prints one row
per model and one column per stratum, as "leak rate / error rate".

  python -m scriptleak.compare --method greedy \\
      base=results/base/heldout.json both=results/B_both/heldout.json
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import List, Optional


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("results", nargs="+", metavar="NAME=PATH")
    p.add_argument("--method", default="greedy")
    p.add_argument("--error", default="cer", choices=["cer", "wer"])
    args = p.parse_args(argv)

    rows, strata = [], []
    for item in args.results:
        name, path = item.split("=", 1)
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            # sweep files are {method: {group: ...}}; evaluate files are {group: ...}
            res = data[args.method] if args.method in data else (data if "ALL" in data else data[args.method])
        except (OSError, KeyError, ValueError) as e:
            print(f"(skipping {name}: {e})")
            continue
        rows.append((name, res))
        for g in res:
            if g not in strata:
                strata.append(g)
    if not rows:
        print("nothing to compare")
        return 1
    width = max(len(n) for n, _ in rows)
    print(f"{'model':<{width}}  " + "  ".join(f"{g:>15}" for g in strata))
    for name, res in rows:
        cells = []
        for g in strata:
            r = res.get(g)
            cells.append(f"{r['slr_u']:>6.2%}/{r.get(args.error, r['cer']):>7.2%}" if r else "-")
        print(f"{name:<{width}}  " + "  ".join(f"{c:>15}" for c in cells))
    print(f"\n(each cell: share of utterances with wrong-script output / {args.error.upper()})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
