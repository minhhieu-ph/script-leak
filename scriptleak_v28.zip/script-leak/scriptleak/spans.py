"""Span-level acceptance test for minority-script output ("Latin must earn it").

A *span* is a run of frames in which the greedy CTC path emits minority-script
tokens, uninterrupted by a majority-script token (blanks in between belong to
the span). For every span this module computes

  conf      mean probability of the emitted token over the emitting frames
  negent    minus the mean entropy of those frames
  minmass   mean total probability of all minority tokens
  frames    number of emitting frames (span length)
  lm        n-gram score of the span text under a minority-language model
  lex       share of the span's words found in the minority training lexicon
  lmdiff    lm minus the majority-language score of the *forced* reading, i.e.
            what the same frames say when minority tokens are banned

Spans on majority-language speech are leaks (negatives). Positives are taken
from minority-language speech, both as whole spans and cut into 1-3 word
chunks, because a name inside a sentence is short and a whole English
utterance is not a fair stand-in for it.

The report answers: if we keep X% of the true minority spans, what share of
the leaked spans is rejected -- per feature, and for the rule "confident AND
plausible". It then applies that rule as a decoder (a rejected span is
re-read with minority tokens banned) and prints leakage and accuracy.

  python -m scriptleak.spans --majority th --minority en \\
      --leak-dump dumps/en05/th_test dumps/en05/th_probes \\
      --genuine-dump dumps/en05/en_test \\
      --majority-text th_central.train.jsonl --minority-text en_train.clean.jsonl \\
      --out spans_en05.json

Thresholds are fitted on the even-numbered genuine utterances and every
number about genuine speech is reported on the odd-numbered ones.
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import OrderedDict
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np

from .decoding import collapse
from .dumpio import iter_dump, read_meta
from .evaluate import score
from .languages import get_language
from .manifest import read_manifest
from .ngram import CharNgram
from .tokenmap import BLANK, MAJ, MIN, pieces_to_text, token_groups

_NEG = -1e30
WORD_MARK = "▁"
FEATURES = ["conf", "negent", "minmass", "frames", "lm", "lex", "lmdiff"]


# ------------------------------------------------------------------ spans

def frame_stats(logp: np.ndarray, groups: np.ndarray) -> Dict[str, np.ndarray]:
    """Per-frame quantities shared by all spans of an utterance."""
    lp = logp.astype(np.float64)
    ids = lp.argmax(axis=1)
    p = np.exp(lp)
    top = p[np.arange(len(ids)), ids]
    ent = -(p * np.where(p > 0, lp, 0.0)).sum(axis=1)
    minmass = p[:, groups == MIN].sum(axis=1)
    return {"ids": ids, "g": groups[ids], "top": top, "ent": ent, "minmass": minmass}


def find_spans(g: np.ndarray) -> List[Tuple[int, int]]:
    """[start, end) frame ranges of minority runs; a majority frame ends a run."""
    spans, start, last = [], None, None
    for t, x in enumerate(g.tolist()):
        if x == MIN:
            if start is None:
                start = t
            last = t
        elif x == MAJ and start is not None:
            spans.append((start, last + 1))
            start = None
    if start is not None:
        spans.append((start, last + 1))
    return spans


def text_of(ids: Sequence[int], vocab: Sequence[str], blank: int) -> str:
    return pieces_to_text([vocab[i] for i in collapse(np.asarray(ids), blank) if i < len(vocab)])


def forced_ids(logp: np.ndarray, groups: np.ndarray, start: int, end: int) -> np.ndarray:
    """Greedy path of frames [start, end) with minority tokens banned."""
    return np.where(groups == MIN, _NEG, logp[start:end]).argmax(axis=1)


def span_features(st: Dict[str, np.ndarray], start: int, end: int) -> Optional[Dict[str, float]]:
    emit = np.flatnonzero(st["g"][start:end] == MIN) + start
    if len(emit) == 0:
        return None
    return {
        "conf": float(st["top"][emit].mean()),
        "negent": float(-st["ent"][emit].mean()),
        "minmass": float(st["minmass"][emit].mean()),
        "frames": float(len(emit)),
    }


def word_chunks(st: Dict[str, np.ndarray], start: int, end: int, vocab: Sequence[str],
                blank: int, offset: int = 0) -> List[Tuple[int, int]]:
    """Cut a span into chunks of 1, 2, 3, 1, ... words at word-start tokens."""
    ids = st["ids"]
    word_starts, prev = [], -1
    for t in range(start, end):
        i = int(ids[t])
        if i != prev and i != blank and i < len(vocab) and vocab[i].startswith(WORD_MARK):
            word_starts.append(t)
        prev = i
    if not word_starts or word_starts[0] != start:
        word_starts = [start] + word_starts
    bounds = word_starts + [end]
    out, w, k = [], 0, offset % 3 + 1
    while w < len(bounds) - 1:
        hi = min(w + k, len(bounds) - 1)
        out.append((bounds[w], bounds[hi]))
        w, k = hi, k % 3 + 1
    return out


# ---------------------------------------------------------------- scoring

class Scorer:
    """Adds the language features to the acoustic ones."""

    def __init__(self, min_lm: CharNgram, maj_lm: CharNgram, lexicon: set):
        self.min_lm, self.maj_lm, self.lexicon = min_lm, maj_lm, lexicon

    def add(self, feats: Dict[str, float], text: str, forced: str) -> Dict[str, float]:
        words = text.split()
        feats["lm"] = self.min_lm.score(text)
        feats["lex"] = (sum(w in self.lexicon for w in words) / len(words)) if words else 0.0
        feats["lmdiff"] = feats["lm"] - self.maj_lm.score(forced)
        return feats


def utterance_spans(logp, groups, vocab, blank, scorer: Scorer, chunks: bool = False,
                    offset: int = 0) -> Tuple[Dict, List[Dict]]:
    """All spans of one utterance, with features, text and frame range."""
    st = frame_stats(logp, groups)
    out = []
    for start, end in find_spans(st["g"]):
        ranges = word_chunks(st, start, end, vocab, blank, offset) if chunks else [(start, end)]
        for a, b in ranges:
            f = span_features(st, a, b)
            if f is None:
                continue
            text = text_of(st["ids"][a:b], vocab, blank)
            forced = text_of(forced_ids(logp, groups, a, b), vocab, blank)
            rec = scorer.add(f, text, forced)
            rec.update({"start": a, "end": b, "text": text, "forced": forced})
            out.append(rec)
    return st, out


def gated_text(logp, groups, vocab, blank, st, spans: List[Dict],
               accept: Callable[[Dict], bool]) -> str:
    """Greedy decoding in which every rejected span is re-read with minority
    tokens banned."""
    ids = st["ids"].copy()
    for s in spans:
        if not accept(s):
            ids[s["start"]:s["end"]] = forced_ids(logp, groups, s["start"], s["end"])
    return text_of(ids, vocab, blank)


# ------------------------------------------------------------- statistics

def auc(pos: np.ndarray, neg: np.ndarray) -> float:
    """P(score of a positive > score of a negative), ties counted half."""
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    allv = np.concatenate([pos, neg])
    order = allv.argsort(kind="mergesort")
    ranks = np.empty(len(allv), dtype=np.float64)
    sv = allv[order]
    i = 0
    while i < len(sv):
        j = i
        while j + 1 < len(sv) and sv[j + 1] == sv[i]:
            j += 1
        ranks[order[i:j + 1]] = (i + j) / 2.0 + 1.0
        i = j + 1
    return float((ranks[:len(pos)].sum() - len(pos) * (len(pos) + 1) / 2.0) / (len(pos) * len(neg)))


def threshold_at(pos: np.ndarray, keep: float) -> float:
    """Smallest score that still keeps `keep` of the positives."""
    return float(np.quantile(pos, 1.0 - keep)) if len(pos) else float("-inf")


def column(spans: List[Dict], name: str) -> np.ndarray:
    return np.asarray([s[name] for s in spans], dtype=np.float64)


# ------------------------------------------------------------------ main

def _texts(path: str, limit: int) -> List[str]:
    out = []
    for e in read_manifest(path):
        out.append(str(e.get("text", "")))
        if len(out) >= limit:
            break
    return out


def run(args) -> Dict:
    majority, minority = get_language(args.majority), get_language(args.minority)
    print("Training the n-gram models ...", flush=True)
    min_texts = _texts(args.minority_text, args.lm_sentences)
    min_lm = CharNgram(args.lm_order).fit(min_texts)
    maj_lm = CharNgram(args.lm_order).fit(_texts(args.majority_text, args.lm_sentences))
    scorer = Scorer(min_lm, maj_lm, min_lm.vocabulary(min_texts))

    # ---- pass 1: collect spans
    leak, leak_strata = [], []
    for d in args.leak_dump:
        meta = read_meta(d)
        vocab, blank = meta["vocab"], meta["blank_id"]
        groups = token_groups(vocab, majority, minority, blank)
        for n, (rec, logp) in enumerate(iter_dump(d)):
            if majority.script.count(str(rec.get("text", ""))) == 0:
                continue  # not majority-language speech
            _, sp = utterance_spans(logp, groups, vocab, blank, scorer)
            leak.extend(sp)
            leak_strata.extend([str(rec.get(args.group_by, "ALL"))] * len(sp))
            if (n + 1) % 5000 == 0:
                print(f"  {d}: {n + 1} utterances", flush=True)

    fit_whole, fit_chunk, test_whole, test_chunk = [], [], [], []
    for d in args.genuine_dump:
        meta = read_meta(d)
        vocab, blank = meta["vocab"], meta["blank_id"]
        groups = token_groups(vocab, majority, minority, blank)
        for n, (rec, logp) in enumerate(iter_dump(d)):
            _, whole = utterance_spans(logp, groups, vocab, blank, scorer)
            _, chunk = utterance_spans(logp, groups, vocab, blank, scorer, chunks=True, offset=n)
            (fit_whole if n % 2 == 0 else test_whole).extend(whole)
            (fit_chunk if n % 2 == 0 else test_chunk).extend(chunk)

    out: Dict = OrderedDict()
    out["counts"] = {"leak_spans": len(leak), "genuine_spans_test": len(test_whole),
                     "genuine_chunks_test": len(test_chunk)}
    print(f"\nLeaked spans (on {majority.name} speech): {len(leak)}")
    print(f"Genuine {minority.name} spans, held-out half: {len(test_whole)} whole, "
          f"{len(test_chunk)} chunks of 1-3 words")
    if not leak or not test_chunk:
        print("Not enough spans for the analysis.")
        return out

    def med(spans, name):
        return float(np.median(column(spans, name)))

    print("\nMedian of each feature")
    print(f"{'feature':<9} {'leaked':>9} {'chunks':>9} {'whole':>9}")
    for f in FEATURES:
        print(f"{f:<9} {med(leak, f):>9.3f} {med(test_chunk, f):>9.3f} {med(test_whole, f):>9.3f}")

    # ---- single features
    keep = args.keep
    print(f"\nOne feature at a time (threshold keeps {keep:.0%} of genuine chunks, fitted on the other half)")
    print(f"{'feature':<9} {'AUC chunks':>10} {'AUC whole':>10} {'kept':>7} {'leak rejected':>14}")
    out["features"] = OrderedDict()
    for f in FEATURES:
        thr = threshold_at(column(fit_chunk, f), keep)
        kept = float((column(test_chunk, f) >= thr).mean())
        rej = float((column(leak, f) < thr).mean())
        a_c, a_w = auc(column(test_chunk, f), column(leak, f)), auc(column(test_whole, f), column(leak, f))
        out["features"][f] = {"auc_chunks": a_c, "auc_whole": a_w, "threshold": thr,
                              "genuine_kept": kept, "leak_rejected": rej}
        print(f"{f:<9} {a_c:>10.3f} {a_w:>10.3f} {kept:>7.1%} {rej:>14.1%}")

    # ---- rules: confident AND plausible
    rules = OrderedDict()
    for name, feats in (("conf", ["conf"]), ("lm", ["lm"]), ("conf+lm", ["conf", "lm"]),
                        ("conf+lmdiff", ["conf", "lmdiff"]), ("conf+lm+lex", ["conf", "lm", "lex"])):
        q = keep if len(feats) == 1 else 1.0 - (1.0 - keep) / len(feats)
        thr = {f: threshold_at(column(fit_chunk, f), q) for f in feats}
        rules[name] = thr

    def make_accept(thr):
        return lambda s: all(s[f] >= t for f, t in thr.items())

    print("\nRules (a span is kept only if every condition holds)")
    print(f"{'rule':<13} {'chunks kept':>12} {'leak rejected':>14}   leak rejected per stratum")
    out["rules"] = OrderedDict()
    strata = sorted(set(leak_strata))
    for name, thr in rules.items():
        acc = make_accept(thr)
        kept = float(np.mean([acc(s) for s in test_chunk]))
        rej_all = float(np.mean([not acc(s) for s in leak]))
        per = {}
        for g in strata:
            sel = [s for s, x in zip(leak, leak_strata) if x == g]
            per[g] = float(np.mean([not acc(s) for s in sel])) if sel else float("nan")
        out["rules"][name] = {"thresholds": thr, "genuine_chunks_kept": kept,
                              "leak_rejected": rej_all, "leak_rejected_by_stratum": per}
        detail = "  ".join(f"{g}={v:.0%}" for g, v in per.items())
        print(f"{name:<13} {kept:>12.1%} {rej_all:>14.1%}   {detail}")

    # ---- pass 2: use the rules as a decoder
    print("\nThe rules used as a decoder (rejected spans re-read without minority tokens)")
    out["decoding"] = OrderedDict()
    names = ["greedy"] + list(rules)
    accepts = {"greedy": (lambda s: True)}
    accepts.update({n: make_accept(t) for n, t in rules.items()})

    for d in args.leak_dump:
        meta = read_meta(d)
        vocab, blank = meta["vocab"], meta["blank_id"]
        groups = token_groups(vocab, majority, minority, blank)
        refs, strat, hyps = [], [], {n: [] for n in names}
        for rec, logp in iter_dump(d):
            st, sp = utterance_spans(logp, groups, vocab, blank, scorer)
            refs.append(str(rec.get("text", "")))
            strat.append(str(rec.get(args.group_by, "ALL")))
            for n in names:
                hyps[n].append(gated_text(logp, groups, vocab, blank, st, sp, accepts[n]))
        print(f"\n{d}  ({majority.name} speech: leak rate / CER)")
        groups_here = sorted(set(strat))
        print(f"{'rule':<13} " + " ".join(f"{g:>16}" for g in ["ALL"] + groups_here))
        res_d = OrderedDict()
        for n in names:
            cells, res_d[n] = [], OrderedDict()
            for g in ["ALL"] + groups_here:
                idx = range(len(refs)) if g == "ALL" else [i for i, x in enumerate(strat) if x == g]
                r = score([refs[i] for i in idx], [hyps[n][i] for i in idx], majority, minority)
                res_d[n][g] = {"slr_u": r["slr_u"], "cer": r["cer"], "eligible": r["utterances_eligible"]}
                cells.append(f"{r['slr_u']:>7.2%}/{r['cer']:>7.2%}")
            print(f"{n:<13} " + " ".join(f"{c:>16}" for c in cells))
        out["decoding"][d] = res_d

    for d in args.genuine_dump:
        meta = read_meta(d)
        vocab, blank = meta["vocab"], meta["blank_id"]
        groups = token_groups(vocab, majority, minority, blank)
        refs, strat, hyps = [], [], {n: [] for n in names}
        for k, (rec, logp) in enumerate(iter_dump(d)):
            if k % 2 == 0:
                continue  # thresholds were fitted on these
            st, sp = utterance_spans(logp, groups, vocab, blank, scorer)
            refs.append(str(rec.get("text", "")))
            strat.append(str(rec.get(args.group_by, "ALL")))
            for n in names:
                hyps[n].append(gated_text(logp, groups, vocab, blank, st, sp, accepts[n]))
        print(f"\n{d}  ({minority.name} speech, held-out half: WER)")
        groups_here = sorted(set(strat))
        print(f"{'rule':<13} " + " ".join(f"{g:>10}" for g in ["ALL"] + groups_here))
        res_d = OrderedDict()
        for n in names:
            cells, res_d[n] = [], OrderedDict()
            for g in ["ALL"] + groups_here:
                idx = range(len(refs)) if g == "ALL" else [i for i, x in enumerate(strat) if x == g]
                r = score([refs[i] for i in idx], [hyps[n][i] for i in idx], minority, majority)
                res_d[n][g] = {"wer": r.get("wer", r["cer"]), "cer": r["cer"]}
                cells.append(f"{r.get('wer', r['cer']):>10.2%}")
            print(f"{n:<13} " + " ".join(cells))
        out["decoding"][d] = res_d

    # ---- a look at the data
    order = np.argsort(column(leak, "conf"))[::-1][:args.examples]
    print(f"\nThe {len(order)} most confident leaked spans (the hard cases)")
    for i in order:
        s = leak[int(i)]
        print(f"  conf={s['conf']:.2f} lm={s['lm']:.2f} lex={s['lex']:.2f}  "
              f"'{s['text']}'  ->  forced: '{s['forced']}'")
    return out


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--majority", required=True)
    p.add_argument("--minority", required=True)
    p.add_argument("--leak-dump", nargs="+", required=True, help="dumps of majority-language speech")
    p.add_argument("--genuine-dump", nargs="+", required=True, help="dumps of minority-language speech")
    p.add_argument("--majority-text", required=True, help="manifest whose text trains the majority n-gram model")
    p.add_argument("--minority-text", required=True)
    p.add_argument("--group-by", default="stratum")
    p.add_argument("--keep", type=float, default=0.99, help="share of genuine chunks a threshold must keep")
    p.add_argument("--lm-order", type=int, default=5)
    p.add_argument("--lm-sentences", type=int, default=60000)
    p.add_argument("--examples", type=int, default=15)
    p.add_argument("--out")
    args = p.parse_args(argv)
    out = run(args)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(out, f, ensure_ascii=False, indent=2)
        print(f"\nWrote {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
