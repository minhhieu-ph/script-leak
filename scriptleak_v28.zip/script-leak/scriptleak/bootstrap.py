"""Confidence intervals for the real-audio leak rates (v24).

Utterances of one speaker (LOTUSDIS) or one meeting (AMI) are not
independent, so the bootstrap resamples whole speakers / meetings
("cluster bootstrap"). It gives the uncertainty that comes from the TEST SET
only. The spread between seeds is a second, separate source of uncertainty,
reported next to it as mean, standard deviation and range over seeds.

  python -m scriptleak.bootstrap --work $W --groups clean=clean,clean_s1,clean_s2 both=...

For each model: Thai -> Latin on LOTUSDIS, English -> Thai on AMI and their sum,
each with a 95% interval. For each group: the mean over its seeds with a 95%
interval (test-set uncertainty) and the seed standard deviation and range.
Then every pair of groups: difference of the means with a 95% interval.
"""

from __future__ import annotations

import argparse
import itertools
import json
import os
import sys
from typing import Dict, List, Optional, Tuple

import numpy as np

from .realstats import DEFAULT_GROUPS, leak_flags, load_utts, parse_groups

SETS = (("real_lotus_th", "speaker_id"), ("real_ami_en", "meeting"))


def cluster_table(rows: List[Dict], set_name: str, cluster_field: str, field: str,
                  clusters: Optional[List[str]] = None) -> Tuple[List[str], np.ndarray, np.ndarray]:
    """(cluster names, leaks per cluster, utterances per cluster)."""
    flags = leak_flags(rows, set_name, field)
    meta = {str(r.get("audio_filepath")): r for r in rows}
    leaks: Dict[str, int] = {}
    count: Dict[str, int] = {}
    for k, leak in flags.items():
        c = str(meta[k].get(cluster_field) or k)
        leaks[c] = leaks.get(c, 0) + int(leak)
        count[c] = count.get(c, 0) + 1
    names = clusters or sorted(count)
    return names, np.array([leaks.get(c, 0) for c in names], float), np.array([count.get(c, 0) for c in names], float)


def resample_weights(n_clusters: int, b: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.multinomial(n_clusters, np.full(n_clusters, 1.0 / n_clusters), size=b).astype(float)


def ci(x: np.ndarray) -> Tuple[float, float]:
    return float(np.percentile(x, 2.5)), float(np.percentile(x, 97.5))


def run(work: str, b_pct: str, groups: Dict[str, List[str]], field: str, b: int, seed: int) -> Dict:
    labels = sorted({l for ls in groups.values() for l in ls})
    draws: Dict[str, Dict[str, np.ndarray]] = {}   # set -> label -> B draws
    point: Dict[str, Dict[str, float]] = {}
    for si, (set_name, cfield) in enumerate(SETS):
        rows = {l: load_utts(work, b_pct, l, set_name) for l in labels}
        rows = {l: r for l, r in rows.items() if r}
        if not rows:
            continue
        first = next(iter(rows))
        names, _, _ = cluster_table(rows[first], set_name, cfield, field)
        W = resample_weights(len(names), b, seed + si)
        draws[set_name], point[set_name] = {}, {}
        for l, r in rows.items():
            _, leaks, cnt = cluster_table(r, set_name, cfield, field, names)
            point[set_name][l] = float(leaks.sum() / max(cnt.sum(), 1))
            draws[set_name][l] = (W @ leaks) / np.maximum(W @ cnt, 1)
    out: Dict = {"models": {}, "groups": {}, "differences": []}
    have_both = len(draws) == 2
    for l in labels:
        m = {}
        for set_name in draws:
            if l in draws[set_name]:
                m[set_name] = {"rate": point[set_name][l], "ci": ci(draws[set_name][l])}
        if have_both and all(l in draws[s] for s in draws):
            tot = sum(draws[s][l] for s in draws)
            m["sum"] = {"rate": sum(point[s][l] for s in draws), "ci": ci(tot)}
        out["models"][l] = m
    group_draws = {}
    for g, ls in groups.items():
        ls = [l for l in ls if l in out["models"] and "sum" in out["models"][l]]
        if not ls:
            continue
        tot = np.mean([sum(draws[s][l] for s in draws) for l in ls], axis=0)
        vals = [out["models"][l]["sum"]["rate"] for l in ls]
        group_draws[g] = tot
        out["groups"][g] = {"seeds": ls, "mean": float(np.mean(vals)), "ci": ci(tot),
                            "sd": float(np.std(vals, ddof=1)) if len(vals) > 1 else float("nan"),
                            "min": float(min(vals)), "max": float(max(vals))}
    for a, c in itertools.combinations(group_draws, 2):
        d = group_draws[a] - group_draws[c]
        out["differences"].append({"a": a, "b": c, "diff": float(out["groups"][a]["mean"] - out["groups"][c]["mean"]),
                                   "ci": ci(d)})
    return out


def report(res: Dict) -> List[str]:
    L = ["Per model (95% interval from resampling speakers / meetings):",
         f"  {'model':<14} {'Thai->Latin (LOTUSDIS)':>26} {'English->Thai (AMI)':>26} {'sum':>26}"]
    for l, m in res["models"].items():
        cells = []
        for key in ("real_lotus_th", "real_ami_en", "sum"):
            v = m.get(key)
            cells.append(f"{v['rate']:6.1%} [{v['ci'][0]:5.1%}, {v['ci'][1]:5.1%}]" if v else "-")
        L.append(f"  {l:<14} " + " ".join(f"{c:>26}" for c in cells))
    if res["groups"]:
        L.append("\nPer recipe (sum of both directions; interval = test-set uncertainty of the seed mean):")
        for g, v in res["groups"].items():
            L.append(f"  {g:<8} mean {v['mean']:6.1%} [{v['ci'][0]:5.1%}, {v['ci'][1]:5.1%}]   "
                     f"seed sd {v['sd']:5.1%}, range {v['min']:5.1%}-{v['max']:5.1%}  ({len(v['seeds'])} seeds)")
    if res["differences"]:
        L.append("\nDifferences between recipes (seed means; the interval ignores seed variation, compare with the seed sd above):")
        for d in res["differences"]:
            L.append(f"  {d['a']} - {d['b']}: {d['diff']:+6.1%} [{d['ci'][0]:+5.1%}, {d['ci'][1]:+5.1%}]")
    return L


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--work", default=os.environ.get("W"))
    p.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    p.add_argument("--groups", nargs="*", default=DEFAULT_GROUPS)
    p.add_argument("--field", default="pred_ctc")
    p.add_argument("--resamples", type=int, default=2000)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--out")
    args = p.parse_args(argv)
    if not args.work:
        p.error("--work (or $W) is required")
    res = run(args.work, args.b_pct, parse_groups(args.groups), args.field, args.resamples, args.seed)
    print("\n".join(report(res)))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
