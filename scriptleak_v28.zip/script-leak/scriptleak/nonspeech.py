"""What does the model write when nobody speaks?

Reads a dump (or any manifest with a hypothesis field) of audio whose
reference is empty and reports, per stratum, how often the model writes
anything, and how often that contains each script.

  python -m scriptleak.nonspeech --manifest dumps/en05/nonspeech/utts.jsonl \\
      --majority th --minority en --hyp-field pred_ctc
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import OrderedDict
from typing import Dict, List, Optional

from .languages import get_language
from .manifest import read_manifest
from .normalize import scoring_normalize


def report(entries: List[Dict], majority, minority, hyp_field: str, group_by: str) -> "OrderedDict[str, Dict]":
    rows: "OrderedDict[str, Dict]" = OrderedDict()
    for e in entries:
        g = str(e.get(group_by, "ALL"))
        hyp = scoring_normalize(str(e.get(hyp_field, "")))
        r = rows.setdefault(g, {"n": 0, "any": 0, "minority": 0, "majority": 0, "chars": 0})
        r["n"] += 1
        r["any"] += bool(hyp.strip())
        r["minority"] += minority.script.count(hyp) > 0
        r["majority"] += majority.script.count(hyp) > 0
        r["chars"] += len(hyp.replace(" ", ""))
    for r in rows.values():
        n = max(r["n"], 1)
        r.update({"any_rate": r["any"] / n, "minority_rate": r["minority"] / n,
                  "majority_rate": r["majority"] / n, "mean_chars": r["chars"] / n})
    return rows


def compare(items: List[str], key: str = "minority_rate") -> str:
    """One row per model, one column per stratum, from several --out files."""
    rows, strata = [], []
    for item in items:
        name, path = item.split("=", 1)
        try:
            with open(path, "r", encoding="utf-8") as f:
                res = json.load(f)
        except (OSError, ValueError) as e:
            rows.append((name, None))
            continue
        rows.append((name, res))
        for g in res:
            if g not in strata:
                strata.append(g)
    if not strata:
        return "nothing to compare"
    width = max(8, max(len(n) for n, _ in rows))
    lines = [f"{'model':<{width}}  " + "  ".join(f"{g:>11}" for g in strata)]
    for name, res in rows:
        cells = [f"{res[g][key]:>11.1%}" if res and g in res else f"{'-':>11}" for g in strata]
        lines.append(f"{name:<{width}}  " + "  ".join(cells))
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--compare", nargs="+", metavar="NAME=PATH",
                   help="print a model x stratum table of earlier --out files and stop")
    p.add_argument("--key", default="minority_rate", help="column for --compare")
    p.add_argument("--manifest")
    p.add_argument("--majority", default="th")
    p.add_argument("--minority", default="en")
    p.add_argument("--hyp-field", default="pred_ctc")
    p.add_argument("--group-by", default="stratum")
    p.add_argument("--examples", type=int, default=8)
    p.add_argument("--out")
    args = p.parse_args(argv)
    if args.compare:
        print(compare(args.compare, args.key))
        return 0
    if not args.manifest:
        p.error("--manifest is required")
    maj, mino = get_language(args.majority), get_language(args.minority)
    entries = list(read_manifest(args.manifest))
    rows = report(entries, maj, mino, args.hyp_field, args.group_by)
    print(f"{'stratum':<12} {'n':>6} {'writes text':>12} {f'has {mino.name}':>13} {f'has {maj.name}':>10} {'chars':>7}")
    for g, r in rows.items():
        print(f"{g:<12} {r['n']:>6} {r['any_rate']:>12.1%} {r['minority_rate']:>13.1%} "
              f"{r['majority_rate']:>10.1%} {r['mean_chars']:>7.1f}")
    shown = 0
    for e in entries:
        h = str(e.get(args.hyp_field, "")).strip()
        if h and shown < args.examples:
            print(f"  [{e.get(args.group_by, '')}] {h[:100]}")
            shown += 1
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(rows, f, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
