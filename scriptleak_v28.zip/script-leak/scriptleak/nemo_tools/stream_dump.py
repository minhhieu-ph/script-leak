"""Like dump_logprobs, but the audio goes through the encoder in real streaming mode (v27).

The cache-aware FastConformer is run chunk by chunk with its caches, exactly as
NeMo's examples/asr/asr_cache_aware_streaming/speech_to_text_cache_aware_streaming_infer.py
does (CacheAwareStreamingAudioBuffer + encoder.cache_aware_stream_step), and the
CTC head is applied to each chunk's encoder output. The frame log-probabilities
of all chunks are concatenated and written in the usual dump format, so every
CPU analysis (leak, lock re-decoding at the end of the utterance, ...) reads
them unchanged.

  python -m scriptleak.nemo_tools.stream_dump --model final.nemo --manifest m.jsonl --out dumps/X/stream_set

--selfcheck N runs the first N utterances three ways (offline forward, streaming
one utterance at a time, streaming in batches) and prints how far they differ.
Exit code 0: batched streaming equals one-at-a-time; 3: it does not (use
--batch-size 1).
Untested outside a NeMo install.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Dict, List, Optional

import numpy as np

from ..audio import resample, to_mono
from ..dumpio import DumpWriter
from ..manifest import read_manifest
from ..tokenmap import ids_to_text


def _collapse(frame_ids: np.ndarray, blank_id: int) -> List[int]:
    out, prev = [], -1
    for i in frame_ids.tolist():
        if i != prev and i != blank_id:
            out.append(i)
        prev = i
    return out


def stream_batch(model, head, wavs: List[np.ndarray], device: str) -> List[np.ndarray]:
    """Streaming CTC log-probabilities [T_i, V] for a batch of waveforms."""
    import torch
    from nemo.collections.asr.parts.utils.streaming_utils import CacheAwareStreamingAudioBuffer

    buf = CacheAwareStreamingAudioBuffer(model=model, online_normalization=False, pad_and_drop_preencoded=False)
    for w in wavs:
        if hasattr(buf, "append_audio"):
            buf.append_audio(np.ascontiguousarray(w, dtype=np.float32), stream_id=-1)
        else:  # older buffers: features first
            sig = torch.from_numpy(np.ascontiguousarray(w, dtype=np.float32)).unsqueeze(0).to(device)
            feat, _ = model.preprocessor(input_signal=sig, length=torch.tensor([sig.size(1)], device=device))
            buf.append_processed_signal(feat, stream_id=-1)
    c_ch, c_t, c_len = model.encoder.get_initial_cache_state(batch_size=len(wavs))
    pieces: List[List[np.ndarray]] = [[] for _ in wavs]
    drop = model.encoder.streaming_cfg.drop_extra_pre_encoded
    for step, (chunk, chunk_len) in enumerate(iter(buf)):
        rets = model.encoder.cache_aware_stream_step(
            processed_signal=chunk, processed_signal_length=chunk_len,
            cache_last_channel=c_ch, cache_last_time=c_t, cache_last_channel_len=c_len,
            keep_all_outputs=buf.is_buffer_empty(),
            drop_extra_pre_encoded=0 if step == 0 else drop)
        encoded, enc_len = rets[0], rets[1]
        if len(rets) >= 5:
            c_ch, c_t, c_len = rets[2], rets[3], rets[4]
        logp = head(encoder_output=encoded).float().cpu().numpy()
        for b, n in enumerate(enc_len.cpu().numpy().tolist()):
            if n > 0:
                pieces[b].append(logp[b, : int(n)])
    V = None
    out = []
    for p in pieces:
        if p:
            V = p[0].shape[1]
        out.append(np.concatenate(p) if p else None)
    return [o if o is not None else np.zeros((0, V or 1), np.float32) for o in out]


def offline_batch(model, head, wavs: List[np.ndarray], device: str) -> List[np.ndarray]:
    import torch

    t = [torch.from_numpy(np.ascontiguousarray(w, dtype=np.float32)) for w in wavs]
    lengths = torch.tensor([len(w) for w in t], device=device)
    sig = torch.nn.utils.rnn.pad_sequence(t, batch_first=True).to(device)
    feat, feat_len = model.preprocessor(input_signal=sig, length=lengths)
    enc, enc_len = model.encoder(audio_signal=feat, length=feat_len)
    lp = head(encoder_output=enc).float().cpu().numpy()
    return [lp[i, : int(n)] for i, n in enumerate(enc_len.cpu().numpy().tolist())]


def compare(a: List[np.ndarray], b: List[np.ndarray], blank: int, vocab: List[str]) -> Dict:
    same_text, diffs, len_diff = 0, [], []
    for x, y in zip(a, b):
        n = min(len(x), len(y))
        len_diff.append(abs(len(x) - len(y)))
        if n:
            diffs.append(float(np.abs(np.exp(x[:n]) - np.exp(y[:n])).max()))
        tx = ids_to_text(_collapse(x.argmax(1), blank), vocab) if len(x) else ""
        ty = ids_to_text(_collapse(y.argmax(1), blank), vocab) if len(y) else ""
        same_text += tx == ty
    return {"same_text": same_text / max(1, len(a)), "max_prob_diff": float(np.median(diffs)) if diffs else None,
            "frames_off": float(np.mean(len_diff)) if len_diff else None}


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--model", required=True)
    p.add_argument("--manifest", required=True)
    p.add_argument("--out")
    p.add_argument("--batch-size", type=int, default=16)
    p.add_argument("--device", default="cuda")
    p.add_argument("--limit", type=int)
    p.add_argument("--shard-size", type=int, default=2000)
    p.add_argument("--att-context", help="e.g. 70,13 (default: the model's own)")
    p.add_argument("--selfcheck", type=int, default=0, metavar="N")
    args = p.parse_args(argv)

    from .common import preload

    preload()
    import soundfile as sf
    import torch

    from .common import ctc_head, get_vocabulary, load_model, patch_nemo

    patch_nemo()
    model = load_model(args.model, None, args.device)
    if args.att_context:
        model.encoder.set_default_att_context_size([int(x) for x in args.att_context.split(",")])
    model.encoder.setup_streaming_params()
    head = ctc_head(model)
    vocab = get_vocabulary(model)
    blank = len(vocab)
    sr_model = int(model.cfg.preprocessor.sample_rate)
    cfg = model.encoder.streaming_cfg
    print(f"streaming: att_context={getattr(model.encoder, 'att_context_size', '?')} "
          f"chunk={getattr(cfg, 'chunk_size', '?')} shift={getattr(cfg, 'shift_size', '?')} "
          f"drop_extra_pre_encoded={getattr(cfg, 'drop_extra_pre_encoded', '?')}", flush=True)

    entries: List[Dict] = list(read_manifest(args.manifest))
    if args.selfcheck:
        entries = entries[: args.selfcheck]
    elif args.limit:
        entries = entries[: args.limit]

    def load(e):
        audio, sr = sf.read(e["audio_filepath"], dtype="float32", always_2d=False)
        return resample(to_mono(audio), sr, sr_model)

    with torch.inference_mode():
        if args.selfcheck:
            wavs = [load(e) for e in entries]
            off = offline_batch(model, head, wavs, args.device)
            one = [stream_batch(model, head, [w], args.device)[0] for w in wavs]
            bat = []
            for s in range(0, len(wavs), args.batch_size):
                bat += stream_batch(model, head, wavs[s:s + args.batch_size], args.device)
            res = {"streaming_vs_offline": compare(one, off, blank, vocab),
                   "batched_vs_one_at_a_time": compare(bat, one, blank, vocab), "n": len(wavs)}
            print("SELFCHECK " + json.dumps(res), flush=True)
            return 0 if res["batched_vs_one_at_a_time"]["same_text"] >= 0.98 else 3
        if not args.out:
            p.error("--out is required")
        order = sorted(range(len(entries)), key=lambda i: -float(entries[i].get("duration", 0.0)))
        results: Dict[int, np.ndarray] = {}
        for k, s in enumerate(range(0, len(order), args.batch_size)):
            idx = order[s:s + args.batch_size]
            for i, lp in zip(idx, stream_batch(model, head, [load(entries[i]) for i in idx], args.device)):
                results[i] = lp.astype(np.float16)
            if k % 20 == 0:
                print(f"{min(s + args.batch_size, len(order))}/{len(order)} utterances", flush=True)

    extra = {"model": args.model, "sample_rate": sr_model, "manifest": args.manifest, "streaming": True,
             "att_context": args.att_context or "default"}
    with DumpWriter(args.out, vocab, blank, args.shard_size, extra) as w:
        for i, e in enumerate(entries):
            rec = dict(e)
            lp = results[i].astype(np.float32)
            rec["pred_ctc"] = ids_to_text(_collapse(lp.argmax(axis=1), blank), vocab) if len(lp) else ""
            w.add(rec, lp)
    print(f"Wrote streaming dump of {len(entries)} utterances to {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
