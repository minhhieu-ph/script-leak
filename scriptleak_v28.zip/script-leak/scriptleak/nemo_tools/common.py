"""Small helpers shared by the NeMo scripts. Untested outside a NeMo install."""

from __future__ import annotations

from typing import List


def preload() -> None:
    """Import the native libraries in the order that scriptleak.nemo_tools.check_env
    uses, *before* torch and NeMo. On the machine this was first run on, importing
    NeMo without these already loaded ended in a segmentation fault, while
    check_env (which loads them first) worked."""
    import numpy  # noqa: F401
    import soundfile  # noqa: F401
    import sentencepiece  # noqa: F401


def patch_nemo() -> None:
    """Work around a NeMo 3.0.0 problem with the aggregate (one block per
    language) tokenizer: the CTC word-error-rate metric calls
    `tokenizer.tokens_to_text(tokens)` without the language id that
    AggregateTokenizer requires, which stops training at the first logging
    step. Sub-word pieces of any language join the same way, so no language
    id is needed. Calls that do pass a language id are left untouched."""
    try:
        from nemo.collections.common.tokenizers.aggregate_tokenizer import AggregateTokenizer
    except Exception:
        return
    if getattr(AggregateTokenizer, "_scriptleak_patched", False):
        return
    original = AggregateTokenizer.tokens_to_text

    def tokens_to_text(self, tokens, lang_id=None):
        if lang_id is not None:
            return original(self, tokens, lang_id)
        if isinstance(tokens, str):
            tokens = [tokens]
        if len(tokens) > 0 and isinstance(tokens[0], (list, tuple)):
            return [tokens_to_text(self, t) for t in tokens]
        return " ".join("".join(str(t) for t in tokens).replace("\u2581", " ").split())

    AggregateTokenizer.tokens_to_text = tokens_to_text
    AggregateTokenizer._scriptleak_patched = True


def import_lightning():
    try:
        import lightning.pytorch as pl
    except ImportError:
        import pytorch_lightning as pl
    return pl


def load_model(model_path: str = None, pretrained: str = None, device: str = "cuda"):
    import nemo.collections.asr as nemo_asr

    if model_path:
        model = nemo_asr.models.ASRModel.restore_from(model_path, map_location=device)
    elif pretrained:
        model = nemo_asr.models.ASRModel.from_pretrained(pretrained, map_location=device)
    else:
        raise ValueError("give a model path or a pretrained name")
    return model.eval().to(device)


def ctc_head(model):
    """The module that maps encoder output to CTC log-probabilities.
    Hybrid transducer-CTC models expose it as `ctc_decoder`, pure CTC models
    as `decoder`."""
    if hasattr(model, "ctc_decoder"):
        return model.ctc_decoder
    name = type(model).__name__
    if "CTC" in name and hasattr(model, "decoder"):
        return model.decoder
    raise AttributeError(f"{name} has no CTC head (need a hybrid transducer-CTC or a CTC model)")


def get_vocabulary(model) -> List[str]:
    """Token strings in output order of the CTC head (blank excluded)."""
    head = ctc_head(model)
    vocab = getattr(head, "vocabulary", None)
    if vocab:
        return list(vocab)
    tok = getattr(model, "tokenizer", None)
    if tok is not None and getattr(tok, "vocab", None):
        return list(tok.vocab)
    raise AttributeError("could not find the model vocabulary")
