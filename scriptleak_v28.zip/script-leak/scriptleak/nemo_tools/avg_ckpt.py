"""Average the weights of several checkpoints of ONE training run.

  python -m scriptleak.nemo_tools.avg_ckpt --models exp/B20_rir/epoch040.nemo \
      exp/B20_rir/epoch045.nemo exp/B20_rir/final.nemo --out exp/B20_rir_avg/final.nemo

Floating-point tensors are averaged; integer tensors (batch-norm step
counters) are taken from the last model. Runs on CPU.
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import List, Optional


def average_state_dicts(states):
    """Element-wise mean of floating-point entries; others from the last state."""
    import torch

    out = {}
    last = states[-1]
    for k, v in last.items():
        if torch.is_tensor(v) and v.is_floating_point():
            acc = torch.zeros_like(v, dtype=torch.float64)
            for s in states:
                acc += s[k].to(torch.float64)
            out[k] = (acc / len(states)).to(v.dtype)
        else:
            out[k] = v
    return out


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--models", nargs="+", required=True, help=".nemo files, the last one is the base")
    p.add_argument("--out", required=True)
    args = p.parse_args(argv)

    from .common import preload

    preload()
    from .common import load_model, patch_nemo

    patch_nemo()
    states = []
    for path in args.models:
        print(f"loading {path}", flush=True)
        m = load_model(path, None, "cpu")
        states.append({k: v.detach().clone() for k, v in m.state_dict().items()})
        if path != args.models[-1]:
            del m
    base = m  # the last model
    base.load_state_dict(average_state_dicts(states))
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    base.save_to(args.out)
    print(f"Saved the average of {len(states)} checkpoints to {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
