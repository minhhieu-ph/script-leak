"""Do different seeds leak on the SAME utterances? (v24)

The real-audio leak rate of one recipe swings a lot between seeds. This asks
whether the swing hides a stable pattern: if the same utterances, speakers or
kinds of sentence leak in every seed, then content or context decides WHICH
utterances leak and the seed decides HOW MANY. If not, it is noise.

  python -m scriptleak.seedvar --work $W --set real_lotus_th \\
      --groups rir=rir,rir_s1,rir_s2 both=both,both_s1,both_s2

For each group of seeds of one recipe:
  1. leak rate of each seed
  2. on how many seeds each utterance leaks, against what independent seeds
     with the same rates would give
  3. pairwise overlap: P(B leaks | A leaks) and its ratio to P(B leaks) ("lift")
  4. per speaker: correlation of the speakers' leak rates between seeds
  5. by kind of sentence: filler-only (อืม, เอ่อ, ครับ ...) vs other, and by length
  6. (LOTUSDIS) across microphones: if a segment leaks on one mic, does the
     same segment leak on the others?
"""

from __future__ import annotations

import argparse
import itertools
import json
import os
import sys
from collections import defaultdict
from typing import Dict, List, Optional

import numpy as np

from .realstats import DEFAULT_GROUPS, filler_like, leak_flags, load_utts, parse_groups


def poisson_binomial(ps: List[float]) -> np.ndarray:
    dist = np.zeros(len(ps) + 1)
    dist[0] = 1.0
    for p in ps:
        dist[1:] = dist[1:] * (1 - p) + dist[:-1] * p
        dist[0] *= (1 - p)
    return dist


def pearson(a: List[float], b: List[float]) -> float:
    a, b = np.asarray(a, float), np.asarray(b, float)
    if len(a) < 3 or a.std() == 0 or b.std() == 0:
        return float("nan")
    return float(np.corrcoef(a, b)[0, 1])


def length_bin(text: str) -> str:
    n = len(str(text).replace(" ", ""))
    return "<=6" if n <= 6 else "7-15" if n <= 15 else "16-30" if n <= 30 else ">30"


def analyse_group(rows_by_label: Dict[str, List[Dict]], set_name: str, field: str) -> Dict:
    labels = list(rows_by_label)
    flags = {l: leak_flags(rows_by_label[l], set_name, field) for l in labels}
    keys = sorted(set.intersection(*[set(f) for f in flags.values()]))
    meta = {str(r.get("audio_filepath")): r for r in rows_by_label[labels[0]]}
    X = np.array([[flags[l][k] for l in labels] for k in keys], dtype=bool)
    n = len(keys)
    rates = X.mean(axis=0).tolist()
    res: Dict = {"labels": labels, "n": n, "rates": dict(zip(labels, rates))}

    counts = np.bincount(X.sum(axis=1), minlength=len(labels) + 1) / max(n, 1)
    res["k_of_n"] = {"observed": counts.tolist(), "independent": poisson_binomial(rates).tolist()}

    pairs = []
    for i, j in itertools.permutations(range(len(labels)), 2):
        a, b = X[:, i], X[:, j]
        if a.sum() == 0 or b.mean() == 0:
            continue
        cond = float(b[a].mean())
        pairs.append({"given": labels[i], "then": labels[j], "p_then_given": cond,
                      "p_then": float(b.mean()), "lift": cond / float(b.mean())})
    res["pairs"] = pairs

    spk = defaultdict(list)
    for idx, k in enumerate(keys):
        spk[str(meta[k].get("speaker_id", meta[k].get("meeting", "?")))].append(idx)
    spk = {s: ix for s, ix in spk.items() if len(ix) >= 20}
    per_spk = {s: X[ix].mean(axis=0).tolist() for s, ix in spk.items()}
    corr = [pearson([v[i] for v in per_spk.values()], [v[j] for v in per_spk.values()])
            for i, j in itertools.combinations(range(len(labels)), 2)]
    res["speakers"] = {"count": len(per_spk), "mean_pairwise_corr": float(np.nanmean(corr)) if corr else float("nan"),
                       "top": sorted(((s, float(np.mean(v)), len(spk[s])) for s, v in per_spk.items()),
                                     key=lambda t: -t[1])[:5]}

    kinds = defaultdict(list)
    for idx, k in enumerate(keys):
        text = meta[k].get("text", "")
        kinds["filler-only" if filler_like(text) else "other"].append(idx)
        kinds[f"len {length_bin(text)}"].append(idx)
    res["kinds"] = {kname: {"n": len(ix), "rates": X[ix].mean(axis=0).tolist()} for kname, ix in kinds.items()}

    seg = defaultdict(list)
    for idx, k in enumerate(keys):
        r = meta[k]
        if "text_raw" in r and "speaker_id" in r and str(r.get("stratum", "")).startswith("lotus/"):
            seg[(r["speaker_id"], r["text_raw"])].append(idx)
    seg = {s: ix for s, ix in seg.items() if len(ix) >= 2}
    if seg:
        cross = []
        for j, l in enumerate(labels):
            hit = tot = 0
            for ix in seg.values():
                col = X[ix, j]
                for a in range(len(ix)):
                    others = np.delete(col, a)
                    if others.any():
                        tot += 1
                        hit += bool(col[a])
            base = rates[j]
            p = hit / tot if tot else float("nan")
            cross.append({"label": l, "p_leak_given_other_mic_leaks": p, "p_leak": base,
                          "lift": p / base if base else float("nan")})
        res["cross_mic"] = {"segments": len(seg), "per_model": cross}
    return res


def report(name: str, res: Dict) -> List[str]:
    L = [f"\n=== {name}: {', '.join(res['labels'])}  (n = {res['n']} utterances)"]
    L.append("1. leak rate: " + "  ".join(f"{l} {r:.1%}" for l, r in res["rates"].items()))
    obs, ind = res["k_of_n"]["observed"], res["k_of_n"]["independent"]
    L.append("2. utterances leaking on k seeds (observed / if seeds were independent):")
    L.append("   " + "  ".join(f"k={k}: {o:.1%} / {e:.1%}" for k, (o, e) in enumerate(zip(obs, ind))))
    k_all = len(obs) - 1
    if ind[k_all] > 0:
        L.append(f"   leaking on all {k_all} seeds: {obs[k_all] / ind[k_all]:.1f}x what independence predicts")
    L.append("3. pairwise: P(B leaks | A leaks) vs P(B leaks)")
    for p in res["pairs"]:
        L.append(f"   {p['given']:>10} -> {p['then']:<10} {p['p_then_given']:6.1%} vs {p['p_then']:6.1%}  lift {p['lift']:.1f}")
    s = res["speakers"]
    L.append(f"4. speakers (>=20 utterances): {s['count']}; mean correlation of per-speaker leak rate between seeds: "
             f"{s['mean_pairwise_corr']:.2f}")
    for spk, mean, cnt in s["top"]:
        L.append(f"   most affected: {spk:<14} mean leak {mean:.1%} over {cnt} utterances")
    L.append("5. by kind of sentence (leak rate per seed):")
    for kname in sorted(res["kinds"]):
        k = res["kinds"][kname]
        L.append(f"   {kname:<12} n={k['n']:>5}  " + "  ".join(f"{r:6.1%}" for r in k["rates"]))
    if "cross_mic" in res:
        c = res["cross_mic"]
        L.append(f"6. across microphones ({c['segments']} segments recorded on >=2 mics):")
        for m in c["per_model"]:
            L.append(f"   {m['label']:<10} P(leak | same segment leaks on another mic) {m['p_leak_given_other_mic_leaks']:6.1%}"
                     f" vs {m['p_leak']:6.1%}  lift {m['lift']:.1f}")
    return L


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--work", default=os.environ.get("W"))
    p.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    p.add_argument("--set", required=True)
    p.add_argument("--groups", nargs="*", default=DEFAULT_GROUPS)
    p.add_argument("--field", default="pred_ctc")
    p.add_argument("--out")
    args = p.parse_args(argv)
    if not args.work:
        p.error("--work (or $W) is required")
    everything = {}
    for name, labels in parse_groups(args.groups).items():
        rows = {l: load_utts(args.work, args.b_pct, l, args.set) for l in labels}
        rows = {l: r for l, r in rows.items() if r}
        if len(rows) < 2:
            print(f"(group {name}: fewer than two dumps of {args.set}; skipped)")
            continue
        res = analyse_group(rows, args.set, args.field)
        everything[name] = res
        print("\n".join(report(name, res)))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(everything, f, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
