"""What does each fix cost? Leak rate against recognition errors and kept English words (v26).

Every method is run on the frame dumps of every final model:
  greedy                the model as it is
  b = x                 add x to the score of every Latin token (x < 0 favours Thai)
  lock, lock:k=12/25    decide the script of the utterance once (whole utterance, or the
                        first k frames as a streaming system would), then ban the other
  marg, marg:tau,rho    per-frame script decision by summed probability mass

The constant b is chosen per model on the real dev sets by three rules:
  min-leak   lowest dev leak (both directions summed), as in v25
  tol        lowest dev leak among the b whose dev CER (Thai) and dev WER (English)
             are at most TOL above greedy (default 2 points)
  min-err    lowest dev CER(Thai) + WER(English), leakage not looked at

Reported on the test sets: leak both ways, CER on LOTUSDIS Thai, WER on AMI,
and on the LOTUSDIS utterances that really mix Thai and English: share of the
reference's English words kept (recall) and CER. When dumps of AMI close-talk
(real_amiihm_en) exist, leak and WER there too, with b still chosen on the
far-field dev. Then the trade-off curve over b, and leak/CER per microphone.

CPU only.   python -m scriptleak.pareto --work $W
"""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import sys
from collections import Counter
from typing import Dict, List, Optional, Tuple

import numpy as np

from .decoding import decode
from .dumpio import iter_dump, read_meta
from .normalize import scoring_normalize
from .realstats import DEFAULT_GROUPS, EN, TH, parse_groups, spoken_other
from .retention import latin_words
from .tokenmap import ids_to_text, token_groups

DEV = ("dev_lotus_th", "dev_ami_en")
TEST = ("real_lotus_th", "real_ami_en")
MIXED = "real_lotus_mixed"
IHM = "real_amiihm_en"
B_GRID = [round(float(b), 1) for b in np.arange(-10.0, 6.01, 0.5)]
FIXED = ["lock", "lock:k=12", "lock:k=25", "marg", "marg:tau=0.5,rho=0.9"]

try:  # C implementations if the environment has one
    import editdistance as _ed

    def edit_distance(a, b) -> int:
        return int(_ed.eval(a, b))
except ImportError:  # pragma: no cover - depends on the environment
    try:
        from rapidfuzz.distance import Levenshtein as _lev

        def edit_distance(a, b) -> int:
            return int(_lev.distance(a, b))
    except ImportError:
        from .metrics import edit_distance  # noqa: F401  (pure Python)


def spec_of(name: str) -> str:
    """'b=-6.5' -> decoding spec (decoding.logit_bias subtracts its b from Latin)."""
    if name == "greedy":
        return "greedy"
    if name.startswith("b="):
        return f"bias:b={-float(name[2:])}"
    return name


def method_names() -> List[str]:
    return ["greedy"] + [f"b={b}" for b in B_GRID if b != 0.0] + FIXED


# ------------------------------------------------------------------ one dump

def score_dump(path: str, set_name: str, names: List[str]) -> Dict:
    meta = read_meta(path)
    vocab, blank = meta["vocab"], int(meta["blank_id"])
    groups = token_groups(vocab, TH, EN, blank_id=blank)
    specs = [spec_of(n) for n in names]
    mixed = set_name == MIXED
    spoken, other = (TH, EN) if mixed else spoken_other(set_name)
    english = spoken is EN
    leak, errs, ref_len, strata, kept, ref_words = [], [], [], [], [], []
    keys, clusters = [], []
    for rec, logp in iter_dump(path):
        ref = scoring_normalize(str(rec.get("text", "")))
        if not mixed and (other.script.count(ref) or not spoken.script.count(ref)):
            continue
        r_units = ref.split() if english else ref.replace(" ", "")
        rw = Counter(latin_words(ref)) if mixed else None
        cache: Dict[str, Tuple[int, bool, int]] = {}
        row_e, row_l, row_k = [], [], []
        for s in specs:
            hyp = scoring_normalize(ids_to_text(decode(logp, groups, s), vocab))
            if hyp not in cache:
                h_units = hyp.split() if english else hyp.replace(" ", "")
                k = sum((rw & Counter(latin_words(hyp))).values()) if mixed else 0
                cache[hyp] = (edit_distance(r_units, h_units), other.script.count(hyp) > 0, k)
            e, l, k = cache[hyp]
            row_e.append(e)
            row_l.append(l)
            row_k.append(k)
        errs.append(row_e)
        leak.append(row_l)
        kept.append(row_k)
        ref_len.append(len(r_units))
        ref_words.append(sum(rw.values()) if mixed else 0)
        strata.append(str(rec.get("stratum", "")))
        keys.append(str(rec.get("audio_filepath")))
        clusters.append(str(rec.get("meeting") or rec.get("speaker_id") or rec.get("audio_filepath")))
    return {"names": names, "leak": np.array(leak, bool).reshape(-1, len(names)),
            "errs": np.array(errs, np.int64).reshape(-1, len(names)), "ref_len": np.array(ref_len, np.int64),
            "kept": np.array(kept, np.int64).reshape(-1, len(names)), "ref_words": np.array(ref_words, np.int64),
            "strata": np.array(strata), "keys": keys, "clusters": np.array(clusters)}


def _job(args):
    path, set_name, names = args
    try:
        return path, set_name, score_dump(path, set_name, names)
    except Exception as e:  # one bad dump must not stop the rest
        return path, set_name, f"{type(e).__name__}: {e}"


# ------------------------------------------------------------------ summaries

def rates(d: Dict, sel: Optional[np.ndarray] = None) -> Dict[str, np.ndarray]:
    """Per method: leak rate, error rate, English-word recall (mixed set)."""
    if sel is None:
        sel = np.ones(len(d["ref_len"]), bool)
    n = max(1, int(d["ref_len"][sel].sum()))
    w = max(1, int(d["ref_words"][sel].sum()))
    return {"leak": d["leak"][sel].mean(axis=0) if sel.any() else np.full(len(d["names"]), np.nan),
            "err": d["errs"][sel].sum(axis=0) / n,
            "recall": d["kept"][sel].sum(axis=0) / w}


def choose(dev: Dict[str, Dict[str, np.ndarray]], names: List[str], tol: float) -> Dict[str, str]:
    """Pick b on the dev sets by the three rules."""
    idx = [i for i, n in enumerate(names) if n == "greedy" or n.startswith("b=")]
    bval = {i: 0.0 if names[i] == "greedy" else float(names[i][2:]) for i in idx}
    leak = dev[DEV[0]]["leak"] + dev[DEV[1]]["leak"]
    cer_th, wer_en = dev[DEV[0]]["err"], dev[DEV[1]]["err"]
    g = names.index("greedy")

    def best(cands, key):
        return names[min(cands, key=lambda i: (round(float(key[i]), 6), abs(bval[i])))]

    ok = [i for i in idx if cer_th[i] <= cer_th[g] + tol and wer_en[i] <= wer_en[g] + tol]
    return {"min-leak": best(idx, leak), "tol": best(ok, leak), "min-err": best(idx, cer_th + wer_en)}


def run(work: str, b_pct: str, groups: Dict[str, List[str]], workers: int = 16,
        tol: float = 0.02, log=print) -> Dict:
    names = method_names()
    labels = [l for ls in groups.values() for l in ls]
    sets = DEV + TEST + (MIXED, IHM)
    jobs = []
    for l in labels:
        for s in sets:
            p = os.path.join(work, "dumps", f"B{b_pct}_{l}", s)
            if os.path.exists(os.path.join(p, "meta.json")):
                jobs.append((p, s, names))
    log(f"decoding {len(jobs)} dumps x {len(names)} methods with {workers} workers ...")
    got: Dict[Tuple[str, str], Dict] = {}
    with mp.get_context("spawn").Pool(max(1, workers)) as pool:
        for k, (p, s, d) in enumerate(pool.imap_unordered(_job, jobs), 1):
            if isinstance(d, str):
                log(f"!! {p}: {d}")
            else:
                got[(os.path.basename(os.path.dirname(p))[len(f"B{b_pct}_"):], s)] = d
            if k % 8 == 0 or k == len(jobs):
                log(f"  {k}/{len(jobs)}")
    res: Dict = {"names": names, "tol": tol, "models": {}, "groups": {}}
    for l in labels:
        if not all((l, s) in got for s in DEV + TEST):
            log(f"   {l}: dev or test dumps missing, skipped")
            continue
        R = {s: rates(got[(l, s)]) for s in sets if (l, s) in got}
        pick = choose(R, names, tol)
        res["models"][l] = {"pick": pick, "rates": {s: {k: v.tolist() for k, v in r.items()} for s, r in R.items()},
                            "_d": {s: got[(l, s)] for s in sets if (l, s) in got}}
    rows = ["greedy", "min-leak", "tol", "min-err"] + FIXED
    for g, ls in groups.items():
        ls = [l for l in ls if l in res["models"]]
        if not ls:
            continue
        out = {}
        for row in rows:
            vals = []
            for l in ls:
                m = res["models"][l]
                n = m["pick"].get(row, row)
                i = names.index(n)
                r = m["rates"]
                v = {"Th>L": r[TEST[0]]["leak"][i], "En>Th": r[TEST[1]]["leak"][i],
                     "CER": r[TEST[0]]["err"][i], "WER": r[TEST[1]]["err"][i], "b": n}
                v["sum"] = v["Th>L"] + v["En>Th"]
                if MIXED in r:
                    v["recall"], v["mixCER"] = r[MIXED]["recall"][i], r[MIXED]["err"][i]
                if IHM in r:
                    v["ihm"], v["ihmWER"] = r[IHM]["leak"][i], r[IHM]["err"][i]
                vals.append(v)
            agg = {k: float(np.mean([v[k] for v in vals])) for k in vals[0] if k != "b" and all(k in v for v in vals)}
            agg["sd"] = float(np.std([v["sum"] for v in vals], ddof=1)) if len(vals) > 1 else 0.0
            agg["b"] = [v["b"] for v in vals]
            out[row] = agg
        res["groups"][g] = out
    # trade-off curve over b, symmetric recipes vs the Thai-heavy one
    fam = {"symmetric": [l for g, ls in groups.items() if g != "th" for l in ls if l in res["models"]],
           "th": [l for l in groups.get("th", []) if l in res["models"]]}
    res["curve"] = {}
    for f, ls in fam.items():
        if not ls:
            continue
        rows_c = []
        for n in ["b=-10.0", "b=-8.0", "b=-6.0", "b=-5.0", "b=-4.0", "b=-3.0", "b=-2.0", "b=-1.0", "greedy",
                  "b=1.0", "b=2.0", "b=3.0", "b=4.0", "b=6.0"]:
            i = names.index(n)
            r = [res["models"][l]["rates"] for l in ls]
            row = {"b": 0.0 if n == "greedy" else float(n[2:]),
                   "sum": float(np.mean([x[TEST[0]]["leak"][i] + x[TEST[1]]["leak"][i] for x in r])),
                   "CER": float(np.mean([x[TEST[0]]["err"][i] for x in r])),
                   "WER": float(np.mean([x[TEST[1]]["err"][i] for x in r]))}
            if all(MIXED in x for x in r):
                row["recall"] = float(np.mean([x[MIXED]["recall"][i] for x in r]))
            if all(IHM in x for x in r):
                row["ihm"] = float(np.mean([x[IHM]["leak"][i] for x in r]))
                row["ihmWER"] = float(np.mean([x[IHM]["err"][i] for x in r]))
            rows_c.append(row)
        res["curve"][f] = rows_c
    # per microphone, symmetric recipes pooled
    ls = fam["symmetric"]
    if ls:
        strata = sorted(set(res["models"][ls[0]]["_d"][TEST[0]]["strata"].tolist()))
        per = {}
        for st in strata:
            row = {}
            for meth in ("greedy", "min-leak", "tol", "lock"):
                lk, er = [], []
                for l in ls:
                    m = res["models"][l]
                    d = m["_d"][TEST[0]]
                    i = names.index(m["pick"].get(meth, meth))
                    r = rates(d, d["strata"] == st)
                    lk.append(r["leak"][i])
                    er.append(r["err"][i])
                row[meth] = (float(np.mean(lk)), float(np.mean(er)))
            row["n"] = int((res["models"][ls[0]]["_d"][TEST[0]]["strata"] == st).sum())
            per[st] = row
        res["per_mic"] = per
    return res


def report(res: Dict) -> List[str]:
    L = [f"Rules for b (chosen per model on the real dev sets): min-leak = lowest leak; tol = lowest leak with dev "
         f"CER and WER at most {res['tol']:.0%} above greedy; min-err = lowest CER + WER."]
    has_mix = any("recall" in v for g in res["groups"].values() for v in g.values())
    has_ihm = any("ihm" in v for g in res["groups"].values() for v in g.values())
    head = (f"  {'method':<22} {'Th>L':>6} {'En>Th':>6} {'sum':>6} {'(sd)':>6} {'CER Th':>7} {'WER En':>7}"
            + (f" {'EN kept':>8} {'mix CER':>8}" if has_mix else "")
            + (f" {'IHM En>Th':>10} {'IHM WER':>8}" if has_ihm else ""))
    for g, rows in res["groups"].items():
        L.append(f"\n=== {g}: test sets, mean over seeds")
        L.append(head)
        for row, v in rows.items():
            label = row
            if row in ("min-leak", "tol", "min-err"):
                label = f"{row} (" + ",".join(b.replace("b=", "") for b in v["b"]) + ")"
            line = (f"  {label:<22} {v['Th>L']:6.1%} {v['En>Th']:6.1%} {v['sum']:6.1%} {v['sd']:6.1%} "
                    f"{v['CER']:7.1%} {v['WER']:7.1%}")
            if has_mix:
                line += f" {v.get('recall', float('nan')):8.1%} {v.get('mixCER', float('nan')):8.1%}"
            if has_ihm:
                line += f" {v.get('ihm', float('nan')):10.1%} {v.get('ihmWER', float('nan')):8.1%}"
            L.append(line)
    for f, rows in res.get("curve", {}).items():
        L.append(f"\nTrade-off over a shared b, {f} recipe(s), mean over models (test sets)")
        L.append(f"  {'b':>6} {'leak sum':>9} {'CER Th':>7} {'WER En':>7}" + (f" {'EN kept':>8}" if has_mix else "")
                 + (f" {'IHM En>Th':>10} {'IHM WER':>8}" if has_ihm else ""))
        for r in rows:
            line = f"  {r['b']:+6.1f} {r['sum']:9.1%} {r['CER']:7.1%} {r['WER']:7.1%}"
            if has_mix:
                line += f" {r.get('recall', float('nan')):8.1%}"
            if has_ihm:
                line += f" {r.get('ihm', float('nan')):10.1%} {r.get('ihmWER', float('nan')):8.1%}"
            L.append(line)
    if res.get("per_mic"):
        L.append("\nLOTUSDIS Thai per microphone, symmetric recipes pooled: leak / CER")
        L.append(f"  {'mic':<20} {'n':>5} {'greedy':>15} {'min-leak':>15} {'tol':>15} {'lock':>15}")
        for st, r in res["per_mic"].items():
            L.append(f"  {st:<20} {r['n']:>5} " + " ".join(f"{r[m][0]:6.1%}/{r[m][1]:6.1%}".rjust(15)
                                                          for m in ("greedy", "min-leak", "tol", "lock")))
    return L


def _jsonable(res: Dict) -> Dict:
    out = {k: v for k, v in res.items() if k != "models"}
    out["models"] = {l: {k: v for k, v in m.items() if k != "_d"} for l, m in res["models"].items()}
    return out


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--work", default=os.environ.get("W"))
    p.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    p.add_argument("--groups", nargs="*", default=DEFAULT_GROUPS)
    p.add_argument("--workers", type=int, default=int(os.environ.get("CALIB_WORKERS", "16")))
    p.add_argument("--tol", type=float, default=float(os.environ.get("PARETO_TOL", "0.02")))
    p.add_argument("--out")
    args = p.parse_args(argv)
    if not args.work:
        p.error("--work (or $W) is required")
    res = run(args.work, args.b_pct, parse_groups(args.groups), args.workers, args.tol)
    if not res["groups"]:
        print("no model has dumps on all four dev/test sets (run 'selectC' first)")
        return 1
    print("\n".join(report(res)))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(_jsonable(res), f, ensure_ascii=False, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
