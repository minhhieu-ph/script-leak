"""Wrong-script output in both directions, side by side.

Phase B showed the error can point either way: a model may write Thai noisy
speech in Latin letters, or English noisy speech in Thai letters, and a clean
model can switch from one to the other between two checkpoints. Reporting one
direction alone hides that. Each cell here is

    Thai speech -> Latin letters  /  English speech -> Thai letters

(share of utterances), per stratum both test sets share, plus their sum at
the hardest stratum.

  python -m scriptleak.twoway base=results/B20_base/heldout.json,results/B20_base/en.json \\
      both=results/B20_both/heldout.json,results/B20_both/en.json
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Dict, List, Optional, Tuple

ORDER = ["clean", "snr20", "snr10", "snr5", "snr0"]


def _load(path: str, method: str = "greedy") -> Optional[Dict]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    if method in data:
        return data[method]
    return data if "ALL" in data else None


def rows_for(items: List[str], method: str = "greedy") -> List[Tuple[str, Optional[Dict], Optional[Dict]]]:
    out = []
    for item in items:
        name, paths = item.split("=", 1)
        th_path, _, en_path = paths.partition(",")
        out.append((name, _load(th_path, method), _load(en_path, method) if en_path else None))
    return out


def table(items: List[str], method: str = "greedy", strata: Optional[List[str]] = None) -> str:
    rows = rows_for(items, method)
    order = strata or ORDER
    strata = [s for s in order if any(th and s in th for _, th, _ in rows)
              and any(en and s in en for _, _, en in rows)]
    if not strata:
        return "nothing to compare (no stratum in both test sets)"
    hardest = strata[-1]
    width = max(8, max(len(n) for n, _, _ in rows))
    lines = [f"{'model':<{width}}  " + "  ".join(f"{s:>15}" for s in strata) + f"  {'sum ' + hardest:>10}"]
    for name, th, en in rows:
        cells = []
        for s in strata:
            a = f"{th[s]['slr_u']:.1%}" if th and s in th else "-"
            b = f"{en[s]['slr_u']:.1%}" if en and s in en else "-"
            cells.append(f"{a + ' / ' + b:>15}")
        if th and en and hardest in th and hardest in en:
            total = f"{th[hardest]['slr_u'] + en[hardest]['slr_u']:>10.1%}"
        else:
            total = f"{'-':>10}"
        lines.append(f"{name:<{width}}  " + "  ".join(cells) + f"  {total}")
    lines.append("(each cell: Thai speech written in Latin / English speech written in Thai, share of utterances)")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("results", nargs="+", metavar="NAME=THAI_JSON[,ENGLISH_JSON]")
    p.add_argument("--method", default="greedy")
    p.add_argument("--strata", nargs="*", help="strata to show (default: clean, snr20, snr10, snr5, snr0)")
    args = p.parse_args(argv)
    print(table(args.results, args.method, args.strata))
    return 0


if __name__ == "__main__":
    sys.exit(main())
