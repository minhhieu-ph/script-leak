import json
import os

import numpy as np

from scriptleak import singlerun
from tests.test_v25 import _fake_dump


def test_singlerun(tmp_path):
    rng = np.random.default_rng(7)
    work = str(tmp_path)
    groups = {"A": ["a", "a_s1"]}
    for l, sh in {"a": 1.2, "a_s1": 0.2}.items():
        for s in singlerun.DEV + singlerun.TEST:
            for c, extra in (("final", 0.0), ("avg", -0.5), ("epoch030", -1.0), ("epoch040", 0.5)):
                _fake_dump(singlerun.cand_dir(work, "20", l, c, s), s, 30,
                           np.random.default_rng(hash((l, s)) % 1000), sh + extra)
    res = singlerun.run(work, "20", groups, workers=2, resamples=200, log=lambda *a: None)
    v = res["groups"]["A"]
    r = v["rows"]
    for name in ("final, greedy", "final, lock", "one run: dev picks + lock", "three runs: dev picks + lock"):
        lo, hi = r[name]["ci"]
        assert lo <= r[name]["mean"] + 1e-9 and r[name]["mean"] <= hi + 1e-9
    assert all(p.split(":")[1] in ("final", "avg", "epoch030", "epoch040") for p in r["one run: dev picks + lock"]["picks"])
    text = "\n".join(singlerun.report(res))
    assert "change vs 'final, greedy'" in text and "Per run" in text
    json.dumps(res)


def test_candidates(tmp_path):
    os.makedirs(tmp_path / "dumps" / "B20_x" / "sel_epoch035_dev_lotus_th")
    assert singlerun.candidates(str(tmp_path), "20", "x") == ["final", "avg", "epoch035"]
