import io
import json
import os
import tarfile

import numpy as np
import pytest

from scriptleak import real, retention
from scriptleak.manifest import read_manifest, write_manifest


def test_mixed_normalize_kinds():
    assert real.mixed_normalize("สวัสดี ครับ") == ("สวัสดี ครับ", "thai")
    assert real.mixed_normalize("ใช้ Google Meet นะ") == ("ใช้ google meet นะ", "mixed")
    assert real.mixed_normalize("ประชุม 3 โมง")[1] == "digit"
    assert real.mixed_normalize("๓ โมง")[1] == "digit"
    assert real.mixed_normalize("ไป ๆ")[1] == "repeat_mark"
    assert real.mixed_normalize("hello world")[1] == "latin_only"
    assert real.mixed_normalize("ราคา 50%")[1] == "digit"
    assert real.mixed_normalize("โอเค, ไปกัน!")[0] == "โอเค ไปกัน"
    assert real.mixed_normalize("café ดี")[1] == "accented_latin"
    assert real.mixed_normalize("  ")[1] == "empty"


def _lotus_rows():
    rows = []
    for seg in range(200):
        text = f"ข้อความ {seg} ทดสอบ".replace(str(seg), "ก" * (seg % 7 + 1))
        if seg % 10 == 0:
            text += " zoom"
        for mic in ("m1", "m2", "m3"):
            rows.append({"audio_filepath": f"/x/{seg}_{mic}.wav", "duration": 2.0, "text": text,
                         "speaker_id": f"s{seg % 5}", "mic": mic})
    rows.append({"audio_filepath": "/x/long.wav", "duration": 45.0, "text": "ยาว", "speaker_id": "s0", "mic": "m1"})
    return rows


def test_build_keeps_the_same_segments_for_every_mic():
    thai, mixed, rep = real.build(_lotus_rows(), "lotus", "mic", keep_frac=0.4,
                                  group_fields=["speaker_id", "text"])
    by_mic = {}
    for r in thai + mixed:
        by_mic.setdefault(r["stratum"], set()).add((r["speaker_id"], r["text"]))
    assert set(by_mic) == {"lotus/m1", "lotus/m2", "lotus/m3"}
    assert by_mic["lotus/m1"] == by_mic["lotus/m2"] == by_mic["lotus/m3"]
    kept = len(by_mic["lotus/m1"])
    assert 0 < kept < 200
    assert rep["dropped"]["duration"] == 1
    assert all("zoom" in r["text"] for r in mixed) and mixed
    assert not any("zoom" in r["text"] for r in thai)
    assert all(r["text_raw"] and r["lang"] == "th" for r in thai)


def test_split_by_stratum(tmp_path):
    thai, _, _ = real.build(_lotus_rows(), "lotus", "mic")
    items = real.split_by_stratum(thai, str(tmp_path / "strata"))
    assert len(items) == 3
    name, path = items[0].split("=", 1)
    assert name == "lotus/m1" and os.path.basename(path) == "lotus_m1.jsonl"
    assert all(e["stratum"] == "lotus/m1" for e in read_manifest(path))


def test_build_cli(tmp_path, capsys):
    raw = tmp_path / "raw.jsonl"
    write_manifest(str(raw), _lotus_rows())
    rc = real.main(["build", "--manifest", str(raw), "--name", "lotus", "--stratum-field", "mic",
                    "--out-thai", str(tmp_path / "th.jsonl"), "--out-mixed", str(tmp_path / "mx.jsonl"),
                    "--report", str(tmp_path / "rep.json"), "--strata-dir", str(tmp_path / "s")])
    assert rc == 0
    out = capsys.readouterr().out
    assert "Thai-only references" in out and "lotus/m2" in out
    rep = json.loads((tmp_path / "rep.json").read_text())
    assert rep["thai_only"] + rep["mixed"] == 600


def _tar_with(tmp_path, names):
    path = tmp_path / "a.tar.gz"
    with tarfile.open(path, "w:gz") as tf:
        for n in names:
            data = b"abc"
            info = tarfile.TarInfo(n)
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
    return str(path)


def test_safe_extract(tmp_path):
    ok = _tar_with(tmp_path, ["test/a.wav", "test/sub/b.wav"])
    assert real.safe_extract(ok, str(tmp_path / "out")) == 2
    assert (tmp_path / "out" / "test" / "sub" / "b.wav").read_bytes() == b"abc"
    bad = _tar_with(tmp_path, ["../evil.wav"])
    with pytest.raises(ValueError):
        real.safe_extract(bad, str(tmp_path / "out2"))


def test_gigaspeech2_entries_accept_flac(tmp_path):
    sf = pytest.importorskip("soundfile")
    from scriptleak.prepare import gigaspeech2_entries

    d = tmp_path / "test" / "x"
    d.mkdir(parents=True)
    sf.write(str(d / "seg1.flac"), np.zeros(16000, dtype=np.float32), 16000)
    sf.write(str(d / "seg2.wav"), np.zeros(8000, dtype=np.float32), 16000)
    tsv = tmp_path / "test.tsv"
    tsv.write_text("seg1\tสวัสดี\nseg2\tครับ\nseg3\tหาย\n", encoding="utf-8")
    rows = list(gigaspeech2_entries(str(tsv), str(tmp_path / "test")))
    assert [r["utt_id"] for r in rows] == ["seg1", "seg2"]
    assert abs(rows[0]["duration"] - 1.0) < 1e-6


def test_retention_scores():
    rows = [
        {"text": "เปิด zoom ก่อน", "pred_ctc": "เปิด zoom ก่อน", "stratum": "a"},
        {"text": "ใช้ google meet", "pred_ctc": "ใช้ กูเกิล meet", "stratum": "a"},
        {"text": "ส่ง line มา", "pred_ctc": "ส่ง ไลน์ มา hello", "stratum": "b"},
    ]
    res = retention.score(rows, "stratum")
    assert list(res) == ["pred_ctc"]
    all_ = res["pred_ctc"]["ALL"]
    assert all_["ref_latin_words"] == 4
    assert all_["latin_recall"] == pytest.approx(2 / 4)
    assert all_["latin_utts"] == pytest.approx(1.0)
    assert all_["extra_latin"] == pytest.approx(1 / 3)
    assert res["pred_ctc"]["a"]["latin_recall"] == pytest.approx(2 / 3)
    assert res["pred_ctc"]["ALL"]["cer"] > 0


def test_retention_table(tmp_path):
    res = retention.score([{"text": "เปิด zoom", "pred_ctc": "เปิด ซูม", "pred_transducer": "เปิด zoom"}])
    p = tmp_path / "r.json"
    p.write_text(json.dumps(res))
    out = retention.table([f"base={p}"])
    assert "base" in out and "0.0%" in out and "100.0%" in out


def test_compare_reads_evaluate_files(tmp_path, capsys):
    from scriptleak import compare

    ev = {"ALL": {"slr_u": 0.1, "cer": 0.2}, "lotus/m1": {"slr_u": 0.3, "cer": 0.4}}
    sw = {"greedy": {"ALL": {"slr_u": 0.05, "cer": 0.1}}}
    (tmp_path / "ev.json").write_text(json.dumps(ev))
    (tmp_path / "sw.json").write_text(json.dumps(sw))
    assert compare.main([f"a={tmp_path / 'ev.json'}", f"b={tmp_path / 'sw.json'}"]) == 0
    out = capsys.readouterr().out
    assert "30.00%" in out and "5.00%" in out


def test_load_hf_with_data_files_skips_split_check(monkeypatch):
    import sys
    import types

    from scriptleak import prepare

    seen = {}

    def fake_load_dataset(*args, **kw):
        seen.update(kw, args=args)
        ns = types.SimpleNamespace(features=None)
        ns.cast_column = lambda name, feat: ns
        return ns

    fake = types.ModuleType("datasets")
    fake.load_dataset = fake_load_dataset
    fake.Audio = lambda **kw: None
    monkeypatch.setitem(sys.modules, "datasets", fake)
    prepare._load_hf("nectec/LOTUSDIS", None, "test", "audio", "data/test-*")
    assert seen["data_files"] == {"test": "data/test-*"}
    assert seen["verification_mode"] == "no_checks"
