import os

import numpy as np

from scriptleak import pareto
from scriptleak.dumpio import DumpWriter
from tests.test_v25 import BLANK, VOCAB, _fake_dump


def _mixed_dump(path, n, rng, shift):
    with DumpWriter(path, VOCAB, BLANK) as w:
        for i in range(n):
            T = int(rng.integers(8, 30))
            lp = rng.normal(0, 1, size=(T, len(VOCAB) + 1)).astype(np.float32)
            lp[:, BLANK] += 1.0
            lp[: T // 2, 1:4] += 1.5
            lp[T // 2:, 4:7] += 1.5 + shift
            lp = lp - np.log(np.exp(lp).sum(1, keepdims=True))
            w.add({"audio_filepath": f"/mix/{i}.wav", "text": "สวัสดี hello", "stratum": "lotus/mix"}, lp)


def test_spec_sign():
    assert pareto.spec_of("b=-6.5") == "bias:b=6.5"
    assert pareto.spec_of("greedy") == "greedy"
    assert pareto.spec_of("lock:k=12") == "lock:k=12"
    assert "greedy" in pareto.method_names() and "b=0.0" not in pareto.method_names()


def test_run(tmp_path):
    rng = np.random.default_rng(3)
    work = str(tmp_path)
    groups = {"A": ["a", "a_s1"], "th": ["t", "t_s1"]}
    for l, sh in {"a": 1.5, "a_s1": 0.5, "t": -1.0, "t_s1": -0.5}.items():
        for s in pareto.DEV + pareto.TEST + (pareto.IHM,):
            _fake_dump(os.path.join(work, "dumps", f"B20_{l}", s), s, 25, rng, sh)
        _mixed_dump(os.path.join(work, "dumps", f"B20_{l}", pareto.MIXED), 20, rng, sh)
    res = pareto.run(work, "20", groups, workers=2, tol=0.02, log=lambda *a: None)
    names = res["names"]
    for l, m in res["models"].items():
        r = m["rates"]
        g = names.index("greedy")
        i = names.index(m["pick"]["tol"])
        assert r["dev_lotus_th"]["err"][i] <= r["dev_lotus_th"]["err"][g] + 0.02 + 1e-9
        lm = names.index(m["pick"]["min-leak"])
        assert (r["dev_lotus_th"]["leak"][lm] + r["dev_ami_en"]["leak"][lm]
                <= r["dev_lotus_th"]["leak"][g] + r["dev_ami_en"]["leak"][g] + 1e-9)
        # banning Latin keeps no English word
        assert r[pareto.MIXED]["recall"][names.index("b=-10.0")] <= r[pareto.MIXED]["recall"][g] + 1e-9
    text = "\n".join(pareto.report(res))
    assert "EN kept" in text and "IHM" in text and "per microphone" in text
    import json
    json.dumps(pareto._jsonable(res))
