import json

import pytest

from scriptleak import real, realdiag, twoway
from scriptleak.languages import get_language


def test_ami_key_ignores_the_microphone():
    a = real.ami_key("AMI_EN2002a_H00_MEE071_0000557_0000594")
    b = real.ami_key("eval_ami_en2002a_sdm1_mee071_0000557_0000594.wav")
    c = real.ami_key("/x/y/AMI_EN2002a_SDM_MEE071_0000557_0000594.wav")
    assert a == b == c == ("en2002a", "mee071", "0000557", "0000594")
    assert real.ami_key("README") is None


def test_ami_entries_match_far_field_wavs(tmp_path):
    d = tmp_path / "audio"
    d.mkdir()
    (d / "eval_ami_en2002a_sdm1_mee071_0000557_0000594.wav").write_bytes(b"x")
    text = tmp_path / "text"
    text.write_text("AMI_EN2002a_H00_MEE071_0000557_0000594 OKAY SO LET'S START\n"
                    "AMI_EN2002a_H01_FEO072_0000600_0000700 YEAH\n", encoding="utf-8")
    rows = list(real.ami_entries(str(text), str(d), duration_fn=lambda p: 2.5))
    assert len(rows) == 1
    assert rows[0]["text"] == "OKAY SO LET'S START" and rows[0]["meeting"] == "en2002a"
    assert rows[0]["duration"] == 2.5


def test_build_en_spoken_form_and_sampling():
    rows = [{"text": "OKAY SO LET'S START", "duration": 2.0, "meeting": "m", "speaker_id": "s"},
            {"text": "WE HAVE 3 ITEMS", "duration": 2.0, "meeting": "m", "speaker_id": "s"},
            {"text": "HMM", "duration": 0.2, "meeting": "m", "speaker_id": "s"}]
    out, rep = real.build_en(rows, "ami")
    assert [r["text"] for r in out] == ["okay so let's start"]
    assert out[0]["stratum"] == "ami" and out[0]["lang"] == "en"
    assert rep["dropped"] == {"digit": 1, "duration": 1}
    many = [{"text": f"word {chr(97 + i % 26)}{i}".replace(str(i), ""), "duration": 2.0,
             "meeting": str(i), "speaker_id": "s"} for i in range(400)]
    half, _ = real.build_en(many, "ami", keep_frac=0.5)
    assert 120 < len(half) < 280


def _rows():
    return [
        {"audio_filepath": "a", "text": "สวัสดี", "pred_ctc": "hello", "stratum": "m1", "duration": 1.0},
        {"audio_filepath": "b", "text": "สวัสดี", "pred_ctc": "สวัสดี", "stratum": "m1", "duration": 2.0},
        {"audio_filepath": "c", "text": "สวัสดี", "pred_ctc": "", "stratum": "m2", "duration": 5.0},
        {"audio_filepath": "d", "text": "สวัสดีครับ", "pred_ctc": "สวัสดี hi", "stratum": "m2", "duration": 9.0},
    ]


def test_realdiag_uses_the_reference_models_hardness():
    th, en = get_language("th"), get_language("en")
    hard = {"a": 0.1, "b": 0.1, "c": 0.95, "d": 0.5}
    res = realdiag.analyse(_rows(), "pred_ctc", th, en, hard)
    a = res["per"]["ALL"]
    assert (a["n"], a["empty"], a["leak"], a["nonempty"]) == (4, 1, 2, 3)
    assert res["hard"]["<30%"] == [2, 1]
    assert res["hard"]["30-60%"] == [1, 1]
    assert res["dur"][">=8s"] == [1, 1]
    assert res["only_other"] == 1 and res["mixed"] == 1
    # without a reference, an utterance is binned by its own error: the leak at "a" moves up
    own = realdiag.analyse(_rows(), "pred_ctc", th, en, None)
    assert own["hard"].get("<30%", [0, 0])[1] == 0


def test_realdiag_cli(tmp_path, capsys):
    for lab in ("th", "base"):
        d = tmp_path / "dumps" / f"B20_{lab}" / "real_lotus_th"
        d.mkdir(parents=True)
        rows = _rows() if lab == "base" else [dict(r, pred_ctc=r["text"]) for r in _rows()]
        (d / "utts.jsonl").write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in rows), encoding="utf-8")
    rc = realdiag.main(["--work", str(tmp_path), "--set", "real_lotus_th", "--spoken", "th",
                        "--out", str(tmp_path / "o.json")])
    assert rc == 0
    out = capsys.readouterr().out
    assert "summary" in out and "base" in out and "th " in out
    assert json.loads((tmp_path / "o.json").read_text())["CTC"]["base"]["per"]["ALL"]["leak"] == 2


def test_twoway_on_real_sets(tmp_path):
    th = {"greedy": {"ALL": {"slr_u": 0.15}, "lotus/jbl": {"slr_u": 0.2}}}
    en = {"greedy": {"ALL": {"slr_u": 0.3}, "ami": {"slr_u": 0.3}}}
    (tmp_path / "t.json").write_text(json.dumps(th))
    (tmp_path / "e.json").write_text(json.dumps(en))
    out = twoway.table([f"both={tmp_path / 't.json'},{tmp_path / 'e.json'}"], strata=["ALL"])
    assert "15.0% / 30.0%" in out and "45.0%" in out


def test_pick_parquet_finds_the_split_in_several_layouts():
    files = ["README.md", "ihm/test-00000-of-00002.parquet", "sdm/train-00000.parquet",
             "sdm/test-00000-of-00002.parquet", "sdm/test-00001-of-00002.parquet",
             "sdm/validation-00000.parquet"]
    assert real._pick_parquet(files, "sdm", "eval") == ["sdm/test-00000-of-00002.parquet",
                                                         "sdm/test-00001-of-00002.parquet"]
    conv = ["sdm/partial-test/0000.parquet", "sdm/partial-train/0000.parquet", "ihm/test/0000.parquet"]
    assert real._pick_parquet(conv, "sdm", "eval") == ["sdm/partial-test/0000.parquet"]
    assert real._pick_parquet(["data/sdm_eval-0.parquet"], "sdm", "eval") == ["data/sdm_eval-0.parquet"]
    assert real._pick_parquet(files, "sdm", "dev") == ["sdm/validation-00000.parquet"]
