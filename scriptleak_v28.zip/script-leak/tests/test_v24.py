import json
import os

import numpy as np
import pytest

from scriptleak import bootstrap, seedvar, selection
from scriptleak.realstats import filler_like


def _write(work, label, set_name, rows):
    d = os.path.join(work, "dumps", f"B20_{label}", set_name)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "utts.jsonl"), "w", encoding="utf-8") as f:
        f.write("\n".join(json.dumps(r, ensure_ascii=False) for r in rows))


def _lotus_rows(leaky, rng, n_seg=60, mics=("lotus/a", "lotus/b")):
    rows = []
    for s in range(n_seg):
        text = "อืม" if s % 10 == 0 else "สวัสดีครับวันนี้"
        for m in mics:
            hyp = "hello" if (s in leaky and rng.random() < 0.9) else "สวัสดี"
            rows.append({"audio_filepath": f"/{s}_{m}.wav", "text": text, "text_raw": text + str(s),
                         "speaker_id": f"spk{s % 3}", "stratum": m, "pred_ctc": hyp})
    return rows


def test_filler_like():
    assert filler_like("อืม ครับ")
    assert filler_like("เอ่อค่ะ")
    assert not filler_like("ขึ้นเขาใหญ่")
    assert not filler_like("")


def test_poisson_binomial_sums_to_one():
    d = seedvar.poisson_binomial([0.1, 0.5, 0.9])
    assert d.sum() == pytest.approx(1.0)
    assert d[3] == pytest.approx(0.1 * 0.5 * 0.9)


def test_seedvar_sees_shared_utterances(tmp_path):
    rng = np.random.default_rng(0)
    shared = set(range(0, 60, 4))
    groups = {"x": {l: _lotus_rows(shared, rng) for l in ("m0", "m1", "m2")}}
    res = seedvar.analyse_group(groups["x"], "real_lotus_th", "pred_ctc")
    assert res["n"] == 120
    obs, ind = res["k_of_n"]["observed"], res["k_of_n"]["independent"]
    assert obs[3] > ind[3] * 2        # leaking on all seeds far more than independence predicts
    assert all(p["lift"] > 2 for p in res["pairs"])
    assert res["cross_mic"]["per_model"][0]["lift"] > 2
    assert "filler-only" in res["kinds"]
    text = "\n".join(seedvar.report("x", res))
    assert "lift" in text and "across microphones" in text


def test_bootstrap_and_selection_end_to_end(tmp_path, capsys):
    rng = np.random.default_rng(1)
    work = str(tmp_path)
    for i, label in enumerate(("a", "a_s1", "b", "b_s1")):
        leaky = set(range(0, 60, 2 + i))
        _write(work, label, "real_lotus_th", _lotus_rows(leaky, rng))
        _write(work, label, "dev_lotus_th", _lotus_rows(leaky, rng))
        ami = [{"audio_filepath": f"/m{j}.wav", "text": "hello there", "meeting": f"mt{j % 4}",
                "pred_ctc": "สวัสดี" if j % (3 + i) == 0 else "hello"} for j in range(80)]
        _write(work, label, "real_ami_en", ami)
        _write(work, label, "dev_ami_en", ami)
    groups = {"A": ["a", "a_s1"], "B": ["b", "b_s1"]}
    res = bootstrap.run(work, "20", groups, "pred_ctc", 300, 0)
    m = res["models"]["a"]
    lo, hi = m["sum"]["ci"]
    assert lo <= m["sum"]["rate"] <= hi
    assert set(res["groups"]) == {"A", "B"} and len(res["differences"]) == 1
    assert "Per recipe" in "\n".join(bootstrap.report(res))

    sel = selection.run(work, "20", groups, "pred_ctc")
    assert len(sel["candidates"]) == 4
    assert sel["spearman"] > 0.9            # dev and test identical here
    g = sel["groups"]["A"]
    assert g["dev_picks_final"]["test"] == g["best_seed_oracle"]
    assert "random seed" in "\n".join(selection.report(sel))


def test_average_state_dicts():
    torch = pytest.importorskip("torch")
    from scriptleak.nemo_tools.avg_ckpt import average_state_dicts

    a = {"w": torch.tensor([1.0, 2.0]), "n": torch.tensor(3)}
    b = {"w": torch.tensor([3.0, 4.0]), "n": torch.tensor(7)}
    out = average_state_dicts([a, b])
    assert torch.allclose(out["w"], torch.tensor([2.0, 3.0]))
    assert int(out["n"]) == 7
