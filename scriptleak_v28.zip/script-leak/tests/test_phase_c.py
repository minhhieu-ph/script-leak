import json

import numpy as np
import pytest

from scriptleak import heads, nonspeech, probes2
from scriptleak.languages import get_language
from scriptleak.noise import rms


def _db(a, b):
    return 20 * np.log10(rms(a) / rms(b))


def test_soft_has_the_snr_of_noise_but_a_lower_level():
    rng = np.random.default_rng(0)
    x = (0.05 * rng.standard_normal(16000)).astype(np.float32)
    bg = rng.standard_normal(16000).astype(np.float32)
    loud = probes2.mix_snr(x, bg, 10)
    quiet = probes2.soft(x, bg, 10)
    # speech part of the quiet mix is 10 dB down, background at the noise20 level
    bg_quiet = quiet - x * 10 ** (-10 / 20)
    assert _db(x * 10 ** (-10 / 20), bg_quiet) == pytest.approx(10, abs=0.01)
    assert _db(loud, quiet) == pytest.approx(10, abs=0.5)
    q0 = probes2.soft(x, bg, 20)
    assert _db(x * 0.1, q0 - x * 0.1) == pytest.approx(0, abs=0.01)


def test_babble_sums_talkers_at_equal_level():
    class FakePool(probes2.Pool):
        def read(self, i):
            return (0.1 * (i + 1) * np.random.default_rng(i).standard_normal(8000)).astype(np.float32)

    pool = FakePool([f"t{k}" for k in range(5)], 16000)
    picked = []
    orig = pool.read
    pool.read = lambda i: picked.append(i) or orig(i)
    b = probes2.babble(pool, 4000, np.random.default_rng(1), talkers=4, exclude={0})
    assert len(b) == 4000 and rms(b) > 0
    assert 0 not in picked and len(picked) == 4
    # each talker is scaled to the same level before summing
    assert rms(b) == pytest.approx(2.0, rel=0.5)


def test_heads_crosstab():
    th, en = get_language("th"), get_language("en")
    rows = [
        {"text": "สวัสดี", "pred_ctc": "hello", "pred_transducer": "hello", "stratum": "a"},
        {"text": "สวัสดี", "pred_ctc": "hello", "pred_transducer": "สวัสดี", "stratum": "a"},
        {"text": "สวัสดี", "pred_ctc": "สวัสดี", "pred_transducer": "hi", "stratum": "b"},
        {"text": "สวัสดี", "pred_ctc": "สวัสดี", "pred_transducer": "สวัสดี", "stratum": "b"},
        {"text": "zoom", "pred_ctc": "zoom", "pred_transducer": "zoom", "stratum": "b"},
    ]
    t = heads.crosstab(rows, en, th, "stratum")
    a = t["ALL"]
    assert (a["n"], a["ctc"], a["rnnt"], a["both"], a["ctc_only"], a["rnnt_only"]) == (4, 2, 2, 1, 1, 1)
    assert t["a"]["ctc"] == 2 and t["b"]["rnnt_only"] == 1
    assert "overlap" in heads.format_crosstab(t)


def test_nonspeech_compare(tmp_path):
    a = {"babth_only": {"minority_rate": 0.1, "any_rate": 0.5}}
    b = {"babth_only": {"minority_rate": 0.0, "any_rate": 0.2}, "music_only": {"minority_rate": 0.3, "any_rate": 0.4}}
    (tmp_path / "a.json").write_text(json.dumps(a))
    (tmp_path / "b.json").write_text(json.dumps(b))
    out = nonspeech.compare([f"base={tmp_path / 'a.json'}", f"both={tmp_path / 'b.json'}"])
    assert "10.0%" in out and "30.0%" in out and "-" in out
    out = nonspeech.compare([f"base={tmp_path / 'a.json'}"], key="any_rate")
    assert "50.0%" in out


def test_twoway_table(tmp_path):
    from scriptleak import twoway

    th = {"greedy": {"ALL": {"slr_u": 0.05}, "clean": {"slr_u": 0.0}, "snr0": {"slr_u": 0.12}, "korat": {"slr_u": 0.0}}}
    en = {"greedy": {"ALL": {"slr_u": 0.02}, "clean": {"slr_u": 0.0}, "snr0": {"slr_u": 0.036}}}
    (tmp_path / "th.json").write_text(json.dumps(th))
    (tmp_path / "en.json").write_text(json.dumps(en))
    out = twoway.table([f"base={tmp_path / 'th.json'},{tmp_path / 'en.json'}",
                        f"only_th={tmp_path / 'th.json'}"])
    lines = out.splitlines()
    assert "clean" in lines[0] and "snr0" in lines[0] and "korat" not in lines[0]
    assert "12.0% / 3.6%" in lines[1] and "15.6%" in lines[1]
    assert "12.0% / -" in lines[2]
