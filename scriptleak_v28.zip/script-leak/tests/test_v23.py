import os

import numpy as np
import pytest

from scriptleak import augment
from scriptleak.noise import rms


def test_apply_rir_delta_and_delay_keep_the_signal():
    x = np.random.default_rng(0).standard_normal(1600).astype(np.float32) * 0.1
    h = np.zeros(400, dtype=np.float32)
    h[37] = 0.5  # a pure delay: aligned on the peak, the signal comes back unchanged
    y = augment.apply_rir(x, h)
    assert len(y) == len(x)
    assert np.allclose(y, x, atol=1e-5)


def test_apply_rir_reverb_keeps_length_and_level():
    rng = np.random.default_rng(1)
    x = (rng.standard_normal(16000) * 0.05).astype(np.float32)
    t = np.arange(8000) / 16000.0
    h = rng.standard_normal(8000) * np.exp(-6.9 * t / 0.5)
    h[0] = 3.0
    y = augment.apply_rir(x, h.astype(np.float32))
    assert len(y) == len(x)
    assert rms(y) == pytest.approx(rms(x), rel=1e-3)
    assert not np.allclose(y, x)


def test_rir_files_skip_noises_and_test_split(tmp_path):
    names = ["simulated_rirs/smallroom/Room001/Room001-00001.wav",
             "real_rirs_isotropic_noises/RVB2014_type1_rir_largeroom1_far_angla.wav",
             "real_rirs_isotropic_noises/RVB2014_type1_noise_largeroom1_1.wav",
             "pointsource_noises/noise-free-sound-0001.wav"]
    for n in names:
        p = tmp_path / n
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b"x")
    got = augment.rir_files(str(tmp_path))
    assert all("noise" not in os.path.basename(g) and "pointsource" not in g for g in got)
    from scriptleak.noise import noise_split
    assert all(noise_split(g) == "train" for g in got)


def test_plan_rir_is_deterministic_and_respects_probabilities():
    rirs, noises = [f"r{i}.wav" for i in range(10)], [f"n{i}.wav" for i in range(10)]
    entries = [{"audio_filepath": f"/a/{i}.wav"} for i in range(2000)]
    plans = [augment.plan_rir(e, rirs, noises, 0.5, 0.7, 0, 20, 0) for e in entries]
    again = [augment.plan_rir(e, rirs, noises, 0.5, 0.7, 0, 20, 0) for e in entries]
    assert plans == again
    chosen = [p for p in plans if p]
    assert 850 < len(chosen) < 1150
    with_noise = sum("noise_file" in p for p in chosen)
    assert 0.6 < with_noise / len(chosen) < 0.8
    assert all(0 <= p["snr"] <= 20 for p in chosen if "snr" in p)
