import os

import numpy as np

from scriptleak import combo
from tests.test_v25 import BLANK, VOCAB, _fake_dump


def test_combo(tmp_path):
    rng = np.random.default_rng(5)
    work = str(tmp_path)
    groups = {"A": ["a", "a_s1", "a_s2"]}
    for l, sh in {"a": 1.5, "a_s1": 0.3, "a_s2": -0.8}.items():
        for s in combo.DEV + combo.TEST:
            _fake_dump(os.path.join(work, "dumps", f"B20_{l}", s), s, 30, rng, sh)
            _fake_dump(os.path.join(work, "dumps", f"B20_{l}", "stream_" + s), s, 30, rng, sh)
    res = combo.run(work, "20", groups, workers=2, log=lambda *a: None)
    assert set(res["modes"]) == {"offline", "streaming"}
    rows = res["modes"]["offline"]["A"]
    assert rows["best seed (oracle)"]["sum"] <= rows["random seed, greedy"]["sum"] + 1e-9
    assert rows["dev picks, lock"]["pick"] in groups["A"]
    assert "a" in res["agreement"]
    text = "\n".join(combo.report(res))
    assert "proposal vs random seed" in text and "Streaming vs offline" in text


def test_stream_compare():
    from scriptleak.nemo_tools.stream_dump import compare

    x = np.log(np.full((5, len(VOCAB) + 1), 1.0 / (len(VOCAB) + 1)))
    x[:, 1] = 0.0
    r = compare([x, x], [x, x[:4]], BLANK, VOCAB)
    assert r["same_text"] == 1.0 and r["frames_off"] == 0.5
