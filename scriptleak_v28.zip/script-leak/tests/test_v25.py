import json
import os

import numpy as np

from scriptleak import calib
from scriptleak.dumpio import DumpWriter
from scriptleak.realstats import EN, TH

VOCAB = ["▁", "ก", "ข", "สวัสดี", "▁a", "b", "hello", "'"]
BLANK = len(VOCAB)


def _fake_dump(path, set_name, n, rng, shift):
    with DumpWriter(path, VOCAB, BLANK) as w:
        for i in range(n):
            T = int(rng.integers(5, 30))
            lp = rng.normal(0, 1, size=(T, len(VOCAB) + 1)).astype(np.float32)
            lp[:, BLANK] += 1.5
            if set_name.endswith("_en"):
                lp[:, 4:7] += 1.0
                text = "hello there"
            else:
                lp[:, 1:4] += 1.0
                text = "สวัสดีครับ"
            lp[:, 4:7] += shift
            lp = lp - np.log(np.exp(lp).sum(1, keepdims=True))
            from scriptleak.tokenmap import ids_to_text
            from scriptleak.decoding import collapse
            pred = ids_to_text(collapse(lp.astype(np.float16).astype(np.float32).argmax(1), BLANK), VOCAB)
            w.add({"audio_filepath": f"/{set_name}/{i}.wav", "text": text, "pred_ctc": pred}, lp)


def test_threshold_matches_decoding(tmp_path):
    rng = np.random.default_rng(0)
    for set_name in ("dev_lotus_th", "dev_ami_en"):
        d = str(tmp_path / set_name)
        _fake_dump(d, set_name, 60, rng, 0.0)
        s = calib.summarise_dump(d, set_name)
        assert len(s["thr"]) == 60
        other = EN if set_name.endswith("_th") else TH
        for b in (-3.0, -1.0, 0.0, 0.7, 2.5):
            hyps = calib.decode_texts(s, b)
            real = np.array([other.script.count(h) > 0 for h in hyps])
            assert (real == calib.leak_mask(s, b)).mean() > 0.97
        assert (calib.leak_mask(s, 0.0) == s["base_leak"]).mean() > 0.97
        c = calib.curve(s)
        assert abs(c[calib.ZERO] - calib.leak_rate(s, 0.0)) < 1e-9


def test_run_end_to_end(tmp_path):
    rng = np.random.default_rng(1)
    work = str(tmp_path)
    groups = {"A": ["a", "a_s1", "a_s2"], "B": ["b", "b_s1", "b_s2"]}
    shifts = {"a": 1.5, "a_s1": 0.0, "a_s2": -1.5, "b": 0.5, "b_s1": 0.2, "b_s2": 2.0}
    for l, sh in shifts.items():
        for s in calib.DEV + calib.TEST:
            _fake_dump(os.path.join(work, "dumps", f"B20_{l}", s), s, 40, rng, sh)
        r = os.path.join(work, "results", f"B20_{l}")
        os.makedirs(r)
        for f in ("heldout.json", "en.json"):
            json.dump({"greedy": {"clean": {"slr_u": 0.0}, "snr0": {"slr_u": 0.01 * (sh + 2)}}},
                      open(os.path.join(r, f), "w"))
    res = calib.run(work, "20", groups, workers=2, repeats=5)
    assert res["agreement_b0"] > 0.95
    for l, sh in shifts.items():
        m = res["models"][l]
        assert m["cal"]["dev"] <= m["b0"]["dev"] + 1e-9
    # models shifted towards Latin get a negative b
    assert res["models"]["b_s2"]["b"] < res["models"]["a_s2"]["b"]
    g = res["groups"]["A"]
    assert g["cal"]["sd"] <= g["b0"]["sd"] + 1e-9
    assert set(g["dev_size"]) == set(calib.SIZES)
    assert "synthetic_pick" in g
    text = "\n".join(calib.report(res))
    assert "How small can the dev set be" in text and "MUSAN" in text
    json.dumps(calib._jsonable(res))
