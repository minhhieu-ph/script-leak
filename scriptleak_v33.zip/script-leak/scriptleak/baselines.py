"""Baselines a reviewer will ask for, and the remaining statistics (v32). CPU only.

  lid     run a public spoken-language identifier (SpeechBrain VoxLingua107
          ECAPA, needs `pip install speechbrain`) once over the test sets and keep,
          per utterance, its Thai-vs-English decision. Independent of the ASR model.
  score   for the final models, on the test sets (LOTUSDIS Thai, AMI far-field,
          AMI close-talk, LOTUSDIS Thai+English mixed), compare:
            greedy        the model as it is
            lock          ours: script decided from the CTC mass of the utterance
            lid-mask      script decided by the external language identifier
            oracle-mask   script given by the true spoken language (upper bound;
                          on mixed utterances it bans the English words)
          leak (both ways), CER Thai / WER English, English words kept on the mixed
          set, script fidelity (share of output letters in the spoken script), and
          the accuracy of each script decision. Then the synthetic-vs-real Spearman
          with a bootstrap interval over models and a permutation p-value.

  python -m scriptleak.baselines lid --work $W
  python -m scriptleak.baselines score --work $W
"""

from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import sys
from collections import Counter
from typing import Dict, List, Optional

import numpy as np

from .calib import _synthetic
from .decoding import greedy, hard_mask, utterance_lock
from .dumpio import iter_dump, read_meta
from .normalize import scoring_normalize
from .realstats import DEFAULT_GROUPS, EN, TH, parse_groups
from .retention import latin_words
from .tokenmap import MAJ, MIN, ids_to_text, token_groups

SETS = {"real_lotus_th": "th", "real_ami_en": "en", "real_amiihm_en": "en", "real_lotus_mixed": "mix"}
METHODS = ("greedy", "lock", "lid-mask", "oracle-mask")


# ------------------------------------------------------------------ language identification

_CLF = None


def _lid_init():
    global _CLF
    import torch

    torch.set_num_threads(1)
    try:
        from speechbrain.inference.classifiers import EncoderClassifier
    except ImportError:  # older SpeechBrain
        from speechbrain.pretrained import EncoderClassifier
    _CLF = EncoderClassifier.from_hparams(source="speechbrain/lang-id-voxlingua107-ecapa",
                                          savedir=os.environ.get("LID_CACHE", "pretrained_models/lid_voxlingua107"),
                                          run_opts={"device": "cpu"})


def _lang_index(clf, code: str) -> int:
    lab2ind = clf.hparams.label_encoder.lab2ind
    for lab, i in lab2ind.items():
        if str(lab).split(":")[0].strip().lower() == code:
            return int(i)
    raise KeyError(f"language '{code}' not in the identifier's labels")


def _lid_one(path: str):
    import soundfile as sf
    import torch

    from .audio import resample, to_mono

    try:
        a, sr = sf.read(path, dtype="float32", always_2d=False)
        a = resample(to_mono(a), sr, 16000)
        out = _CLF.classify_batch(torch.from_numpy(np.ascontiguousarray(a)).unsqueeze(0))[0][0]
        th, en = float(out[_lang_index(_CLF, "th")]), float(out[_lang_index(_CLF, "en")])
        return path, th, en
    except Exception as e:  # noqa: BLE001
        return path, None, f"{type(e).__name__}: {e}"


def cmd_lid(args) -> int:
    paths, seen = [], set()
    for s, man in (("real_lotus_th", "lotus.th.jsonl"), ("real_ami_en", "ami.en.jsonl"),
                   ("real_amiihm_en", "amiihm.en.jsonl"), ("real_lotus_mixed", "lotus.mixed.jsonl")):
        p = os.path.join(args.work, "real", man)
        if not os.path.exists(p):
            print(f"   {man}: missing, skipped")
            continue
        for l in open(p, encoding="utf-8"):
            if l.strip():
                a = json.loads(l)["audio_filepath"]
                if a not in seen:
                    seen.add(a)
                    paths.append(a)
    out = os.path.join(args.work, "lid_voxlingua107.jsonl")
    done = set()
    if os.path.exists(out):
        done = {json.loads(l)["audio_filepath"] for l in open(out, encoding="utf-8") if l.strip()}
    todo = [p for p in paths if p not in done]
    try:  # load once here: a failing initializer would make the pool respawn workers forever (v32)
        _lid_init()
    except Exception as e:  # noqa: BLE001
        print(f"!! cannot load the language identifier: {type(e).__name__}: {e}")
        return 1
    print(f"language identification: {len(todo)} of {len(paths)} utterances to do, {args.workers} processes")
    errors = 0
    with mp.get_context("spawn").Pool(max(1, args.workers), initializer=_lid_init) as pool, \
            open(out, "a", encoding="utf-8") as f:
        for k, (p, th, en) in enumerate(pool.imap_unordered(_lid_one, todo, chunksize=8), 1):
            if th is None:
                errors += 1
                if errors <= 5:
                    print(f"!! LID failed on {p}: {en}")
                continue
            f.write(json.dumps({"audio_filepath": p, "th": th, "en": en}) + "\n")
            if k % 2000 == 0:
                print(f"  {k}/{len(todo)}", flush=True)
    print(f"wrote {out} ({errors} failures)")
    return 0 if errors < max(10, len(todo) // 100) else 1


# ------------------------------------------------------------------ scoring

def _load_lid(work: str) -> Dict[str, bool]:
    """audio_filepath -> True if the identifier says English."""
    p = os.path.join(work, "lid_voxlingua107.jsonl")
    if not os.path.exists(p):
        return {}
    out = {}
    for l in open(p, encoding="utf-8"):
        if l.strip():
            r = json.loads(l)
            out[r["audio_filepath"]] = r["en"] > r["th"]
    return out


def _edit(a, b) -> int:
    from .pareto import edit_distance

    return edit_distance(a, b)


def score_dump(path: str, kind: str, lid: Dict[str, bool]) -> Dict:
    meta = read_meta(path)
    vocab, blank = meta["vocab"], int(meta["blank_id"])
    groups = token_groups(vocab, TH, EN, blank_id=blank)
    spoken, other = (EN, TH) if kind == "en" else (TH, EN)
    english = kind == "en"
    acc = {m: Counter() for m in METHODS}
    for rec, lp in iter_dump(path):
        ref = scoring_normalize(str(rec.get("text", "")))
        if kind != "mix" and (other.script.count(ref) or not spoken.script.count(ref)):
            continue
        a = str(rec.get("audio_filepath"))
        says_en = lid.get(a)
        truth_en = english
        pm, pn = np.exp(lp[:, groups == MAJ]).sum(), np.exp(lp[:, groups == MIN]).sum()
        lock_en = pn > pm
        hyps = {"greedy": greedy(lp, groups), "lock": utterance_lock(lp, groups),
                "oracle-mask": hard_mask(lp, groups, MAJ if truth_en else MIN)}
        if says_en is not None:
            hyps["lid-mask"] = hard_mask(lp, groups, MAJ if says_en else MIN)
        ru = ref.split() if english else ref.replace(" ", "")
        rw = Counter(latin_words(ref)) if kind == "mix" else None
        for m, ids in hyps.items():
            hyp = scoring_normalize(ids_to_text(ids, vocab))
            c = acc[m]
            c["n"] += 1
            hu = hyp.split() if english else hyp.replace(" ", "")
            c["err"] += _edit(ru, hu)
            c["ref"] += len(ru)
            o, s = other.script.count(hyp), spoken.script.count(hyp)
            if kind != "mix":
                c["leak"] += o > 0
                c["fid_num"] += s / (o + s) if o + s else 1.0
            else:
                c["kept"] += sum((rw & Counter(latin_words(hyp))).values())
                c["words"] += sum(rw.values())
        if kind != "mix":
            acc["lock"]["dec_ok"] += lock_en == truth_en
            if says_en is not None:
                acc["lid-mask"]["dec_ok"] += says_en == truth_en
    out = {}
    for m, c in acc.items():
        if not c["n"]:
            continue
        r = {"n": c["n"], "err": c["err"] / max(1, c["ref"])}
        if kind != "mix":
            r["leak"] = c["leak"] / c["n"]
            r["fidelity"] = c["fid_num"] / c["n"]
            if m in ("lock", "lid-mask"):
                r["decision_acc"] = c["dec_ok"] / c["n"]
        else:
            r["kept"] = c["kept"] / max(1, c["words"])
        out[m] = r
    return out


def _job(args):
    path, kind, lid = args
    try:
        return path, score_dump(path, kind, lid)
    except Exception as e:  # noqa: BLE001
        return path, f"{type(e).__name__}: {e}"


def spearman_ci(x: np.ndarray, y: np.ndarray, resamples: int = 10000, seed: int = 0) -> Dict:
    rk = lambda v: np.argsort(np.argsort(v, kind="stable"), kind="stable").astype(float)
    rho = lambda a, b: float(np.corrcoef(rk(a), rk(b))[0, 1]) if np.std(rk(a)) and np.std(rk(b)) else 0.0
    rng = np.random.default_rng(seed)
    n = len(x)
    boots = []
    for _ in range(resamples):
        i = rng.integers(0, n, n)
        if len(set(i)) > 2:
            boots.append(rho(x[i], y[i]))
    r0 = rho(x, y)
    perm = np.mean([abs(rho(x, rng.permutation(y))) >= abs(r0) for _ in range(resamples)])
    return {"rho": r0, "ci": (float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5))),
            "p_perm": float(perm), "n": n}


def cmd_score(args) -> int:
    groups = parse_groups(args.groups)
    lid = _load_lid(args.work)
    if not lid:
        print("NOTE: no lid_voxlingua107.jsonl (run 'baselines lid'); the lid-mask column is left out")
    labels = [l for ls in groups.values() for l in ls]
    jobs = []
    for l in labels:
        for s, kind in SETS.items():
            p = os.path.join(args.work, "dumps", f"B{args.b_pct}_{l}", s)
            if os.path.exists(os.path.join(p, "meta.json")):
                jobs.append((p, kind, lid))
    print(f"scoring {len(jobs)} dumps ...", flush=True)
    got = {}
    with mp.get_context("spawn").Pool(max(1, args.workers)) as pool:
        for p, r in pool.imap_unordered(_job, jobs):
            if isinstance(r, str):
                print(f"!! {p}: {r}")
            else:
                got[p] = r
    d = lambda l, s: os.path.join(args.work, "dumps", f"B{args.b_pct}_{l}", s)
    L = ["Test sets, mean over the seeds of each recipe. Leak = share of utterances with a letter of the other script.",
         "fidelity = share of output letters in the spoken script; EN kept = English words of mixed utterances kept in Latin",
         "decision = share of utterances whose script/language decision is right (lock: from the CTC mass; lid: external)"]
    res = {"recipes": {}}
    for g, ls in groups.items():
        L.append(f"\n=== {g} ({', '.join(ls)})")
        L.append(f"  {'method':<12} {'Th>L':>6} {'En>Th':>6} {'sum':>6} {'CER Th':>7} {'WER En':>7} {'fid Th':>7} {'fid En':>7}"
                 f" {'IHM En>Th':>9} {'IHM WER':>8} {'EN kept':>8} {'mix CER':>8} {'decision Th/En':>15}")
        rows = {}
        for m in METHODS:
            vals = []
            for l in ls:
                r = {s: got.get(d(l, s), {}).get(m) for s in SETS}
                if r["real_lotus_th"] is None or r["real_ami_en"] is None:
                    continue
                vals.append(r)
            if not vals:
                continue
            mean = lambda s, k: float(np.mean([v[s][k] for v in vals if v.get(s) and k in v[s]])) \
                if any(v.get(s) and k in v[s] for v in vals) else float("nan")
            row = {"Th>L": mean("real_lotus_th", "leak"), "En>Th": mean("real_ami_en", "leak"),
                   "CER": mean("real_lotus_th", "err"), "WER": mean("real_ami_en", "err"),
                   "fidTh": mean("real_lotus_th", "fidelity"), "fidEn": mean("real_ami_en", "fidelity"),
                   "ihm": mean("real_amiihm_en", "leak"), "ihmWER": mean("real_amiihm_en", "err"),
                   "kept": mean("real_lotus_mixed", "kept"), "mixCER": mean("real_lotus_mixed", "err"),
                   "decTh": mean("real_lotus_th", "decision_acc"), "decEn": mean("real_ami_en", "decision_acc")}
            row["sum"] = row["Th>L"] + row["En>Th"]
            rows[m] = row
            f = lambda v: "     -" if np.isnan(v) else f"{v:6.1%}"
            dec = "" if np.isnan(row["decTh"]) else f"{row['decTh']:.1%}/{row['decEn']:.1%}"
            L.append(f"  {m:<12} {f(row['Th>L'])} {f(row['En>Th'])} {f(row['sum'])} {f(row['CER']):>7} {f(row['WER']):>7}"
                     f" {f(row['fidTh']):>7} {f(row['fidEn']):>7} {f(row['ihm']):>9} {f(row['ihmWER']):>8}"
                     f" {f(row['kept']):>8} {f(row['mixCER']):>8} {dec:>15}")
        res["recipes"][g] = rows
    # synthetic vs real, final models, greedy
    xs, ys, names = [], [], []
    for l in labels:
        syn = _synthetic(args.work, args.b_pct, l)
        r = [got.get(d(l, s), {}).get("greedy") for s in ("real_lotus_th", "real_ami_en")]
        if syn is not None and all(r):
            xs.append(syn)
            ys.append(r[0]["leak"] + r[1]["leak"])
            names.append(l)
    if len(xs) >= 5:
        sp = spearman_ci(np.array(xs), np.array(ys))
        res["spearman"] = sp
        L.append(f"\nMUSAN (synthetic) vs real leak, {sp['n']} final models: Spearman {sp['rho']:+.2f}, "
                 f"95% bootstrap interval [{sp['ci'][0]:+.2f}, {sp['ci'][1]:+.2f}], permutation p = {sp['p_perm']:.2f}")
    print("\n".join(L))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(res, fh, ensure_ascii=False, indent=1)
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("lid", "score"):
        a = sub.add_parser(name)
        a.add_argument("--work", default=os.environ.get("W"))
        a.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
        a.add_argument("--groups", nargs="*", default=DEFAULT_GROUPS)
        a.add_argument("--workers", type=int, default=int(os.environ.get("CALIB_WORKERS", "16")))
        a.add_argument("--out")
    args = p.parse_args(argv)
    if not args.work:
        p.error("--work (or $W) is required")
    return cmd_lid(args) if args.cmd == "lid" else cmd_score(args)


if __name__ == "__main__":
    sys.exit(main())
