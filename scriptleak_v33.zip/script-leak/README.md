# scriptleak v33

Mã nguồn cho nghiên cứu "rò ngôn ngữ thiểu số trong ASR song ngữ nhỏ gọn".
Bản v16 đi hết một vòng thí nghiệm cho đầu CTC: chuẩn bị dữ liệu, huấn luyện,
lưu xác suất theo khung, phân tích nguyên nhân, giải mã và so sánh phương pháp.

## Đã kiểm thử đến đâu

| Phần | Mô-đun | Trạng thái |
|---|---|---|
| Lọc dạng nói, trộn, chia tập | `audit`, `mix`, `split` | Có kiểm thử tự động |
| Chỉ số rò, CER, WER | `metrics`, `evaluate` | Có kiểm thử tự động |
| Giải mã và baseline | `decoding`, `sweep` | Có kiểm thử trên xác suất tổng hợp |
| Phân tích theo khung | `analysis` | Có kiểm thử trên xác suất tổng hợp |
| Thêm nhiễu | `noise` | Phần trộn tín hiệu có kiểm thử; phần đọc ghi tệp chưa chạy |
| Chuyển định dạng | `prepare` | LibriSpeech, AISHELL-1, TSV có kiểm thử cấu trúc thư mục; Hugging Face chưa chạy |
| Mọi thứ dùng NeMo | `nemo_tools/*` | **Chưa chạy lần nào**, vì nơi viết mã không có NeMo và GPU |

`python -m pytest -q` chạy 71 bài kiểm thử, chỉ cần numpy và scipy.

Vì phần NeMo chưa được chạy, bước đầu tiên trên máy huấn luyện là:

```bash
python -m scriptleak.nemo_tools.check_env
```

Lệnh này kiểm tra từng điểm của NeMo mà mã dựa vào. Nếu có dòng `FAIL`, gửi
lại toàn bộ kết quả để sửa trước khi huấn luyện.

## Cài đặt môi trường

```bash
bash scripts/setup_env.sh
```

Script tạo môi trường conda `scriptleak` (Python 3.12), cài PyTorch, NeMo và các
gói còn lại, tải kho NeMo về `third_party/NeMo` để lấy tệp cấu hình, rồi chạy
bộ kiểm thử và `check_env`. Script chưa được chạy thử vì nơi viết mã không có
mạng.

| Biến | Mặc định | Khi nào đổi |
|---|---|---|
| `TORCH_INDEX` | `https://download.pytorch.org/whl/cu130` | Khi PyTorch không thấy GPU. Chọn bản khớp driver theo trang cài đặt của PyTorch |
| `SKIP_TORCH=1` | tắt | Khi môi trường đã có PyTorch chạy được với GPU |
| `SKIP_CONDA=1` | tắt | Khi tự quản lý môi trường Python |
| `ENV_NAME` | `scriptleak` | Tên môi trường conda |

NeMo hiện là bản 3.0 (kho đổi tên thành NeMo Speech), yêu cầu Python 3.12 và
PyTorch 2.7 trở lên. Mã trong `nemo_tools` viết theo giao diện mình biết từ các
bản trước, nên kết quả `check_env` ở cuối script là thứ cần xem đầu tiên. Bước 4
của script in ra các tệp cấu hình FastConformer tìm thấy: dùng một tệp trong đó
làm `--base-config`.

## Tải dữ liệu

```bash
bash scripts/download_data.sh /data/scriptleak
```

| Bộ | Dung lượng tải | Cách tải |
|---|---|---|
| LibriSpeech train-clean-100, dev-clean, test-clean | khoảng 7 GB | Script, từ OpenSLR |
| MUSAN | khoảng 11 GB | Script, từ OpenSLR |
| Thai Dialect Corpus, 4 bộ trên Hugging Face | giọng trung tâm khoảng 7,5 GB | Lệnh `prepare hf` ở bước 1 |
| AISHELL-1 | khoảng 15 GB | `WITH_AISHELL=1`, cho cặp Quan Thoại–Anh |
| GigaSpeech 2, tập test tiếng Thái | chưa rõ | Phải đăng nhập Hugging Face và chấp nhận điều khoản; script in hướng dẫn |

Âm thanh tiếng Thái được ghi lại thành wav 16 kHz, khoảng 115 MB mỗi giờ, tức
khoảng 80 GB cho 700 giờ.

## Chạy nhanh bằng script theo giai đoạn

`scripts/killtest.sh` gói các bước bên dưới thành chín giai đoạn. Chạy lần lượt:

```bash
export D=/data/scriptleak
TEXT_COL=<tên cột> bash scripts/killtest.sh prepare
bash scripts/killtest.sh audit        # dừng lại đọc số giờ tiếng Thái sạch
bash scripts/killtest.sh split
bash scripts/killtest.sh mix
bash scripts/killtest.sh tokenizer
BASE_CONFIG=<tệp yaml> bash scripts/killtest.sh train05
BASE_CONFIG=<tệp yaml> bash scripts/killtest.sh train20
bash scripts/killtest.sh dump
bash scripts/killtest.sh results
```

Mặc định dùng 8 GPU, batch 32 mỗi GPU, 10 epoch, 300 giờ tiếng Thái. Đổi bằng
các biến `GPUS`, `BATCH`, `EPOCHS`, `TH_HOURS`. `INIT=none` để không khởi tạo từ
checkpoint tiếng Anh. Script này chưa được chạy thử.

## Phép thử hai tuần, từng bước

Ký hiệu: `$D` là thư mục dữ liệu, `$NEMO` là `third_party/NeMo`.

### 1. Chuyển về manifest thô

```bash
python -m scriptleak.prepare librispeech --root $D/LibriSpeech \
    --subsets train-clean-100 --out en_train.raw.jsonl
python -m scriptleak.prepare librispeech --root $D/LibriSpeech \
    --subsets dev-clean --out en_dev.raw.jsonl
python -m scriptleak.prepare librispeech --root $D/LibriSpeech \
    --subsets test-clean --out en_test.raw.jsonl

# Xem tên cột trước, rồi thay TEXT_COL bằng cột chứa câu đúng như được nói
python -m scriptleak.prepare hf-columns --dataset CMKL/Porjai-Thai-voice-dataset-korat
for name in central khummuang korat pattani; do
  python -m scriptleak.prepare hf --dataset CMKL/Porjai-Thai-voice-dataset-$name \
      --split train --text-col TEXT_COL \
      --audio-out $D/porjai/$name/wav --out th_$name.raw.jsonl
done
```

Ba bộ phương ngữ có hai cột văn bản: câu phương ngữ và bản dịch sang tiếng Thái
chuẩn. Người đọc nói câu phương ngữ, nên phải lấy cột đó. Mỗi bộ chỉ có một
split tên `train`.

### 2. Kiểm tra và lọc về dạng nói

```bash
python -m scriptleak.audit --manifest th_central.raw.jsonl --lang th \
    --out-manifest th_central.clean.jsonl --report th_central.audit.json
python -m scriptleak.audit --manifest en_train.raw.jsonl --lang en --out-manifest en_train.clean.jsonl
python -m scriptleak.audit --manifest en_dev.raw.jsonl   --lang en --out-manifest en_dev.clean.jsonl
python -m scriptleak.audit --manifest en_test.raw.jsonl  --lang en --out-manifest en_test.clean.jsonl
for name in khummuang korat pattani; do
  python -m scriptleak.audit --manifest th_$name.raw.jsonl --lang th \
      --out-manifest th_$name.clean.jsonl --set stratum=$name
done
```

Với tiếng Thái, khoảng trắng giữa các từ bị xóa. Lý do: bộ dữ liệu tách từ
không nhất quán, cùng một câu có chỗ viết liền có chỗ viết rời.

**Điểm dừng:** xem số giờ sạch của tiếng Thái trong báo cáo. Cần ít nhất 320
giờ (300 huấn luyện, 20 cho dev và test).

### 3. Chia tập và tạo tầng độ khó

```bash
python -m scriptleak.split --manifest th_central.clean.jsonl --dev-hours 3 --test-hours 10 \
    --out-prefix th_central
python -m scriptleak.noise --manifest th_central.test.jsonl --noise-dir $D/musan/noise \
    --snrs 10 5 0 --out-dir $D/th_test_noisy --out-manifest th_test.strata.jsonl
cat th_korat.clean.jsonl th_khummuang.clean.jsonl th_pattani.clean.jsonl >> th_test.strata.jsonl
```

Nếu `hf-columns` cho thấy có cột mã người nói, thêm cột đó vào `--copy-cols` ở
bước 1 và dùng `--speaker-field` ở đây để train và test không chung người nói.

### 4. Trộn dữ liệu huấn luyện

```bash
python -m scriptleak.mix --majority th_central.train.jsonl --minority en_train.clean.jsonl \
    --majority-hours 300 --minority-fraction 0.05 --out train_th300_en05.jsonl
python -m scriptleak.mix --majority th_central.train.jsonl --minority en_train.clean.jsonl \
    --majority-hours 300 --minority-fraction 0.20 --out train_th300_en20.jsonl
```

### 5. Bộ từ vựng và huấn luyện

```bash
python -m scriptleak.nemo_tools.build_tokenizer --manifest th_central.train.jsonl \
    --out-dir tokenizers/th_bpe1024 --vocab-size 1024
python -m scriptleak.nemo_tools.build_tokenizer --manifest en_train.clean.jsonl \
    --out-dir tokenizers/en_bpe256 --vocab-size 256

python -m scriptleak.nemo_tools.train \
    --base-config $NEMO/examples/asr/conf/fastconformer/hybrid_cache_aware_streaming/fastconformer_hybrid_transducer_ctc_bpe_streaming.yaml \
    --train-manifest train_th300_en05.jsonl \
    --val-manifest th_central.dev.jsonl en_dev.clean.jsonl \
    --tokenizer th=tokenizers/th_bpe1024 en=tokenizers/en_bpe256 \
    --init-pretrained stt_en_fastconformer_hybrid_large_streaming_multi \
    --exp-dir exp/th300_en05 --max-epochs 10 --batch-size 64 --devices 1
```

Lặp lại với `train_th300_en20.jsonl` và `--exp-dir exp/th300_en20`.

Ghi chú:
- Đường dẫn tệp cấu hình và tên checkpoint khởi tạo lấy theo trí nhớ về kho
  NeMo trước bản 3.0. Dùng danh sách tệp mà `setup_env.sh` in ra để chọn lại.
- Khởi tạo encoder từ tiếng Anh có thể tự gây thiên lệch về tiếng Anh. Khi làm
  thí nghiệm chính cần thêm một cấu hình đối chứng không khởi tạo từ tiếng Anh.
- `--batch-size 64` là mức thận trọng. Tăng dần cho tới khi gần đầy bộ nhớ GPU.

### 6. Lưu xác suất theo khung

```bash
python -m scriptleak.nemo_tools.dump_logprobs --model exp/th300_en05/final.nemo \
    --manifest th_test.strata.jsonl --out dumps/th300_en05/th_test --transducer
python -m scriptleak.nemo_tools.dump_logprobs --model exp/th300_en05/final.nemo \
    --manifest en_test.clean.jsonl --out dumps/th300_en05/en_test --transducer
```

### 7. Đọc kết quả

```bash
# Có rò không, và có tăng theo độ khó không
python -m scriptleak.sweep --dump dumps/th300_en05/th_test --majority th --minority en \
    --spoken th --group-by stratum --methods greedy --out kill_greedy.json

# Vì sao rò: kiểm định giả thuyết chia nhỏ xác suất
python -m scriptleak.analysis --dump dumps/th300_en05/th_test --majority th --minority en \
    --group-by stratum --out kill_frames.json

# Các phương pháp chặn rò và cái giá với tiếng Anh
python -m scriptleak.sweep --dump dumps/th300_en05/th_test --majority th --minority en \
    --spoken th --group-by stratum --out sweep_th.json
python -m scriptleak.sweep --dump dumps/th300_en05/en_test --majority th --minority en \
    --spoken en --out sweep_en.json
```

Đầu transducer: chấm bằng `evaluate` với `--hyp-field pred_transducer` trên
tệp `utts.jsonl` trong thư mục dump.

### Ngưỡng quyết định

| Kết quả | Quyết định |
|---|---|
| SLR-u từ 0,5% trở lên ở tầng khó nhất và gấp ít nhất 2 lần tầng `clean` | Đi tiếp |
| Thêm vào đó, dòng H1 trong `analysis` báo từ 50% trở lên | Giải mã gộp theo hệ chữ là phương pháp chính |
| Có rò nhưng dòng H1 dưới 50% | Chuyển trọng tâm sang đầu phụ dự đoán hệ chữ và khâu dữ liệu |
| `lock` cho SLR-u gần 0 và `lock:k=6` cũng vậy | Cách đơn giản đã đủ, đóng góp phương pháp mỏng |
| SLR-u dưới 0,1% ở mọi tầng | Thử tăng tiếng Anh lên 50%, giảm tiếng Thái còn 100 giờ, rồi mới kết luận |

## Các phương pháp giải mã

| Tên trong `--methods` | Ý nghĩa |
|---|---|
| `greedy` | Mô hình nguyên trạng |
| `mask` | Cấm hẳn ngôn ngữ thiểu số |
| `bias:b=4` | Trừ một hằng số vào điểm của token thiểu số |
| `lock` | Quyết định hệ chữ một lần cho cả câu (không streaming) |
| `lock:k=25` | Quyết định từ 25 khung đầu, phần trước đó không khóa |
| `marg` | Đề xuất, dạng không nhớ: hệ chữ có tổng xác suất lớn hơn thắng ở mỗi khung |
| `marg:tau=1,rho=0.9` | Đề xuất, có quán tính: tích lũy bằng chứng, chỉ đổi hệ chữ khi vượt ngưỡng |

## Chưa có trong v16

- Giải mã gộp theo hệ chữ cho đầu TDT/transducer (hiện chỉ có cho CTC).
- Đầu phụ dự đoán hệ chữ lúc huấn luyện.
- Baseline nhận diện ngôn ngữ bằng mô hình ngoài và trọng số loss theo hệ chữ.
- Tầng "câu rất ngắn".
- Cặp Quan Thoại–Anh: bộ chuyển AISHELL-1 đã có, chưa có hướng dẫn chạy.

## Giai đoạn A (v13): thăm dò trên hai mô hình đã huấn luyện

Không cần huấn luyện. Một lệnh tạo các tầng test mới, cho hai mô hình đọc và in bốn bảng:

```bash
bash scripts/killtest.sh probeA 2>&1 | tee probeA.log
```

| Bảng | Câu hỏi | Mô-đun |
|---|---|---|
| A1 | Kiểu méo nào làm tiếng Thái bị rò (nhiễu trắng, vang, dải điện thoại, cắt đỉnh, âm lượng nhỏ) | `scriptleak.probes`, `scriptleak.sweep` |
| A2 | Không có tiếng nói thì mô hình viết gì | `scriptleak.nonspeech` |
| A3 | Tiếng Anh trộn nhiễu có bị viết thành chữ Thái không | `scriptleak.noise`, `scriptleak.sweep` |
| A4 | Tách được đoạn Latin bị rò khỏi đoạn tiếng Anh thật không, và dùng làm bộ giải mã thì ra sao | `scriptleak.spans`, `scriptleak.ngram` |

Kết quả gộp ở `$D/work/probeA_summary.txt`. Phần tạo âm thanh và phần dump bỏ qua
những gì đã có, nên chạy lại lệnh sau khi bị ngắt là an toàn. `PROBE_UTTS` (mặc định
2000) là số câu sạch được làm méo.

Ngưỡng của A4 được chỉnh trên nửa số câu tiếng Anh và mọi con số về tiếng Anh được
báo trên nửa còn lại.

## Giai đoạn B (v14): thí nghiệm nhân quả

Mọi lần chạy xuất phát từ tập trộn 20% tiếng Anh (`B_PCT`), 50 epoch (`B_EPOCHS`),
lưu thêm `epochNNN.nemo` mỗi 10 epoch (`SAVE_EVERY`) để vẽ đường rò theo quá trình huấn luyện.

```bash
bash scripts/killtest.sh noisefloor            # mức nhiễu nền của hai khối, vài phút
bash scripts/killtest.sh prepB                 # bản nhiễu của tập huấn luyện + tập test nhiễu giữ riêng
bash scripts/killtest.sh trainB both           # nhiễu ở cả hai khối
bash scripts/killtest.sh trainB noinit         # dữ liệu sạch, encoder không khởi tạo từ tiếng Anh
bash scripts/killtest.sh trainB en             # chỉ khối tiếng Anh có nhiễu
bash scripts/killtest.sh trainB th             # chỉ khối tiếng Thái có nhiễu
bash scripts/killtest.sh evalB base both noinit   # bảng so sánh; base = mô hình sạch đã có
```

- Tệp nhiễu được chia cố định 80/20 theo tên tệp (`noise.noise_split`). Huấn luyện chỉ dùng
  phần 80%, và mọi con số về nhiễu MUSAN ở giai đoạn B chỉ tính trên phần 20% còn lại.
- Nhiễu trắng, cắt đỉnh, vang (các tầng của `probeA`) không bao giờ có trong huấn luyện,
  nên là phép thử "kiểu méo chưa từng thấy".
- `evalB` bỏ qua phần dump đã có và in lại toàn bộ bảng so sánh của mọi mô hình đã đánh giá.
  Kết quả ở `$D/work/phaseB_summary.txt`.
- Ở bảng "leakage during training", cột ALL của dòng `final` tính cả phương ngữ nên không
  so được với các dòng `epochNNN`; hãy so cột `clean` và các cột `snr`.

### v15: tên theo tỷ lệ tiếng Anh, một lệnh cho cả đêm

Mọi tên của giai đoạn B mang tỷ lệ tiếng Anh (`B_PCT`): danh sách `B05_aug-both.jsonl`,
mô hình `exp/B05_both`, kết quả `results/B05_both`, tóm tắt `phaseB_en05_summary.txt`.
Hai tỷ lệ không còn ghi đè lên nhau.

```bash
B_PCT=05 bash scripts/killtest.sh nightB                  # prepB + both + noinit + evalB
B_PCT=05 bash scripts/killtest.sh nightB en th            # các lần chạy khác
```

`trainB` bỏ qua mô hình đã có `final.nemo`, nên chạy lại `nightB` sau khi bị ngắt là an toàn.
Mô hình chạy bằng v14 (thư mục `exp/B_both`) dùng được với v15 nếu đổi tên thành `exp/B20_both`.

### v16: tỷ lệ nhiễu, hạt giống, đo SNR không bị đoạn đệm đánh lừa

Ba biến môi trường đổi tên mô hình, nên các lần chạy không ghi đè lên nhau:

| Biến | Mặc định | Ví dụ | Tên thư mục |
|---|---|---|---|
| `B_PCT` | 20 | 05 | `exp/B05_...` |
| `AUG_PROB` | 0.5 | 0.1 | `exp/B20_p10_th` |
| `SEED` | 0 | 1 | `exp/B20_both_s1` |

Với mặc định, tên giữ nguyên như v15 (`B20_both`, `B20_en`...), nên các mô hình đã có dùng tiếp được.

```bash
AUG_PROB=0.1 bash scripts/killtest.sh nightB th both    # 10% câu của khối được chọn có nhiễu
SEED=1       bash scripts/killtest.sh nightB both en th clean   # lặp lại với hạt giống khác
```

- `clean` là một loại mô hình mới: huấn luyện lại mô hình sạch (dùng với `SEED` để lặp lại mô hình gốc).
- Âm thanh nhiễu của `AUG_PROB` nhỏ là tập con của `AUG_PROB` lớn (cùng tệp nhiễu, cùng SNR), nên `prepB` với 0.1 gần như không tạo thêm tệp nào.
- Bảng tóm tắt `phaseB_en<pct>_summary.txt` liệt kê mọi mô hình đã đánh giá của tỷ lệ tiếng Anh đó.
- `noisefloor` có thêm tỷ lệ khung im lặng tuyệt đối (đoạn đệm số 0) và SNR thô chỉ tính trên khung không im lặng.

## v17: tập test có tiếng ồn thật

Mọi tiếng ồn ở giai đoạn A và B đều là nhiễu trộn nhân tạo (MUSAN, nhiễu trắng).
v17 chấm các mô hình đã huấn luyện trên hai bộ tiếng Thái công khai thu trong điều kiện thật:

| Bộ | Nội dung | Tải |
|---|---|---|
| LOTUSDIS test (`nectec/LOTUSDIS`, CC-BY-SA 4.0) | Họp 3 người, hội thoại tự nhiên; bản trên Hugging Face có 5 micro (bt10m, bt3m, con123, jbl, lav123) | Khoảng 1,6 GB, chỉ phần test |
| GigaSpeech 2 test tiếng Thái (`speechcolab/gigaspeech2`) | YouTube, người gán nhãn chuyên nghiệp | Bị khoá: phải chấp nhận điều khoản trên trang Hugging Face rồi `huggingface-cli login` |

Câu tham chiếu được tách làm hai nhóm:
- **Chỉ tiếng Thái** (`*.th.jsonl`): lọc đúng như tập test Porjai, chấm tỷ lệ rò và CER theo từng micro.
- **Thái xen từ tiếng Anh viết bằng chữ Latin** (`*.mixed.jsonl`): chấm bằng `scriptleak.retention`,
  xem mô hình còn giữ được tên riêng và từ mượn hay không (recall từ Latin, tỷ lệ câu có chữ Latin, CER).

LOTUSDIS mặc định giữ 35% số đoạn (`LOTUS_FRAC`), và giữ cùng những đoạn đó ở cả 5 micro để so sánh cặp.

```bash
bash scripts/killtest.sh realprep   # chỉ CPU và mạng; chạy được khi GPU đang huấn luyện
bash scripts/killtest.sh realB      # cần GPU; mỗi mô hình chạy trên một GPU
```

`realprep` cuối cùng in bảng SNR của các khối huấn luyện và của từng micro, để đặt cạnh tỷ lệ rò.
`realB` tự tìm mọi mô hình có `final.nemo` của `B_PCT` (mặc định bỏ `noinit`) và từ chối chạy khi
GPU đang có tiến trình khác (`REAL_FORCE=1` để bỏ qua). Kết quả nằm ở `$W/real_en${B_PCT}_summary.txt`.

| Biến | Mặc định | Ý nghĩa |
|---|---|---|
| `LOTUS_FRAC` | 0.35 | Tỷ lệ đoạn LOTUSDIS giữ lại |
| `REAL_MODELS` | mọi mô hình | Ví dụ `"base both p10_th"` |
| `REAL_SKIP` | `noinit` | Biểu thức chính quy các nhãn bỏ qua |
| `REAL_GPUS` | `GPUS` | Số GPU dùng để dump |
| `REAL_BATCH` | 16 | Số câu mỗi batch khi dump (câu hội thoại dài hơn câu đọc) |

## v19: kiểm chứng các giả thuyết chưa kết luận được

Ba nhóm thí nghiệm cho các giả thuyết mà giai đoạn A chưa đủ căn cứ (xem bảng giả thuyết trong đề cương).

**`probeC`: tiếng xì xào, nhạc, người nói nhỏ, và các ca rò còn sót** (không huấn luyện)

| Tầng | Nội dung |
|---|---|
| `noise10`, `noise0` | Nhiễu MUSAN (phần giữ lại cho test) ở SNR 10 và 0 dB |
| `soft10`, `soft0` | Cùng đoạn nhiễu đó, giữ ở mức của SNR 20 dB, còn tiếng nói nhỏ đi 10 hoặc 20 dB. Cùng SNR với `noise10`/`noise0` nhưng tổng âm lượng thấp hơn 10–20 dB: tách "SNR thấp" khỏi "âm lượng nhỏ" |
| `babth10`, `babth0` | Xì xào của 4 người nói tiếng Thái khác (câu test khác nội dung) |
| `babmx10`, `babmx0` | Xì xào của 4 người lấy từ MUSAN speech, nhiều thứ tiếng, phần lớn tiếng Anh |
| `music10`, `music0` | Nhạc MUSAN |
| `noise_only`, `babth_only`, `babth_far`, `babmx_only`, `music_only` | Không có người nói chính, 5 giây, câu tham chiếu rỗng |

Ra chữ Latin trên xì xào tiếng Thái là sai chắc chắn. Trên xì xào MUSAN thì có thể là chép đúng
tiếng Anh nghe được, nên được báo cáo riêng. Mọi tầng đều chấm cả hai đầu (CTC và transducer).

Phần C3 lấy lại tập test giữ riêng với cả hai đầu cho `RESID_MODELS` (mặc định `base both p10_both`):
bảng chéo xem hai đầu có rò trên cùng câu không, và phân tích khung (H1) của các ca rò còn sót ở mô hình đã cân bằng.

Âm thanh được tạo trước bằng CPU, nên chạy được khi GPU đang bận; phần dùng GPU sẽ tự dừng và chờ lần chạy sau.

**`adaptB KIND` / `nightC`: G2b, adapt hai giai đoạn**

| KIND | Bắt đầu từ | Dữ liệu adapt | Giữ lại |
|---|---|---|---|
| `adrm_all` | Mô hình đang rò (`th300_en${B_PCT}`) | Nhiễu cân bằng (`aug-both`) | Cả mô hình |
| `adrm_enc` | như trên | như trên | Chỉ encoder |
| `adim_all` | Mô hình đã cân bằng (`both`) | Hỗn hợp gốc, không thêm nhiễu | Cả mô hình |
| `adim_enc` | như trên | như trên | Chỉ encoder |

Mặc định 5 epoch (`ADAPT_EPOCHS`), tốc độ học cố định `ADAPT_LR=1e-4` không warm-up (warm-up của cấu hình
gốc dài hơn cả lần adapt). Mỗi epoch lưu một bản, nên `evalB` vẽ được đường rò theo từng epoch adapt.
Dòng `[train] optimizer in the base config` trong log cho biết cấu hình gốc dùng tốc độ học bao nhiêu.

```bash
bash scripts/killtest.sh probeC          # lần đầu: tạo âm thanh (CPU), rồi dừng nếu GPU bận
bash scripts/killtest.sh realB && bash scripts/killtest.sh probeC && bash scripts/killtest.sh nightC
```

`FORCE=1` bỏ qua kiểm tra GPU bận (thay cho `REAL_FORCE`). `MODELS` và `SKIP` chọn mô hình cho `realB` và `probeC`.

## v20: đo cả hai chiều, nhiều hạt giống, một lệnh cho mọi việc còn lại

Lượt chạy lại `clean_s1` cho thấy chiều rò của mô hình sạch không cố định: rò sang chữ Latin tăng tới 48,7%
ở epoch 40, rồi epoch 50 lại lật sang viết tiếng Anh có nhiễu thành chữ Thái. Vì vậy v20:

- **Đo cả hai chiều trong đường theo epoch.** `evalB` giờ chấm mỗi bản lưu giữa chừng trên cả tập Thái
  (Thái → chữ Latin) lẫn tập Anh (Anh → chữ Thái).
- **Bảng hai chiều** (`scriptleak.twoway`): mỗi ô là "Thái → Latin / Anh → Thái", thêm cột tổng ở tầng khó nhất.
- **Lưu mỗi 5 epoch** (`SAVE_EVERY=5`, trước là 10).
- **`evalB` chạy song song trên mọi GPU** thay vì chỉ GPU 0, và bỏ qua phần đã chấm.
- **`marathon`**: một lệnh chạy hết các việc còn lại, mỗi bước một subshell nên bước lỗi không chặn bước sau:
  `realB` → `probeC` → `nightC` → đường hai chiều cho `clean_s1`, `both_s1` → `clean` hạt giống 0 →
  `clean`, `both` hạt giống 2 → `realB`, `probeC` cho các mô hình mới. Khoảng 20 giờ; log từng bước ở `$W/logs/marathon_*.log`.

```bash
export D=... W=... BASE_CONFIG=...
bash scripts/killtest.sh marathon 2>&1 | tee marathon.log
```

Lưu ý khi so sánh: mô hình `base` (`th300_en20`) được huấn luyện 40 epoch, các mô hình giai đoạn B là 50 epoch.
So sánh công bằng là giữa `clean` (50 epoch, nhiều hạt giống) và các mô hình có thêm nhiễu.

## v21: tiếng Anh ồn thật (AMI) và phân tích rò trên âm thanh thật

- **AMI** (`edinburghcstr/ami`, CC-BY 4.0): các cuộc họp tiếng Anh, kênh một micro đặt xa (SDM), phần eval.
  `realprep` tải phần này (vài GB), lọc về dạng nói như LibriSpeech và giữ 50% số đoạn (`AMI_FRAC`).
  Đây là chiều còn thiếu: trên âm thanh thật, tiếng Anh có bị viết thành chữ Thái không.
- **GigaSpeech 2 giờ chỉ chạy khi đặt `WITH_GS2=1`** (bộ này bị khoá), nên `realprep` không còn báo lỗi 403.
- **`scriptleak.realdiag`**: rò trên một tập thật, tách theo micro (kèm tỷ lệ ra rỗng và tỷ lệ rò trên các câu có ra chữ),
  theo độ khó, theo độ dài câu, và theo kiểu rò (chỉ chữ kia / lẫn trong chữ đúng). Độ khó của một câu được đo bằng lỗi
  của **một mô hình tham chiếu** trên cùng câu đó (`th` cho tiếng Thái, `en` cho tiếng Anh), không phải bằng lỗi của chính
  mô hình đang chấm: câu đã rò thì lỗi tự động cao, nên tự chấm độ khó sẽ giấu bớt rò.
- `realB` in thêm bảng hai chiều trên âm thanh thật: LOTUSDIS Thái → chữ Latin / AMI Anh → chữ Thái.

Chạy sau khi `marathon` xong (chỉ dump phần còn thiếu, LOTUSDIS đã có thì bỏ qua):

```bash
bash scripts/killtest.sh realprep 2>&1 | tee realprep_v21.log && \
bash scripts/killtest.sh realB 2>&1 | tee realB_v21.log
```

## v22: AMI tự dò cấu trúc kho Hugging Face (tar hoặc parquet)

## v23: vang phòng thật, thêm hạt giống cho `th`, adapt dài hơn

- **`getrir`**: tải bộ đáp ứng xung phòng của OpenSLR 28 (`rirs_noises.zip`, khoảng 1,3 GB, Apache 2.0) vào `$D/RIRS_NOISES`.
  Đặt `OPENSLR=<mirror>` nếu trang chính chậm, như lúc tải LibriSpeech.
- **`prepR`** / kiểu mô hình **`rir`**: với `AUG_PROB` (0,5) số câu của **cả hai** khối: thêm vang phòng (RIR mô phỏng
  và thật, phần huấn luyện), rồi với 70% số đó thêm nhiễu hoặc nhạc MUSAN (phần huấn luyện) ở SNR 0–20 dB.
  Vang được căn theo đường truyền thẳng nên lời không bị lệch thời gian. Câu hỏi: phủ điều kiện gần thật hơn thì
  cân bằng có thắng trên LOTUSDIS và AMI, và có hết dao động theo hạt giống không.
- **Adapt dài hơn:** `ADAPT_EPOCHS=15` đổi tên mô hình thành `..._e15` (không đè bản 5 epoch), lưu mỗi 3 epoch.
- **`marathon2`**: `getrir` → `nightB rir` → `th` hạt giống 1 và 2 → adapt 15 epoch (`adrm_enc`, `adrm_all`)
  → `realB` + `probeC` cho các mô hình mới. Khoảng 19 giờ.

```bash
bash scripts/killtest.sh marathon2 2>&1 | tee marathon2.log
```

## v24: seed có rò trên cùng câu không, khoảng tin cậy, chọn model bằng dev thật

- `seedC` (chỉ CPU): `scriptleak.seedvar` xem các seed có rò trên cùng câu, cùng người nói,
  cùng loại câu (chỉ từ đệm / theo độ dài) và cùng đoạn ghi ở các mic khác nhau không;
  `scriptleak.bootstrap` cho khoảng tin cậy 95% (bootstrap theo người nói / theo cuộc họp).
- `realdev` (CPU + mạng): tập validation của LOTUSDIS (~1,3 GB) và AMI dev, dùng làm dev thật.
- `selectC` (GPU): lấy trung bình trọng số của final + 2 checkpoint cuối (`nemo_tools/avg_ckpt.py`),
  dump mọi ứng viên (final, trung bình, checkpoint từ epoch 30) trên dev và test, rồi
  `scriptleak.selection` xem rò trên dev có dự đoán được rò trên test không và chọn theo dev có giảm rò không.

## v25: hiệu chỉnh độ lệch chữ viết trên dev thật

- `calibC` (chỉ CPU, dùng lại dump của `selectC`): `scriptleak.calib` cộng một hằng số b vào điểm
  của mọi token Latin. Với greedy CTC, mỗi câu chỉ đổi trạng thái rò ở đúng một ngưỡng của b,
  nên tỉ lệ rò tính chính xác cho mọi b sau một lượt đọc dump. b chọn trên dev (tổng hai chiều),
  áp nguyên lên test. Báo thêm: b chung cho mọi model, CER/WER phải trả, dev cần bao nhiêu câu,
  chọn seed bằng MUSAN thay cho dev thật, tỉ lệ chữ sai hệ so với tỉ lệ câu có rò theo độ dài.

## v26: mỗi cách sửa phải trả giá bao nhiêu

- `ihmC` (GPU): AMI eval qua micro đeo đầu (IHM, thu gần, cùng các cuộc họp với bản thu xa) và tập
  LOTUSDIS trộn Thái–Anh nếu còn thiếu dump; dump bằng 12 model final.
- `paretoC` (chỉ CPU): `scriptleak.pareto` chạy mọi cách sửa (b chọn trên dev theo ba luật: ít rò nhất,
  ít rò nhất mà CER/WER dev không tăng quá PARETO_TOL, ít lỗi nhất; khóa chữ viết theo câu; giải mã
  gộp xác suất theo chữ viết) và báo rò hai chiều, CER Thái, WER Anh, tỉ lệ giữ từ tiếng Anh trong
  câu trộn, rò/WER trên AMI thu gần, đường đánh đổi theo b và rò/CER theo từng micro.

## v27: giải pháp đầy đủ, offline và streaming thật

- `comboC` (chỉ CPU): `scriptleak.combo` so seed ngẫu nhiên / chọn seed bằng dev, giải mã greedy / khóa
  chữ viết theo câu (lock khi giải mã lại ở cuối câu), cho cả dump offline và dump streaming.
- `streamC` (GPU): `nemo_tools/stream_dump.py` chạy model theo từng khối với cache (cache-aware
  streaming, như ví dụ của NeMo) và ghi log-prob CTC theo khung. Trước tiên tự kiểm tra trên 32 câu:
  streaming so với offline, và chạy theo lô so với từng câu một (lệch thì tự chuyển về lô 1).

## v28: giải pháp với một lần huấn luyện, kèm khoảng tin cậy

- `singleC` (chỉ CPU, dùng dump của `selectC`): `scriptleak.singlerun` chọn checkpoint ngay trong
  từng lần huấn luyện (final, trung bình trọng số, epoch 30–45) bằng rò trên dev khi đã khóa chữ viết,
  rồi đo trên test. Đặt cạnh bản ba lần huấn luyện của v27. Khoảng tin cậy 95% bằng bootstrap theo
  người nói/cuộc họp, ghép cặp giữa các phương pháp nên phần chênh cũng có khoảng riêng.

## v29: chọn checkpoint có giữ độ chính xác

- `singleC` nay báo thêm CER (LOTUSDIS) và WER (AMI) cho mỗi lựa chọn, và một luật chọn có bảo vệ:
  chỉ xét checkpoint có CER/WER trên dev không cao hơn model final quá SEL_TOL (mặc định 1 điểm).

## v30: dùng dev thật để chọn checkpoint và dừng sớm ngay trong lúc huấn luyện

- `nemo_tools/devmon.py`: sau mỗi epoch, đo rò (greedy và khi khóa chữ viết) và CER/WER trên 1000 câu
  cố định của mỗi tập dev thật (LOTUSDIS validation, AMI dev), ghi `devmon.jsonl`, lưu `mon_epochNNN.nemo`.
- `scriptleak.esmon`: chọn checkpoint theo bốn luật (final, ít rò nhất, ít rò nhất có bảo vệ độ chính xác,
  dừng sớm trực tuyến với patience 3/5/10), xóa checkpoint không được chọn, báo cáo trên test.
- `esB [KIND...]` (GPU, dài): huấn luyện lại `clean` và `rir` × 3 seed có bộ đo này (nhãn `*_es`),
  rồi dump test cho các checkpoint được chọn và chạy `esC` (báo cáo, chỉ CPU).

## v31: sửa lỗi treo của bộ đo dev (v30)

- Trong v30, khi chỉ tiến trình chính chạy encoder để đo dev, NeMo gọi `all_reduce` độ dài đầu vào trên mọi
  tiến trình (`sync_max_audio_length`) trong lúc các tiến trình khác đứng ở barrier, nên cả 8 GPU chờ nhau mãi.
  v31 tắt đồng bộ đó trong lúc đo và chỉ dùng câu dev dài tối đa 20 s.

## v32: baseline cho phản biện (chỉ CPU, chạy song song với train)

- `baseC`: bộ nhận dạng ngôn ngữ công khai (SpeechBrain VoxLingua107, cài không đụng tới torch) + chặn token,
  chặn theo ngôn ngữ thật (cận trên), khóa của bài, độ trung thành chữ viết, và khoảng tin cậy bootstrap +
  p hoán vị cho Spearman MUSAN–thật. `esB` nay in dòng `[devmon]` ngay khi có.

## v33: sửa lỗi nạp bộ nhận dạng ngôn ngữ (v32)

- ruamel.yaml 0.19 (12/2025) làm HyperPyYAML của SpeechBrain hỏng (`'Loader' object has no attribute 'max_depth'`):
  `baseC` nay ghim `ruamel.yaml<0.19`; bộ nhận dạng được nạp thử một lần trước khi chạy song song, lỗi thì dừng ngay.
