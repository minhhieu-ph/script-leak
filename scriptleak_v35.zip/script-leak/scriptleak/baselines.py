"""Baselines a reviewer will ask for, and the remaining statistics (v32-v34).

  lid       run a public spoken-language identifier once over the test sets and keep,
            per utterance, its Thai and English scores. Independent of the ASR model.
              --engine voxlingua  SpeechBrain VoxLingua107 ECAPA (CPU pool)
              --engine mms        Meta MMS-LID-126 (transformers, 1B parameters, GPU);
                                  --shard k --num-shards n splits the work over GPUs
              --prefix-sec N      only the first N seconds of each utterance (what a
                                  streaming system knows early); 0 = whole utterance
  merge     join the shard files of one identifier
  score     on the final models' test dumps (LOTUSDIS Thai, AMI far-field and close-talk,
            LOTUSDIS mixed), compare greedy, our lock (script from the CTC mass), a mask
            chosen by every identifier found ($W/lid_*.jsonl), and the oracle mask (true
            language): leak, CER/WER, English words kept, script fidelity, decision
            accuracy. Also: the same per LOTUSDIS microphone, the checkpoint chosen on dev
            (v29, if singlerun_en20.json exists) combined with each mask, Typhoon ASR
            Realtime on LOTUSDIS (if typhoon_*.jsonl exists), and the MUSAN-vs-real
            Spearman with a bootstrap interval.

  python -m scriptleak.baselines lid --work $W [--engine mms --shard 0 --num-shards 8] [--prefix-sec 2]
  python -m scriptleak.baselines score --work $W
"""

from __future__ import annotations

import argparse
import math
import re
import glob
import json
import multiprocessing as mp
import os
import sys
from collections import Counter, defaultdict
from typing import Dict, List, Optional

import numpy as np

from .calib import _synthetic
from .decoding import greedy, hard_mask, utterance_lock
from .dumpio import iter_dump, read_meta
from .normalize import scoring_normalize
from .realstats import DEFAULT_GROUPS, EN, TH, parse_groups
from .retention import latin_words
from .tokenmap import MAJ, MIN, ids_to_text, token_groups

SETS = {"real_lotus_th": "th", "real_ami_en": "en", "real_amiihm_en": "en", "real_lotus_mixed": "mix"}
MANIFESTS = (("real_lotus_th", "lotus.th.jsonl"), ("real_ami_en", "ami.en.jsonl"),
             ("real_amiihm_en", "amiihm.en.jsonl"), ("real_lotus_mixed", "lotus.mixed.jsonl"))


# ------------------------------------------------------------------ language identification

_CLF = None
_PREFIX = 0.0


def _lid_init(prefix: float = 0.0):
    global _CLF, _PREFIX
    import torch

    torch.set_num_threads(1)
    _PREFIX = prefix
    try:
        from speechbrain.inference.classifiers import EncoderClassifier
    except ImportError:  # older SpeechBrain
        from speechbrain.pretrained import EncoderClassifier
    _CLF = EncoderClassifier.from_hparams(source="speechbrain/lang-id-voxlingua107-ecapa",
                                          savedir=os.environ.get("LID_CACHE", "pretrained_models/lid_voxlingua107"),
                                          run_opts={"device": "cpu"})


def _lang_index(clf, code: str) -> int:
    lab2ind = clf.hparams.label_encoder.lab2ind
    for lab, i in lab2ind.items():
        if str(lab).split(":")[0].strip().lower() == code:
            return int(i)
    raise KeyError(f"language '{code}' not in the identifier's labels")


def _load_audio(path: str, prefix: float):
    import soundfile as sf

    from .audio import resample, to_mono

    a, sr = sf.read(path, dtype="float32", always_2d=False)
    a = resample(to_mono(a), sr, 16000)
    if prefix > 0:
        a = a[: int(prefix * 16000)]
    return np.ascontiguousarray(a, dtype=np.float32)


def _lid_one(path: str):
    import torch

    try:
        a = _load_audio(path, _PREFIX)
        out = _CLF.classify_batch(torch.from_numpy(a).unsqueeze(0))[0][0]
        return path, float(out[_lang_index(_CLF, "th")]), float(out[_lang_index(_CLF, "en")])
    except Exception as e:  # noqa: BLE001
        return path, None, f"{type(e).__name__}: {e}"


def _test_paths(work: str) -> List[str]:
    paths, seen = [], set()
    for _, man in MANIFESTS:
        p = os.path.join(work, "real", man)
        if not os.path.exists(p):
            print(f"   {man}: missing, skipped")
            continue
        for l in open(p, encoding="utf-8"):
            if l.strip():
                a = json.loads(l)["audio_filepath"]
                if a not in seen:
                    seen.add(a)
                    paths.append(a)
    return paths


def lid_name(engine: str, prefix: float) -> str:
    base = "voxlingua107" if engine == "voxlingua" else "mms126"
    return base if prefix <= 0 else f"{base}_p{prefix:g}s"


def _done(path: str) -> set:
    if not os.path.exists(path):
        return set()
    out = set()
    for l in open(path, encoding="utf-8"):
        try:
            out.add(json.loads(l)["audio_filepath"])
        except (ValueError, KeyError):
            pass  # a line cut by an interrupted run
    return out


def cmd_lid(args) -> int:
    paths = _test_paths(args.work)
    name = lid_name(args.engine, args.prefix_sec)
    if args.num_shards > 1:
        paths = paths[args.shard::args.num_shards]
        out = os.path.join(args.work, f"lid_{name}.part{args.shard}.jsonl.tmp")
    else:
        out = os.path.join(args.work, f"lid_{name}.jsonl")
    done = _done(out)
    todo = [p for p in paths if p not in done]
    print(f"language identification ({name}): {len(todo)} of {len(paths)} utterances to do", flush=True)
    if not todo:
        return 0
    if args.engine == "mms":
        return _lid_mms(todo, out, args.prefix_sec)
    try:  # load once here: a failing initializer would make the pool respawn workers forever (v32)
        _lid_init(args.prefix_sec)
    except Exception as e:  # noqa: BLE001
        print(f"!! cannot load the language identifier: {type(e).__name__}: {e}")
        return 1
    errors = 0
    with mp.get_context("spawn").Pool(max(1, args.workers), initializer=_lid_init,
                                      initargs=(args.prefix_sec,)) as pool, open(out, "a", encoding="utf-8") as f:
        for k, (p, th, en) in enumerate(pool.imap_unordered(_lid_one, todo, chunksize=8), 1):
            if th is None:
                errors += 1
                if errors <= 5:
                    print(f"!! LID failed on {p}: {en}")
                continue
            f.write(json.dumps({"audio_filepath": p, "th": th, "en": en}) + "\n")
            if k % 4000 == 0:
                print(f"  {k}/{len(todo)}", flush=True)
    print(f"wrote {out} ({errors} failures)")
    return 0 if errors < max(10, len(todo) // 100) else 1


def _lid_mms(todo: List[str], out: str, prefix: float) -> int:
    from .nemo_tools.common import preload

    preload()
    import torch

    try:
        from transformers import AutoFeatureExtractor, Wav2Vec2ForSequenceClassification
    except ImportError as e:
        print(f"!! transformers is not available ({e}); MMS-LID skipped")
        return 1
    mid = "facebook/mms-lid-126"
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    model = fe = None
    import traceback

    import transformers

    print(f"   transformers {transformers.__version__}, torch {torch.__version__}", flush=True)
    for how in ("seqcls", "seqcls-nosafetensors", "auto"):
        try:
            from transformers import AutoModelForAudioClassification, Wav2Vec2FeatureExtractor

            fe = Wav2Vec2FeatureExtractor.from_pretrained(mid) if how != "seqcls" else AutoFeatureExtractor.from_pretrained(mid)
            if how == "auto":
                model = AutoModelForAudioClassification.from_pretrained(mid)
            else:
                kw = {"use_safetensors": False} if how == "seqcls-nosafetensors" else {}
                model = Wav2Vec2ForSequenceClassification.from_pretrained(mid, **kw)
            model = model.to(dev).eval()
            break
        except Exception as e:  # noqa: BLE001
            print(f"!! cannot load {mid} ({how}): {type(e).__name__}: {e}")
            traceback.print_exc()
            model = None
    if model is None:
        return 1
    l2i = {str(k).lower(): v for k, v in (model.config.label2id or {}).items()}
    if not l2i and model.config.id2label:
        l2i = {str(v).lower(): int(k) for k, v in model.config.id2label.items()}
    if "tha" not in l2i or "eng" not in l2i:
        print(f"!! {mid}: labels tha/eng not found in config ({list(l2i)[:10]} ...)")
        return 1
    th_i, en_i = l2i["tha"], l2i["eng"]
    errors = 0
    with open(out, "a", encoding="utf-8") as f, torch.inference_mode():
        for k, p in enumerate(todo, 1):
            try:
                a = _load_audio(p, prefix)
                x = fe(a, sampling_rate=16000, return_tensors="pt").to(dev)
                logits = model(**x).logits[0].float().log_softmax(-1).cpu()
                f.write(json.dumps({"audio_filepath": p, "th": float(logits[th_i]), "en": float(logits[en_i])}) + "\n")
            except Exception as e:  # noqa: BLE001
                errors += 1
                if errors <= 5:
                    print(f"!! MMS-LID failed on {p}: {type(e).__name__}: {e}")
            if k % 1000 == 0:
                print(f"  {k}/{len(todo)}", flush=True)
    print(f"wrote {out} ({errors} failures)")
    return 0 if errors < max(10, len(todo) // 100) else 1


def cmd_merge(args) -> int:
    name = lid_name(args.engine, args.prefix_sec)
    parts = sorted(glob.glob(os.path.join(args.work, f"lid_{name}.part*.jsonl.tmp")))
    if not parts:
        print(f"no shard files for {name}")
        return 1
    rows = {}
    for p in parts:
        for l in open(p, encoding="utf-8"):
            try:
                r = json.loads(l)
                rows[r["audio_filepath"]] = r
            except (ValueError, KeyError):
                pass
    out = os.path.join(args.work, f"lid_{name}.jsonl")
    with open(out, "w", encoding="utf-8") as f:
        for r in rows.values():
            f.write(json.dumps(r) + "\n")
    print(f"wrote {out}: {len(rows)} utterances from {len(parts)} shards")
    return 0


# ------------------------------------------------------------------ scoring

def load_lids(work: str) -> Dict[str, Dict[str, bool]]:
    """lid name -> (audio_filepath -> log-odds English vs Thai; > 0 means English)."""
    out = {}
    for p in sorted(glob.glob(os.path.join(work, "lid_*.jsonl"))):
        name = os.path.basename(p)[4:-6]
        d = {}
        for l in open(p, encoding="utf-8"):
            try:
                r = json.loads(l)
                d[r["audio_filepath"]] = float(r["en"]) - float(r["th"])  # >0: says English
            except (ValueError, KeyError):
                pass
        if d:
            out[name] = d
    return out


def _edit(a, b) -> int:
    from .pareto import edit_distance

    return edit_distance(a, b)


def method_names(lids: Dict) -> List[str]:
    return ["greedy", "lock"] + [f"lid:{n}" for n in lids] + [f"fuse:{n}" for n in lids] + ["oracle-mask"]


def _prefix_sec(name: str) -> float:
    m = re.search(r"_p([0-9.]+)s$", name)
    return float(m.group(1)) if m else 0.0


def _is_decider(m: str) -> bool:
    return m == "lock" or m.startswith("lid:") or m.startswith("fuse:")


def fuse_says_english(lid_logodds: float, p_en_lock: float) -> bool:
    """v35 late fusion, fixed in advance and not tuned: the mean of the identifier's
    two-way posterior P(English) and the ASR model's own share of English-script
    mass, then a 0.5 threshold."""
    p_lid = 1.0 / (1.0 + math.exp(-max(-50.0, min(50.0, lid_logodds))))
    return 0.5 * (p_lid + p_en_lock) > 0.5


def score_dump(path: str, kind: str, lids: Dict[str, Dict[str, bool]]) -> Dict:
    meta = read_meta(path)
    vocab, blank = meta["vocab"], int(meta["blank_id"])
    groups = token_groups(vocab, TH, EN, blank_id=blank)
    spoken, other = (EN, TH) if kind == "en" else (TH, EN)
    english = kind == "en"
    acc: Dict[str, Counter] = defaultdict(Counter)
    per: Dict[str, Dict[str, Counter]] = defaultdict(lambda: defaultdict(Counter))
    for rec, lp in iter_dump(path):
        ref = scoring_normalize(str(rec.get("text", "")))
        if kind != "mix" and (other.script.count(ref) or not spoken.script.count(ref)):
            continue
        a = str(rec.get("audio_filepath"))
        st = str(rec.get("stratum", ""))
        fm, fn = np.exp(lp[:, groups == MAJ]).sum(axis=1), np.exp(lp[:, groups == MIN]).sum(axis=1)
        pm, pn = fm.sum(), fn.sum()
        dur = rec.get("duration")
        fps = len(lp) / float(dur) if dur else 12.5
        hyps = {"greedy": greedy(lp, groups), "lock": utterance_lock(lp, groups),
                "oracle-mask": hard_mask(lp, groups, MAJ if english else MIN)}
        decisions = {"lock": pn > pm}
        for n, d in lids.items():
            if a in d:
                says_en = d[a] > 0
                hyps[f"lid:{n}"] = hard_mask(lp, groups, MAJ if says_en else MIN)
                decisions[f"lid:{n}"] = says_en
                ps = _prefix_sec(n)
                k = len(lp) if ps <= 0 else max(1, min(len(lp), int(round(ps * fps))))
                em, en_ = float(fm[:k].sum()), float(fn[:k].sum())
                p_lock = en_ / (em + en_) if em + en_ >= 0.5 else 0.5
                f_en = fuse_says_english(d[a], p_lock)
                hyps[f"fuse:{n}"] = hard_mask(lp, groups, MAJ if f_en else MIN)
                decisions[f"fuse:{n}"] = f_en
        ru = ref.split() if english else ref.replace(" ", "")
        rw = Counter(latin_words(ref)) if kind == "mix" else None
        for m, ids in hyps.items():
            hyp = scoring_normalize(ids_to_text(ids, vocab))
            hu = hyp.split() if english else hyp.replace(" ", "")
            e = _edit(ru, hu)
            o, s = other.script.count(hyp), spoken.script.count(hyp)
            for c in (acc[m], per[st][m]):
                c["n"] += 1
                c["err"] += e
                c["ref"] += len(ru)
                if kind != "mix":
                    c["leak"] += o > 0
                    c["fid_num"] += s / (o + s) if o + s else 1.0
                    if m in decisions:
                        c["dec_ok"] += decisions[m] == english
                else:
                    c["kept"] += sum((rw & Counter(latin_words(hyp))).values())
                    c["words"] += sum(rw.values())
    def fin(c, m):
        r = {"n": c["n"], "err": c["err"] / max(1, c["ref"])}
        if kind != "mix":
            r["leak"] = c["leak"] / max(1, c["n"])
            r["fidelity"] = c["fid_num"] / max(1, c["n"])
            if _is_decider(m):
                r["decision_acc"] = c["dec_ok"] / max(1, c["n"])
        else:
            r["kept"] = c["kept"] / max(1, c["words"])
        return r
    out = {m: fin(c, m) for m, c in acc.items() if c["n"]}
    out["_per_stratum"] = {st: {m: dict(c) for m, c in d.items()} for st, d in per.items()} if kind == "th" else {}
    return out


def _job(args):
    path, kind, lids = args
    try:
        return path, score_dump(path, kind, lids)
    except Exception as e:  # noqa: BLE001
        return path, f"{type(e).__name__}: {e}"


def spearman_ci(x: np.ndarray, y: np.ndarray, resamples: int = 10000, seed: int = 0) -> Dict:
    rk = lambda v: np.argsort(np.argsort(v, kind="stable"), kind="stable").astype(float)
    rho = lambda a, b: float(np.corrcoef(rk(a), rk(b))[0, 1]) if np.std(rk(a)) and np.std(rk(b)) else 0.0
    rng = np.random.default_rng(seed)
    n = len(x)
    boots = []
    for _ in range(resamples):
        i = rng.integers(0, n, n)
        if len(set(i)) > 2:
            boots.append(rho(x[i], y[i]))
    r0 = rho(x, y)
    perm = np.mean([abs(rho(x, rng.permutation(y))) >= abs(r0) for _ in range(resamples)])
    return {"rho": r0, "ci": (float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5))),
            "p_perm": float(perm), "n": n}


def _fmt(v) -> str:
    return "     -" if v is None or (isinstance(v, float) and np.isnan(v)) else f"{v:6.1%}"


def _recipe_table(got: Dict[str, Dict], groups: Dict[str, List[str]], dirs, methods: List[str], title: str) -> List[str]:
    L = [title]
    for g, ls in groups.items():
        rows = []
        for m in methods:
            vals = []
            for l in ls:
                r = {s: got.get(dirs(l, s), {}).get(m) for s in SETS}
                if r["real_lotus_th"] and r["real_ami_en"]:
                    vals.append(r)
            if not vals:
                continue
            def mean(s, k):
                xs = [v[s][k] for v in vals if v.get(s) and k in v[s]]
                return float(np.mean(xs)) if xs else float("nan")
            sums = [v["real_lotus_th"]["leak"] + v["real_ami_en"]["leak"] for v in vals]
            row = (f"  {m:<22} {_fmt(mean('real_lotus_th', 'leak'))} {_fmt(mean('real_ami_en', 'leak'))} "
                   f"{_fmt(float(np.mean(sums)))} {_fmt(float(np.std(sums, ddof=1)) if len(sums) > 1 else float('nan'))} "
                   f"{_fmt(mean('real_lotus_th', 'err')):>7} {_fmt(mean('real_ami_en', 'err')):>7} "
                   f"{_fmt(mean('real_amiihm_en', 'leak')):>9} {_fmt(mean('real_amiihm_en', 'err')):>8} "
                   f"{_fmt(mean('real_lotus_mixed', 'err')):>8}")
            if _is_decider(m):
                row += f"   {mean('real_lotus_th', 'decision_acc'):.1%}/{mean('real_ami_en', 'decision_acc'):.1%}"
            rows.append(row)
        if rows:
            L.append(f"\n=== {g} ({', '.join(ls)})")
            L.append(f"  {'method':<22} {'Th>L':>6} {'En>Th':>6} {'sum':>6} {'(sd)':>6} {'CER Th':>7} {'WER En':>7}"
                     f" {'IHM En>Th':>9} {'IHM WER':>8} {'mix CER':>8}   decision Th/En")
            L += rows
    return L


def _per_mic(got: Dict[str, Dict], labels: List[str], dirs, methods: List[str]) -> List[str]:
    pooled: Dict[str, Dict[str, Counter]] = defaultdict(lambda: defaultdict(Counter))
    for l in labels:
        r = got.get(dirs(l, "real_lotus_th"), {})
        for st, d in r.get("_per_stratum", {}).items():
            for m, c in d.items():
                pooled[st][m].update(c)
    if not pooled:
        return []
    shown = [m for m in methods if m == "greedy" or _is_decider(m)]
    L = ["\nLOTUSDIS Thai per microphone, all final models pooled: leak / CER (decision accuracy for lock and LIDs)"]
    L.append(f"  {'mic':<16} {'n':>6} " + " ".join(f"{m[:24]:>26}" for m in shown))
    for st in sorted(pooled):
        cells = []
        for m in shown:
            c = pooled[st].get(m)
            if not c or not c["n"]:
                cells.append(f"{'-':>26}")
                continue
            cell = f"{c['leak'] / c['n']:.1%}/{c['err'] / max(1, c['ref']):.1%}"
            if m != "greedy":
                cell += f" ({c['dec_ok'] / c['n']:.0%})"
            cells.append(f"{cell:>26}")
        n = pooled[st]["greedy"]["n"] // max(1, len(labels))
        L.append(f"  {st:<16} {n:>6} " + " ".join(cells))
    return L


def _typhoon(work: str) -> List[str]:
    L = []
    for p in sorted(glob.glob(os.path.join(work, "typhoon_*.jsonl"))):
        rows = [json.loads(l) for l in open(p, encoding="utf-8") if l.strip()]
        if not rows:
            continue
        per = defaultdict(Counter)
        for r in rows:
            ref, hyp = scoring_normalize(r.get("text", "")), scoring_normalize(r.get("pred", ""))
            ru, hu = ref.replace(" ", ""), hyp.replace(" ", "")
            for k in ("ALL", str(r.get("stratum", ""))):
                c = per[k]
                c["n"] += 1
                c["err"] += _edit(ru, hu)
                c["ref"] += len(ru)
                c["leak"] += EN.script.count(hyp) > 0
        L.append(f"\nTyphoon ASR Realtime (public Thai model, 10k hours) on {os.path.basename(p)}: CER / Latin-letter rate")
        for k in ["ALL"] + sorted(x for x in per if x != "ALL"):
            c = per[k]
            L.append(f"  {k:<16} n={c['n']:>5}  CER {c['err'] / max(1, c['ref']):6.1%}  leak {c['leak'] / max(1, c['n']):6.1%}")
    return L


def cmd_score(args) -> int:
    groups = parse_groups(args.groups)
    lids = load_lids(args.work)
    print("identifiers found: " + (", ".join(f"{n} ({len(d)})" for n, d in lids.items()) or "none"), flush=True)
    methods = method_names(lids)
    labels = [l for ls in groups.values() for l in ls]
    final_dir = lambda l, s: os.path.join(args.work, "dumps", f"B{args.b_pct}_{l}", s)
    jobs = [(final_dir(l, s), kind, lids) for l in labels for s, kind in SETS.items()
            if os.path.exists(os.path.join(final_dir(l, s), "meta.json"))]
    # checkpoints chosen on dev in one run (v29), if that analysis exists
    picks = {}
    sj = os.path.join(args.work, f"singlerun_en{args.b_pct}.json")
    if os.path.exists(sj):
        from .singlerun import cand_dir

        sr = json.load(open(sj, encoding="utf-8"))
        for g, v in sr.get("groups", {}).items():
            for p in v.get("rows", {}).get("one run: guarded pick + lock", {}).get("picks", []):
                l, c = p.split(":", 1)
                picks[l] = c
        for l, c in picks.items():
            for s, kind in SETS.items():
                d = cand_dir(args.work, args.b_pct, l, c, s)
                if os.path.exists(os.path.join(d, "meta.json")) and (d, kind, lids) not in jobs:
                    jobs.append((d, kind, lids))
    print(f"scoring {len(jobs)} dumps with {len(methods)} methods ...", flush=True)
    got = {}
    with mp.get_context("spawn").Pool(max(1, args.workers)) as pool:
        for p, r in pool.imap_unordered(_job, jobs):
            if isinstance(r, str):
                print(f"!! {p}: {r}")
            else:
                got[p] = r
    L = ["Test sets, mean over the seeds of each recipe. Leak = share of utterances with a letter of the other script.",
         "lid:X = script chosen by identifier X for the whole utterance (X_pNs = from its first N seconds only);",
         "fuse:X = mean of X's P(English) and the model's own English-script mass share (same N seconds), threshold 0.5;",
         "decision = share of utterances whose language decision is right."]
    L += _recipe_table(got, groups, final_dir, methods, "\n######## Final models")
    L += _per_mic(got, labels, final_dir, methods)
    if picks:
        from .singlerun import cand_dir

        pick_dir = lambda l, s: cand_dir(args.work, args.b_pct, l, picks.get(l, "final"), s)
        L += _recipe_table(got, groups, pick_dir, methods,
                           "\n######## Checkpoint chosen on dev in one run (v29 guarded pick), then each decoding")
    L += _typhoon(args.work)
    xs, ys = [], []
    for l in labels:
        syn = _synthetic(args.work, args.b_pct, l)
        r = [got.get(final_dir(l, s), {}).get("greedy") for s in ("real_lotus_th", "real_ami_en")]
        if syn is not None and all(r):
            xs.append(syn)
            ys.append(r[0]["leak"] + r[1]["leak"])
    res = {}
    if len(xs) >= 5:
        sp = spearman_ci(np.array(xs), np.array(ys))
        res["spearman"] = sp
        L.append(f"\nMUSAN (synthetic) vs real leak, {sp['n']} final models: Spearman {sp['rho']:+.2f}, "
                 f"95% bootstrap interval [{sp['ci'][0]:+.2f}, {sp['ci'][1]:+.2f}], permutation p = {sp['p_perm']:.2f}")
    print("\n".join(L))
    if args.out:
        res["dumps"] = {p: {k: v for k, v in r.items() if k != "_per_stratum"} for p, r in got.items()}
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(res, fh, ensure_ascii=False, indent=1)
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name in ("lid", "merge", "score"):
        a = sub.add_parser(name)
        a.add_argument("--work", default=os.environ.get("W"))
        a.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
        a.add_argument("--groups", nargs="*", default=DEFAULT_GROUPS)
        a.add_argument("--workers", type=int, default=int(os.environ.get("CALIB_WORKERS", "16")))
        a.add_argument("--engine", choices=["voxlingua", "mms"], default="voxlingua")
        a.add_argument("--prefix-sec", type=float, default=0.0)
        a.add_argument("--shard", type=int, default=0)
        a.add_argument("--num-shards", type=int, default=1)
        a.add_argument("--out")
    args = p.parse_args(argv)
    if not args.work:
        p.error("--work (or $W) is required")
    return {"lid": cmd_lid, "merge": cmd_merge, "score": cmd_score}[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
