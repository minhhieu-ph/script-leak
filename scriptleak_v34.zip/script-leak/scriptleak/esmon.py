"""Checkpoint choice and early stopping driven by the real dev set during training (v30).

Reads <exp_dir>/devmon.jsonl, written by nemo_tools.devmon after every epoch
(leak and CER/WER on small real dev subsets, greedy and with the script lock).
All rules score the lock decoding (that is how the model would be deployed):

  final         the last epoch
  min-leak      lowest dev leak (Thai->Latin + English->Thai) over the saved epochs
  guarded       lowest dev leak among epochs whose dev CER and WER are at most TOL
                above the final epoch's (needs the whole run)
  es(P)         online early stopping: at each epoch, among the epochs seen so far whose dev
                CER and WER are at most TOL above the best seen so far, take the one with
                the lowest dev leak; stop once that choice has not changed for P epochs.
                Uses only past epochs, so it works while training and saves the rest.

  python -m scriptleak.esmon select --exp-dir exp/B20_rir_es [--prune]
  python -m scriptleak.esmon report --work $W --labels clean_es clean_s1_es ...
"""

from __future__ import annotations

import argparse
import glob
import json
import multiprocessing as mp
import os
import re
import sys
from typing import Dict, List, Optional

import numpy as np

SETS = ("dev_lotus_th", "dev_ami_en")
TEST = ("real_lotus_th", "real_ami_en")


def load(exp_dir: str) -> List[Dict]:
    path = os.path.join(exp_dir, "devmon.jsonl")
    if not os.path.exists(path):
        return []
    rows = {}
    with open(path, encoding="utf-8") as f:
        for l in f:
            if l.strip():
                r = json.loads(l)
                rows[r["epoch"]] = r  # a restarted run overwrites earlier lines
    return [rows[e] for e in sorted(rows)]


def leak(r: Dict, m: str = "lock") -> float:
    return r[f"{SETS[0]}/{m}/leak"] + r[f"{SETS[1]}/{m}/leak"]


def errs(r: Dict, m: str = "lock"):
    return r[f"{SETS[0]}/{m}/err"], r[f"{SETS[1]}/{m}/err"]


def select(rows: List[Dict], saved: List[int], tol: float = 0.01, patience: int = 5) -> Dict:
    """Epoch picked by each rule. `saved`: epochs that have a checkpoint (the
    last epoch is always available as final.nemo)."""
    if not rows:
        return {}
    last = rows[-1]["epoch"]
    avail = [r for r in rows if r["epoch"] in saved or r["epoch"] == last]
    out = {"final": last, "min-leak": min(avail, key=lambda r: (leak(r), -r["epoch"]))["epoch"]}
    cf, wf = errs(rows[-1])
    ok = [r for r in avail if errs(r)[0] <= cf + tol and errs(r)[1] <= wf + tol]
    out["guarded"] = min(ok, key=lambda r: (leak(r), -r["epoch"]))["epoch"] if ok else last
    for P in sorted({patience, 3, 10}):
        best, best_c, best_w, since, stop, seen = None, np.inf, np.inf, 0, last, []
        for r in rows:
            c, w = errs(r)
            best_c, best_w = min(best_c, c), min(best_w, w)
            if r["epoch"] in saved or r["epoch"] == last:
                seen.append(r)
            # re-checked every epoch: an early pick drops out once accuracy has moved on
            ok_now = [x for x in seen if errs(x)[0] <= best_c + tol and errs(x)[1] <= best_w + tol]
            cand = min(ok_now, key=lambda x: (leak(x), -x["epoch"])) if ok_now else None
            if cand is not None and (best is None or cand["epoch"] != best["epoch"]):
                best, since = cand, 0
            else:
                since += 1
            if best is not None and since >= P:
                stop = r["epoch"]
                break
        out[f"es{P}"] = best["epoch"] if best is not None else last
        out[f"es{P}_stop"] = stop
    return out


def saved_epochs(exp_dir: str) -> List[int]:
    out = []
    for p in glob.glob(os.path.join(exp_dir, "mon_epoch*.nemo")):
        m = re.search(r"mon_epoch(\d+)\.nemo$", p)
        if m:
            out.append(int(m.group(1)))
    return sorted(out)


def cmd_select(args) -> int:
    rows = load(args.exp_dir)
    if not rows:
        print(f"no devmon.jsonl in {args.exp_dir}")
        return 1
    picks = select(rows, saved_epochs(args.exp_dir), args.tol, args.patience)
    with open(os.path.join(args.exp_dir, "esmon_picks.json"), "w", encoding="utf-8") as f:
        json.dump(picks, f, indent=1)
    print(json.dumps(picks))
    if args.prune:
        keep = {v for k, v in picks.items() if not k.endswith("_stop")}
        for e in saved_epochs(args.exp_dir):
            if e not in keep:
                os.remove(os.path.join(args.exp_dir, f"mon_epoch{e:03d}.nemo"))
    return 0


# ------------------------------------------------------------------ report

def _cand_dump(work, b_pct, label, epoch, last, s):
    d = os.path.join(work, "dumps", f"B{b_pct}_{label}")
    return os.path.join(d, s) if epoch == last else os.path.join(d, f"mon_epoch{epoch:03d}_{s}")


def _job(args):
    from .pareto import rates, score_dump

    path, s = args
    try:
        r = rates(score_dump(path, s, ["greedy", "lock"]))
        return path, {k: v.tolist() for k, v in r.items()}
    except Exception as e:  # noqa: BLE001
        return path, f"{type(e).__name__}: {e}"


def cmd_report(args) -> int:
    labels = args.labels
    runs = {}
    for l in labels:
        exp = os.path.join(args.work, "exp", f"B{args.b_pct}_{l}")
        rows = load(exp)
        pf = os.path.join(exp, "esmon_picks.json")
        if not rows or not os.path.exists(pf):
            print(f"   {l}: no devmon.jsonl / esmon_picks.json yet, skipped")
            continue
        runs[l] = {"rows": rows, "picks": json.load(open(pf, encoding="utf-8"))}
    if not runs:
        print("nothing to report (run 'esB' first)")
        return 1
    jobs = []
    for l, r in runs.items():
        last = r["rows"][-1]["epoch"]
        for k, e in r["picks"].items():
            if k.endswith("_stop"):
                continue
            for s in TEST:
                p = _cand_dump(args.work, args.b_pct, l, e, last, s)
                if os.path.exists(os.path.join(p, "meta.json")):
                    jobs.append((p, s))
    jobs = sorted(set(jobs))
    got = {}
    with mp.get_context("spawn").Pool(max(1, args.workers)) as pool:
        for p, r in pool.imap_unordered(_job, jobs):
            if isinstance(r, str):
                print(f"!! {p}: {r}")
            else:
                got[p] = r
    L = ["Dev curves (lock decoding, small real dev subsets): epoch: leak sum / CER Thai / WER English"]
    for l, r in runs.items():
        pts = [f"{x['epoch']}:{leak(x):.0%}/{errs(x)[0]:.0%}/{errs(x)[1]:.0%}" for x in r["rows"]
               if x["epoch"] % 5 == 0 or x["epoch"] in r["picks"].values()]
        L.append(f"  {l:<14} " + "  ".join(pts))
        L.append(f"  {'':<14} dev leak over the run: min {min(leak(x) for x in r['rows']):.1%}, "
                 f"max {max(leak(x) for x in r['rows']):.1%}; picks {r['picks']}")
    rules = ["final/greedy", "final", "min-leak", "guarded"] + sorted(
        {k for r in runs.values() for k in r["picks"] if k.startswith("es") and not k.endswith("_stop")})
    table = {}
    for l, r in runs.items():
        last = r["rows"][-1]["epoch"]
        for rule in rules:
            key, m = (rule.split("/")[0], 0) if rule.endswith("/greedy") else (rule, 1)
            e = r["picks"].get(key)
            if e is None:
                continue
            ps = [_cand_dump(args.work, args.b_pct, l, e, last, s) for s in TEST]
            if not all(p in got for p in ps):
                continue
            t, a = got[ps[0]], got[ps[1]]
            table.setdefault(rule, {})[l] = {"epoch": e, "Th>L": t["leak"][m], "En>Th": a["leak"][m],
                                             "CER": t["err"][m], "WER": a["err"][m]}
    L.append("\nTest sets, per rule (lock decoding unless marked greedy): mean over runs [min-max of leak sum]")
    L.append(f"  {'rule':<14} {'Th>L':>6} {'En>Th':>6} {'sum':>6} {'range':>14} {'CER Th':>7} {'WER En':>7}  epochs")
    groups = {}
    for l in runs:
        groups.setdefault(re.sub(r"(_s\d+)?_es$", "", l), []).append(l)
    for g, ls in groups.items():
        L.append(f"  -- {g} ({', '.join(ls)})")
        for rule in rules:
            v = [table.get(rule, {}).get(l) for l in ls]
            v = [x for x in v if x]
            if not v:
                continue
            sums = [x["Th>L"] + x["En>Th"] for x in v]
            L.append(f"  {rule:<14} {np.mean([x['Th>L'] for x in v]):6.1%} {np.mean([x['En>Th'] for x in v]):6.1%} "
                     f"{np.mean(sums):6.1%} {min(sums):6.1%}-{max(sums):6.1%} {np.mean([x['CER'] for x in v]):7.1%} "
                     f"{np.mean([x['WER'] for x in v]):7.1%}  " + ",".join(str(x["epoch"]) for x in v))
    stops = [(l, k, v) for l, r in runs.items() for k, v in r["picks"].items() if k.endswith("_stop")]
    if stops:
        L.append("\nEarly stopping: epoch at which training could have stopped (of "
                 f"{max(r['rows'][-1]['epoch'] for r in runs.values())})")
        for l, k, v in stops:
            L.append(f"  {l:<14} {k[:-5]:<5} stop at {v}")
    print("\n".join(L))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump({"table": table, "picks": {l: r["picks"] for l, r in runs.items()}}, f, indent=1)
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("select")
    a.add_argument("--exp-dir", required=True)
    a.add_argument("--tol", type=float, default=float(os.environ.get("SEL_TOL", "0.01")))
    a.add_argument("--patience", type=int, default=int(os.environ.get("ES_PATIENCE", "5")))
    a.add_argument("--prune", action="store_true", help="delete mon_epoch*.nemo that no rule picked")
    a = sub.add_parser("report")
    a.add_argument("--work", default=os.environ.get("W"))
    a.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    a.add_argument("--labels", nargs="+", required=True)
    a.add_argument("--workers", type=int, default=int(os.environ.get("CALIB_WORKERS", "16")))
    a.add_argument("--out")
    args = p.parse_args(argv)
    return cmd_select(args) if args.cmd == "select" else cmd_report(args)


if __name__ == "__main__":
    sys.exit(main())
