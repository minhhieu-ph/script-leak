"""Transcribe a manifest with Typhoon ASR Realtime, a public Thai FastConformer-Transducer (v34).

Context for the paper's error rates: the same 115M architecture trained on about
10,000 hours of Thai. It writes Thai only, so it says nothing about leakage; it
shows how hard LOTUSDIS is for a strong Thai model. Scored by scriptleak.baselines.

  python -m scriptleak.nemo_tools.typhoon_eval --manifest real/lotus.th.jsonl --out typhoon_lotus_th.jsonl
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import List, Optional

from ..manifest import read_manifest

MODELS = ("typhoon-ai/typhoon-asr-realtime", "scb10x/typhoon-asr-realtime")


def _text(h) -> str:
    if isinstance(h, (list, tuple)):
        h = h[0] if h else ""
    return str(getattr(h, "text", h))


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--manifest", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--batch-size", type=int, default=32)
    p.add_argument("--model", default=None, help="Hugging Face id (default: try the known ids)")
    args = p.parse_args(argv)

    from .common import patch_nemo, preload

    preload()
    import nemo.collections.asr as nemo_asr

    patch_nemo()
    model, err = None, None
    for mid in ([args.model] if args.model else MODELS):
        try:
            model = nemo_asr.models.ASRModel.from_pretrained(mid, map_location="cuda").eval()
            print(f"loaded {mid}", flush=True)
            break
        except Exception as e:  # noqa: BLE001
            err = f"{mid}: {type(e).__name__}: {e}"
    if model is None:
        print(f"!! could not load Typhoon ASR ({err})")
        return 1
    rows = list(read_manifest(args.manifest))
    out = []
    for s in range(0, len(rows), 512):
        chunk = rows[s:s + 512]
        files = [r["audio_filepath"] for r in chunk]
        try:
            res = model.transcribe(files, batch_size=args.batch_size, verbose=False)
        except TypeError:  # older NeMo: no verbose argument
            res = model.transcribe(files, batch_size=args.batch_size)
        if isinstance(res, tuple):
            res = res[0]
        out += [_text(h) for h in res]
        print(f"{min(s + 512, len(rows))}/{len(rows)}", flush=True)
    with open(args.out, "w", encoding="utf-8") as f:
        for r, h in zip(rows, out):
            f.write(json.dumps({"audio_filepath": r["audio_filepath"], "text": r.get("text", ""),
                                "stratum": r.get("stratum", ""), "pred": h}, ensure_ascii=False) + "\n")
    print(f"wrote {args.out} ({len(out)} utterances)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
