"""The proposal at the cost of one training run, and 95% intervals for every gain (v28).

v27 picked the best of three seeds on the dev set, which costs three trainings.
Here each run is handled alone: among its own candidates (final model, averaged
weights, checkpoints of epoch 30-45, all already dumped by 'selectC') the one
with the lowest dev leak under the script lock is kept, and tested with the
lock. Per recipe, test leak (Thai->Latin on LOTUSDIS + English->Thai on AMI):

  final, greedy               one run as usually reported (mean over the runs)
  final, lock                 the lock alone
  one run: dev picks + lock   checkpoint chosen on dev inside each run, with lock
  one run: guarded pick + lock  the same, among checkpoints whose dev CER and WER are at most
                              TOL (1 point) above the final model's (v29)
  three runs: dev picks + lock  v27's proposal (best seed on dev, with lock)

Intervals: cluster bootstrap (LOTUSDIS speakers, AMI meetings), paired across
methods, so differences get their own interval. They cover the test sets only;
the spread between runs is shown next to them.

CPU only.  python -m scriptleak.singlerun --work $W
"""

from __future__ import annotations

import argparse
import glob
import json
import multiprocessing as mp
import os
import re
import sys
from typing import Dict, List, Optional, Tuple

import numpy as np

from .pareto import score_dump
from .realstats import DEFAULT_GROUPS, parse_groups

DEV = ("dev_lotus_th", "dev_ami_en")
TEST = ("real_lotus_th", "real_ami_en")
NAMES = ["greedy", "lock"]
G, LK = 0, 1


def cand_dir(work: str, b_pct: str, label: str, cand: str, s: str) -> str:
    if cand == "final":
        return os.path.join(work, "dumps", f"B{b_pct}_{label}", s)
    if cand == "avg":
        return os.path.join(work, "dumps", f"B{b_pct}_{label}_avg", s)
    return os.path.join(work, "dumps", f"B{b_pct}_{label}", f"sel_{cand}_{s}")


def candidates(work: str, b_pct: str, label: str) -> List[str]:
    out = ["final", "avg"]
    for d in glob.glob(os.path.join(work, "dumps", f"B{b_pct}_{label}", "sel_epoch*_dev_lotus_th")):
        m = re.search(r"sel_(epoch\d+)_", d)
        if m:
            out.append(m.group(1))
    return sorted(set(out), key=lambda c: (c != "final", c != "avg", c))


def _job(args):
    path, s = args
    try:
        d = score_dump(path, s, NAMES)
        return path, {"leak": d["leak"], "keys": d["keys"], "clusters": d["clusters"],
                      "err": d["errs"].sum(axis=0) / max(1, int(d["ref_len"].sum()))}
    except Exception as e:  # noqa: BLE001
        return path, f"{type(e).__name__}: {e}"


class Boot:
    """Paired cluster bootstrap of leak rates on one test set."""

    def __init__(self, keys: List[str], clusters: np.ndarray, resamples: int, rng):
        self.keys = keys
        uniq, self.cidx = np.unique(clusters, return_inverse=True)
        C = len(uniq)
        self.W = rng.multinomial(C, np.full(C, 1.0 / C), size=resamples).astype(np.float64)
        self.N = np.bincount(self.cidx, minlength=C).astype(np.float64)
        self.den = self.W @ self.N

    def rates(self, flags: np.ndarray) -> np.ndarray:
        F = np.bincount(self.cidx, weights=flags.astype(np.float64), minlength=len(self.N))
        return (self.W @ F) / self.den


def _ci(x: np.ndarray) -> Tuple[float, float]:
    return float(np.percentile(x, 2.5)), float(np.percentile(x, 97.5))


def run(work: str, b_pct: str, groups: Dict[str, List[str]], workers: int = 16,
        resamples: int = 2000, seed: int = 0, log=print, tol: float = 0.01) -> Dict:
    labels = [l for ls in groups.values() for l in ls]
    cands = {l: candidates(work, b_pct, l) for l in labels}
    jobs = [(cand_dir(work, b_pct, l, c, s), s) for l in labels for c in cands[l] for s in DEV + TEST
            if os.path.exists(os.path.join(cand_dir(work, b_pct, l, c, s), "meta.json"))]
    log(f"scoring {len(jobs)} dumps (greedy and lock) ...")
    got = {}
    with mp.get_context("spawn").Pool(max(1, workers)) as pool:
        for k, (path, r) in enumerate(pool.imap_unordered(_job, jobs), 1):
            if isinstance(r, str):
                log(f"!! {path}: {r}")
            else:
                got[path] = r
            if k % 16 == 0 or k == len(jobs):
                log(f"  {k}/{len(jobs)}")
    # reference order of the test utterances
    ref = {}
    for s in TEST:
        for l in labels:
            p = cand_dir(work, b_pct, l, "final", s)
            if p in got:
                ref[s] = got[p]
                break
    if len(ref) < 2:
        return {"groups": {}}
    rng = np.random.default_rng(seed)
    boots = {s: Boot(ref[s]["keys"], ref[s]["clusters"], resamples, rng) for s in TEST}

    def flags(path: str, s: str, m: int) -> Optional[np.ndarray]:
        r = got.get(path)
        if r is None:
            return None
        if r["keys"] == ref[s]["keys"]:
            return r["leak"][:, m]
        pos = {k: i for i, k in enumerate(r["keys"])}
        if not all(k in pos for k in ref[s]["keys"]):
            return None
        return r["leak"][[pos[k] for k in ref[s]["keys"]], m]

    def dev_rate(l, c, m):
        v = [got.get(cand_dir(work, b_pct, l, c, s)) for s in DEV]
        return None if any(x is None for x in v) else float(sum(x["leak"][:, m].mean() for x in v))

    def err(l, c, m, sets):
        v = [got.get(cand_dir(work, b_pct, l, c, s)) for s in sets]
        return None if any(x is None for x in v) else (float(v[0]["err"][m]), float(v[1]["err"][m]))

    def guarded(l):
        base = err(l, "final", G, DEV)
        ok = [c for c in cands[l] if dev_rate(l, c, LK) is not None and test_boot(l, c, LK) is not None
              and (base is None or (err(l, c, LK, DEV)[0] <= base[0] + tol and err(l, c, LK, DEV)[1] <= base[1] + tol))]
        return (min(ok, key=lambda c: dev_rate(l, c, LK)) if ok else "final"), LK

    def test_boot(l, c, m):
        """bootstrap samples of the test sum, and the point value"""
        f = [flags(cand_dir(work, b_pct, l, c, s), s, m) for s in TEST]
        if any(x is None for x in f):
            return None
        return (boots[TEST[0]].rates(f[0]) + boots[TEST[1]].rates(f[1]),
                float(f[0].mean() + f[1].mean()))

    res: Dict = {"groups": {}, "runs": {}}
    for g, ls in groups.items():
        ls = [l for l in ls if test_boot(l, "final", G) is not None]
        if not ls:
            continue
        rows: Dict[str, Dict] = {}
        per_run = {}
        samples = {}
        for name, fn in (
            ("final, greedy", lambda l: ("final", G)),
            ("final, lock", lambda l: ("final", LK)),
            ("one run: dev picks + lock", lambda l: (min((c for c in cands[l] if dev_rate(l, c, LK) is not None
                                                          and test_boot(l, c, LK) is not None),
                                                         key=lambda c: dev_rate(l, c, LK)), LK)),
            ("one run: guarded pick + lock", guarded),
        ):
            sb, pts, picks, errs = [], [], [], []
            for l in ls:
                c, m = fn(l)
                b, pt = test_boot(l, c, m)
                sb.append(b)
                pts.append(pt)
                picks.append(f"{l}:{c}")
                errs.append(err(l, c, m, TEST))
            samples[name] = np.mean(sb, axis=0)
            rows[name] = {"mean": float(np.mean(pts)), "ci": _ci(samples[name]),
                          "sd_runs": float(np.std(pts, ddof=1)) if len(pts) > 1 else 0.0,
                          "range": (float(min(pts)), float(max(pts))), "picks": picks,
                          "CER": float(np.mean([e[0] for e in errs])), "WER": float(np.mean([e[1] for e in errs]))}
            per_run[name] = dict(zip(ls, pts))
        best = min(ls, key=lambda l: dev_rate(l, "final", LK))
        b, pt = test_boot(best, "final", LK)
        samples["three runs: dev picks + lock"] = b
        e3 = err(best, "final", LK, TEST)
        rows["three runs: dev picks + lock"] = {"mean": pt, "ci": _ci(b), "picks": [best], "CER": e3[0], "WER": e3[1]}
        base = samples["final, greedy"]
        diffs = {}
        for name in ("final, lock", "one run: dev picks + lock", "one run: guarded pick + lock",
                     "three runs: dev picks + lock"):
            d = samples[name] - base
            diffs[name] = {"diff": float(rows[name]["mean"] - rows["final, greedy"]["mean"]), "ci": _ci(d),
                           "rel": float((rows[name]["mean"] - rows["final, greedy"]["mean"]) / rows["final, greedy"]["mean"])
                           if rows["final, greedy"]["mean"] else 0.0}
        res["groups"][g] = {"rows": rows, "diffs": diffs}
        res["runs"][g] = per_run
    return res


def report(res: Dict) -> List[str]:
    L = ["Test leak, Thai->Latin (LOTUSDIS) + English->Thai (AMI). [95% interval: test-set resampling of "
         "speakers / meetings; spread between runs shown separately]. CER on LOTUSDIS Thai, WER on AMI."]
    for g, v in res["groups"].items():
        L.append(f"\n=== {g}")
        for name, r in v["rows"].items():
            extra = f"  runs sd {r['sd_runs']:.1%}, range {r['range'][0]:.1%}-{r['range'][1]:.1%}" if "sd_runs" in r else ""
            L.append(f"  {name:<30} {r['mean']:6.1%} [{r['ci'][0]:5.1%}, {r['ci'][1]:5.1%}]  "
                     f"CER {r['CER']:5.1%} WER {r['WER']:5.1%}{extra}")
        L.append("  checkpoint picked per run: " + ", ".join(v["rows"]["one run: dev picks + lock"]["picks"]))
        L.append("  guarded (dev CER/WER at most TOL above the final model): "
                 + ", ".join(v["rows"]["one run: guarded pick + lock"]["picks"]))
        L.append("  change vs 'final, greedy':")
        for name, d in v["diffs"].items():
            L.append(f"    {name:<30} {d['diff']:+6.1%} [{d['ci'][0]:+5.1%}, {d['ci'][1]:+5.1%}]  ({d['rel']:+.0%})")
    if res.get("runs"):
        L.append("\nPer run: final greedy -> final lock -> dev-picked checkpoint with lock -> guarded pick with lock")
        for g, pr in res["runs"].items():
            for l in pr["final, greedy"]:
                L.append(f"  {l:<10} {pr['final, greedy'][l]:6.1%} -> {pr['final, lock'][l]:6.1%} -> "
                         f"{pr['one run: dev picks + lock'][l]:6.1%} -> {pr['one run: guarded pick + lock'][l]:6.1%}")
    return L


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--work", default=os.environ.get("W"))
    p.add_argument("--b-pct", default=os.environ.get("B_PCT", "20"))
    p.add_argument("--groups", nargs="*", default=DEFAULT_GROUPS)
    p.add_argument("--workers", type=int, default=int(os.environ.get("CALIB_WORKERS", "16")))
    p.add_argument("--resamples", type=int, default=2000)
    p.add_argument("--tol", type=float, default=float(os.environ.get("SEL_TOL", "0.01")),
                   help="guarded pick: allowed dev CER/WER increase over the final model (0.01 = 1 point)")
    p.add_argument("--out")
    args = p.parse_args(argv)
    if not args.work:
        p.error("--work (or $W) is required")
    res = run(args.work, args.b_pct, parse_groups(args.groups), args.workers, args.resamples, tol=args.tol)
    if not res["groups"]:
        print("no model has dev and test dumps (run 'selectC' first)")
        return 1
    print("\n".join(report(res)))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(res, f, ensure_ascii=False, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
