import json
import os

import numpy as np

from scriptleak import baselines
from tests.test_v25 import _fake_dump
from tests.test_v26 import _mixed_dump


def test_spearman_ci():
    x = np.arange(12, dtype=float)
    r = baselines.spearman_ci(x, x * 2, resamples=500)
    assert r["rho"] > 0.99 and r["p_perm"] < 0.05
    r = baselines.spearman_ci(x, np.random.default_rng(0).permutation(x), resamples=500)
    assert r["ci"][0] < r["rho"] < r["ci"][1]


def test_score(tmp_path, capsys):
    rng = np.random.default_rng(2)
    work = str(tmp_path)
    for l, sh in {"a": 1.0, "a_s1": 0.0}.items():
        for s in ("real_lotus_th", "real_ami_en", "real_amiihm_en"):
            _fake_dump(os.path.join(work, "dumps", f"B20_{l}", s), s, 30, rng, sh)
        _mixed_dump(os.path.join(work, "dumps", f"B20_{l}", "real_lotus_mixed"), 10, rng, sh)
        r = os.path.join(work, "results", f"B20_{l}")
        os.makedirs(r)
        for f in ("heldout.json", "en.json"):
            json.dump({"greedy": {"snr0": {"slr_u": 0.01 * (sh + 1)}}}, open(os.path.join(r, f), "w"))
    with open(os.path.join(work, "lid_voxlingua107.jsonl"), "w") as f:
        for s in ("real_lotus_th", "real_ami_en", "real_amiihm_en"):
            for i in range(30):
                f.write(json.dumps({"audio_filepath": f"/{s}/{i}.wav", "th": 0.0 if s.endswith("en") else 1.0,
                                    "en": 1.0 if s.endswith("en") else 0.0}) + "\n")
    args = type("A", (), {"work": work, "b_pct": "20", "groups": ["A=a,a_s1"], "workers": 2, "out": None})()
    assert baselines.cmd_score(args) == 0
    out = capsys.readouterr().out
    assert "oracle-mask" in out and "lid:voxlingua107" in out
    line = [l for l in out.splitlines() if l.strip().startswith("oracle-mask")][0]
    assert "0.0%" in line          # the oracle cannot leak
    lidline = [l for l in out.splitlines() if l.strip().startswith("lid:voxlingua107")][0]
    assert "100.0%/100.0%" in lidline  # perfect fake identifier
