import json
import os

import numpy as np

from scriptleak import baselines
from scriptleak.singlerun import cand_dir
from tests.test_v25 import _fake_dump
from tests.test_v26 import _mixed_dump


def _args(work, **kw):
    d = {"work": work, "b_pct": "20", "groups": ["A=a,a_s1"], "workers": 2, "out": None,
         "engine": "voxlingua", "prefix_sec": 0.0, "shard": 0, "num_shards": 1}
    d.update(kw)
    return type("A", (), d)()


def test_names_and_merge(tmp_path):
    assert baselines.lid_name("voxlingua", 0) == "voxlingua107"
    assert baselines.lid_name("voxlingua", 2) == "voxlingua107_p2s"
    assert baselines.lid_name("mms", 0) == "mms126"
    w = str(tmp_path)
    for k in range(2):
        with open(os.path.join(w, f"lid_mms126.part{k}.jsonl.tmp"), "w") as f:
            f.write(json.dumps({"audio_filepath": f"/{k}.wav", "th": 0.0, "en": 1.0}) + "\n")
            f.write('{"audio_filepath": "/cut')   # interrupted line
    assert baselines.cmd_merge(_args(w, engine="mms")) == 0
    assert set(baselines.load_lids(w)) == {"mms126"}
    assert len(baselines.load_lids(w)["mms126"]) == 2


def test_score_full(tmp_path, capsys):
    rng = np.random.default_rng(4)
    w = str(tmp_path)
    for l, sh in {"a": 1.0, "a_s1": 0.0}.items():
        for s in ("real_lotus_th", "real_ami_en", "real_amiihm_en"):
            _fake_dump(os.path.join(w, "dumps", f"B20_{l}", s), s, 30, rng, sh)
            _fake_dump(cand_dir(w, "20", l, "epoch030", s), s, 30, rng, sh - 1)
        _mixed_dump(os.path.join(w, "dumps", f"B20_{l}", "real_lotus_mixed"), 10, rng, sh)
    # strata for the per-microphone table
    for l in ("a", "a_s1"):
        p = os.path.join(w, "dumps", f"B20_{l}", "real_lotus_th", "utts.jsonl")
        rows = [json.loads(x) for x in open(p)]
        for i, r in enumerate(rows):
            r["stratum"] = "lotus/lav123" if i % 2 else "lotus/bt10m"
        open(p, "w").write("\n".join(json.dumps(r, ensure_ascii=False) for r in rows))
    for name, en_for_th in (("voxlingua107", False), ("voxlingua107_p1s", True)):
        with open(os.path.join(w, f"lid_{name}.jsonl"), "w") as f:
            for s in ("real_lotus_th", "real_ami_en", "real_amiihm_en"):
                for i in range(30):
                    en = s.endswith("en") or en_for_th
                    f.write(json.dumps({"audio_filepath": f"/{s}/{i}.wav", "th": 0.0 if en else 1.0,
                                        "en": 1.0 if en else 0.0}) + "\n")
    json.dump({"groups": {"A": {"rows": {"one run: guarded pick + lock": {"picks": ["a:epoch030", "a_s1:epoch030"]}}}}},
              open(os.path.join(w, "singlerun_en20.json"), "w"))
    with open(os.path.join(w, "typhoon_lotus_th.jsonl"), "w") as f:
        f.write(json.dumps({"text": "สวัสดี", "pred": "สวัสดี", "stratum": "lotus/lav123"}, ensure_ascii=False) + "\n")
    assert baselines.cmd_score(_args(w)) == 0
    out = capsys.readouterr().out
    assert "lid:voxlingua107_p1s" in out and "per microphone" in out and "lotus/bt10m" in out
    assert "Checkpoint chosen on dev" in out and "Typhoon ASR Realtime" in out
