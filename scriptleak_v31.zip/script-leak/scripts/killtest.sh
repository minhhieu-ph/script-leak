#!/usr/bin/env bash
# The two-week kill test, one stage at a time.
#
#   bash scripts/killtest.sh STAGE
#
# Stages, in order:
#   prepare    corpora -> raw manifests            (needs TEXT_COL)
#   audit      spoken-form filter; STOP and read the Thai hours
#   split      Thai train/dev/test, noisy strata, dialect test sets
#   mix        training manifests (English = 5% and 20% of hours)
#   tokenizer  one SentencePiece model per language
#   train05    train with 5% English                (needs BASE_CONFIG)
#   train20    train with 20% English
#   dump       frame-level log-probabilities for both models
#   results    leakage tables, frame analysis, method sweep
#   probeA     phase A: distortion probes and the span acceptance test
#              (uses the two trained models, no training)
#   noisefloor | prepB | trainB NAME | evalB NAME... | nightB [NAME...]   phase B, see below
#   realprep   real-condition test sets: LOTUSDIS (Thai) and AMI far-field (English); CPU only
#   realB      score every trained model of B_PCT on them, one model per GPU
#   probeC     babble, music, quiet talker, residual leaks (v19; audio on CPU, then GPU)
#   adaptB KIND | nightC [KIND..]   two-stage adaptation (G2b), see "phase C" below
#   marathon   v20: every remaining step in one command (about 20 h), see the end of this file
#   getrir | prepR | marathon2   v23: reverberation augmentation, th seeds, longer adaptation
#   seedC | realdev | selectC     v24: seed overlap + intervals (CPU), averaged weights + dev selection (GPU)
#   calibC                        v25: script-bias calibration on the real dev set, dev size, MUSAN vs real (CPU)
#   ihmC | paretoC                v26: AMI close-talk + mixed dumps (GPU), cost of every fix (CPU)
#   comboC | streamC              v27: dev choice + lock end to end (CPU), real streaming dumps (GPU)
#   singleC                       v28: the proposal with one training run + 95% intervals (CPU)
#   esB [KIND...] | esC           v30: retrain with a real-dev leak monitor every epoch (GPU), report (CPU)
#
# Settings are environment variables, e.g.
#   D=/data/scriptleak TEXT_COL=sentence bash scripts/killtest.sh prepare
# prepare also reads TEXT_COL_CENTRAL, CENTRAL_MAX_HOURS (450, 0 = all),
# PREP_WORKERS (16). It can be re-run after an interruption.
# audit reads TH_KEEP_SPACES (1 = keep Thai word spaces, 0 = remove them).
#
# NOT TESTED where it was written (no data, no GPU there).
set -euo pipefail

D="${D:-/data/scriptleak}"            # where download_data.sh put the corpora
W="${W:-$D/work}"                     # manifests, tokenizers, models, dumps
TEXT_COL="${TEXT_COL:-}"              # transcript column of the Thai datasets
SPEAKER_COL="${SPEAKER_COL:-}"        # speaker column, if the datasets have one
BASE_CONFIG="${BASE_CONFIG:-}"        # a NeMo FastConformer hybrid transducer-CTC BPE yaml
INIT="${INIT:-stt_en_fastconformer_hybrid_large_streaming_multi}"   # INIT=none trains from scratch
GPUS="${GPUS:-8}"
BATCH="${BATCH:-32}"                  # per GPU
EPOCHS="${EPOCHS:-10}"
TH_HOURS="${TH_HOURS:-300}"
DIALECT_TEST_HOURS="${DIALECT_TEST_HOURS:-5}"
DIALECTS="khummuang korat pattani"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"
mkdir -p "$W"
need() { [ -n "${!1}" ] || { echo "Set $1 first. $2"; exit 1; }; }

stage_prepare() {
  need TEXT_COL "Find it with: python -m scriptleak.prepare hf-columns --dataset CMKL/Porjai-Thai-voice-dataset-korat"
  for part in train-clean-100:en_train dev-clean:en_dev test-clean:en_test; do
    python -m scriptleak.prepare librispeech --root "$D/LibriSpeech" \
        --subsets "${part%%:*}" --out "$W/${part##*:}.raw.jsonl"
  done
  local copy=()
  [ -n "$SPEAKER_COL" ] && copy=(--copy-cols "$SPEAKER_COL")
  # The central set may name its transcript column differently from the
  # dialect sets: TEXT_COL_CENTRAL overrides TEXT_COL for it. CENTRAL_MAX_HOURS
  # (default 450) keeps disk use down; the experiments need about 315 clean hours.
  for name in central $DIALECTS; do
    local col="$TEXT_COL" cap=()
    if [ "$name" = central ]; then
      col="${TEXT_COL_CENTRAL:-$TEXT_COL}"
      [ "${CENTRAL_MAX_HOURS:-450}" != 0 ] && cap=(--max-hours "${CENTRAL_MAX_HOURS:-450}")
    fi
    python -m scriptleak.prepare hf --dataset "CMKL/Porjai-Thai-voice-dataset-$name" \
        --split train --text-col "$col" "${copy[@]}" "${cap[@]}" \
        --num-workers "${PREP_WORKERS:-16}" \
        --audio-out "$D/porjai/$name/wav" --out "$W/th_$name.raw.jsonl"
  done
}

stage_audit() {
  local sp=()
  [ "${TH_KEEP_SPACES:-1}" = 1 ] && sp=(--keep-spaces)
  python -m scriptleak.audit --manifest "$W/th_central.raw.jsonl" --lang th "${sp[@]}" \
      --out-manifest "$W/th_central.clean.jsonl" --report "$W/th_central.audit.json"
  for s in en_train en_dev en_test; do
    python -m scriptleak.audit --manifest "$W/$s.raw.jsonl" --lang en \
        --out-manifest "$W/$s.clean.jsonl" --report "$W/$s.audit.json"
  done
  for name in $DIALECTS; do
    python -m scriptleak.audit --manifest "$W/th_$name.raw.jsonl" --lang th "${sp[@]}" \
        --out-manifest "$W/th_$name.clean.jsonl" --report "$W/th_$name.audit.json" \
        --set "stratum=$name"
  done
  echo
  echo "STOP: Thai-central needs at least $((TH_HOURS + 15)) clean hours (see above)."
}

stage_split() {
  # Split by sentence (text_key) unless a speaker column is given: the corpus
  # has each sentence read by several people, and a test sentence must not
  # also be a training sentence.
  local spk=(--speaker-field "${SPEAKER_COL:-text_key}")
  python -m scriptleak.split --manifest "$W/th_central.clean.jsonl" \
      --dev-hours 3 --test-hours 10 "${spk[@]}" --out-prefix "$W/th_central"
  python -m scriptleak.noise --manifest "$W/th_central.test.jsonl" --noise-dir "$D/musan/noise" \
      --snrs 10 5 0 --out-dir "$D/th_test_noisy" --out-manifest "$W/th_test.strata.jsonl"
  for name in $DIALECTS; do
    python -m scriptleak.split --manifest "$W/th_$name.clean.jsonl" \
        --dev-hours 0 --test-hours "$DIALECT_TEST_HOURS" "${spk[@]}" --out-prefix "$W/th_$name"
    cat "$W/th_$name.test.jsonl" >> "$W/th_test.strata.jsonl"
  done
  echo "Thai test set with strata: $W/th_test.strata.jsonl"
}

stage_mix() {
  for pct in 05 20; do
    python -m scriptleak.mix --majority "$W/th_central.train.jsonl" --minority "$W/en_train.clean.jsonl" \
        --majority-hours "$TH_HOURS" --minority-fraction "0.$pct" --seed 0 \
        --out "$W/train_th${TH_HOURS}_en$pct.jsonl"
  done
}

stage_tokenizer() {
  python -m scriptleak.nemo_tools.build_tokenizer --manifest "$W/th_central.train.jsonl" \
      --out-dir "$W/tokenizers/th_bpe1024" --vocab-size 1024
  python -m scriptleak.nemo_tools.build_tokenizer --manifest "$W/en_train.clean.jsonl" \
      --out-dir "$W/tokenizers/en_bpe256" --vocab-size 256
}

train_one() {  # train_one PCT
  need BASE_CONFIG "Pick one of the yaml files printed by scripts/setup_env.sh (step 4)."
  local init=()
  [ "$INIT" != "none" ] && init=(--init-pretrained "$INIT")
  python -m scriptleak.nemo_tools.train --base-config "$BASE_CONFIG" \
      --train-manifest "$W/train_th${TH_HOURS}_en$1.jsonl" \
      --val-manifest "$W/th_central.dev.jsonl" "$W/en_dev.clean.jsonl" \
      --tokenizer "th=$W/tokenizers/th_bpe1024" "en=$W/tokenizers/en_bpe256" \
      "${init[@]}" --exp-dir "$W/exp/th${TH_HOURS}_en$1" \
      --max-epochs "$EPOCHS" --batch-size "$BATCH" --num-workers 8 --devices "$GPUS"
}

stage_dump() {
  for pct in 05 20; do
    local m="$W/exp/th${TH_HOURS}_en$pct"
    CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs --model "$m/final.nemo" \
        --manifest "$W/th_test.strata.jsonl" --out "$W/dumps/en$pct/th_test" --transducer
    CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs --model "$m/final.nemo" \
        --manifest "$W/en_test.clean.jsonl" --out "$W/dumps/en$pct/en_test" --transducer
  done
}

stage_results() {
  for pct in 05 20; do
    local dd="$W/dumps/en$pct" r="$W/results/en$pct"
    mkdir -p "$r"
    echo "################ English = $pct% of training hours ################"
    echo "--- 1. Is there leakage, and does it grow with difficulty? (CTC head)"
    python -m scriptleak.sweep --dump "$dd/th_test" --majority th --minority en --spoken th \
        --group-by stratum --methods greedy --out "$r/leak_ctc.json" || echo "!! this step failed; continuing"
    echo "--- 2. Same question for the transducer head"
    python -m scriptleak.evaluate --manifest "$dd/th_test/utts.jsonl" --majority th --minority en \
        --hyp-field pred_transducer --group-by stratum --out "$r/leak_transducer.json" || echo "!! this step failed; continuing"
    echo "--- 3. Why: frame analysis"
    python -m scriptleak.analysis --dump "$dd/th_test" --majority th --minority en \
        --group-by stratum --out "$r/frames.json" || echo "!! this step failed; continuing"
    echo "--- 4. Methods on Thai speech"
    python -m scriptleak.sweep --dump "$dd/th_test" --majority th --minority en --spoken th \
        --out "$r/sweep_th.json" || echo "!! this step failed; continuing"
    echo "--- 5. What each method costs English"
    python -m scriptleak.sweep --dump "$dd/en_test" --majority th --minority en --spoken en \
        --out "$r/sweep_en.json" || echo "!! this step failed; continuing"
  done 2>&1 | tee "$W/results_summary.txt"
  echo "Summary saved to $W/results_summary.txt"
}

stage_probeA() {
  # Phase A: probes on the two trained models, no training.
  #   PROBE_UTTS (2000) clean Thai test utterances are distorted in 8 ways.
  local P="$W/probeA"
  mkdir -p "$P"
  if [ ! -s "$P/th_probes.jsonl" ] || [ ! -s "$P/nonspeech.jsonl" ]; then
    python -m scriptleak.probes --manifest "$W/th_central.test.jsonl" --noise-dir "$D/musan/noise" \
        --out-dir "$D/probeA_audio" --out-manifest "$P/th_probes.jsonl" \
        --out-nonspeech "$P/nonspeech.jsonl" --max-utts "${PROBE_UTTS:-2000}"
  fi
  if [ ! -s "$P/en_strata.jsonl" ]; then
    python -m scriptleak.noise --manifest "$W/en_test.clean.jsonl" --noise-dir "$D/musan/noise" \
        --snrs 10 5 0 --out-dir "$D/en_test_noisy" --out-manifest "$P/en_strata.jsonl"
  fi
  for pct in 05 20; do
    for set in th_probes nonspeech en_strata; do
      local out="$W/dumps/en$pct/$set"
      if [ ! -s "$out/meta.json" ] || [ ! -s "$out/utts.jsonl" ]; then
        CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs \
            --model "$W/exp/th${TH_HOURS}_en$pct/final.nemo" --manifest "$P/$set.jsonl" --out "$out"
      fi
    done
  done
  for pct in 05 20; do
    local dd="$W/dumps/en$pct" r="$W/results/en$pct"
    mkdir -p "$r"
    echo "################ English = $pct% of training hours ################"
    echo "--- A1. Which distortions make Thai speech leak? (CTC head)"
    python -m scriptleak.sweep --dump "$dd/th_probes" --majority th --minority en --spoken th \
        --group-by stratum --methods greedy --out "$r/probes_th.json" || echo "!! this step failed; continuing"
    echo "--- A2. No speech at all: what does the model write?"
    python -m scriptleak.nonspeech --manifest "$dd/nonspeech/utts.jsonl" --majority th --minority en \
        --out "$r/nonspeech.json" || echo "!! this step failed; continuing"
    echo "--- A3. Noisy English: is the error symmetric?"
    python -m scriptleak.sweep --dump "$dd/en_strata" --majority th --minority en --spoken en \
        --group-by stratum --methods greedy --out "$r/probes_en.json" || echo "!! this step failed; continuing"
    echo "--- A4. Can leaked spans be told from real English spans?"
    python -m scriptleak.spans --majority th --minority en \
        --leak-dump "$dd/th_test" "$dd/th_probes" --genuine-dump "$dd/en_strata" \
        --majority-text "$W/th_central.train.jsonl" --minority-text "$W/en_train.clean.jsonl" \
        --out "$r/spans.json" || echo "!! this step failed; continuing"
  done 2>&1 | tee "$W/probeA_summary.txt"
  echo "Summary saved to $W/probeA_summary.txt"
}

# ---------------------------------------------------------------- phase B
# Causal experiments. All start from the mix with B_PCT% English (default 20).
#   noisefloor          acoustic condition of each training block (minutes, CPU)
#   prepB               noisy training copies + held-out test manifests
#   trainB KIND         KIND = both | en | th   noise on both / English / Thai blocks
#                              clean            no noise (a replicate of the clean model)
#                              noinit           no noise, encoder not initialised
#   evalB KIND [KIND..] dump + tables; KIND as above, or base (the clean model of phase A)
#   nightB [KIND..]     prepB, trainB for each KIND, evalB base + KINDs
# Settings that change a model's name (so runs never overwrite each other):
#   B_PCT     English share of training hours                 20  -> B20_...
#   AUG_PROB  share of utterances of a noisy block given noise 0.5 -> (nothing); 0.1 -> p10_
#   SEED      training seed                                   0   -> (nothing); 1 -> _s1
# e.g. B_PCT=20 AUG_PROB=0.1 SEED=1, KIND th  ->  exp/B20_p10_th_s1
B_PCT="${B_PCT:-20}"
AUG_PROB="${AUG_PROB:-0.5}"
SEED="${SEED:-0}"
B_EPOCHS="${B_EPOCHS:-50}"
SAVE_EVERY="${SAVE_EVERY:-5}"
PTAG="$(python -c "p=float('$AUG_PROB'); print('' if abs(p-0.5)<1e-9 else 'p%02d' % round(p*100))")"
AT="B${B_PCT}${PTAG:+_$PTAG}"           # names of the augmented training manifests

_label() {  # KIND -> label used in exp/, dumps/, results/ (after "B<pct>_")
  local kind="$1" sfx=""
  [ "$SEED" != 0 ] && sfx="_s$SEED"
  case "$kind" in
    base)         echo "base" ;;
    both|en|th)   echo "${PTAG:+${PTAG}_}$kind$sfx" ;;
    adrm_all|adrm_enc|adim_all|adim_enc)
                  local et=""; [ "${ADAPT_EPOCHS:-5}" != 5 ] && et="_e${ADAPT_EPOCHS}"
                  echo "${PTAG:+${PTAG}_}$kind$et$sfx" ;;
    rir)          echo "${PTAG:+${PTAG}_}rir$sfx" ;;
    clean|noinit) echo "$kind$sfx" ;;
    *) echo "unknown kind '$kind' (use base|clean|noinit|both|en|th|rir|adrm_all|adrm_enc|adim_all|adim_enc)" >&2; return 1 ;;
  esac
}

_model_dir() {  # KIND -> directory holding final.nemo
  if [ "$1" = base ]; then echo "$W/exp/th${TH_HOURS}_en${B_PCT}"; else echo "$W/exp/B${B_PCT}_$(_label "$1")"; fi
}

stage_noisefloor() {
  python -m scriptleak.noisefloor --manifest "th=$W/th_central.train.jsonl" "en=$W/en_train.clean.jsonl"
}

stage_prepB() {
  local base="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl"
  # The noisy audio of a lower AUG_PROB is a subset of that of a higher one (same
  # draws per utterance), so every AUG_PROB shares one audio directory.
  python -m scriptleak.augment make --manifest "$base" --noise-dir "$D/musan/noise" \
      --out-dir "$D/aug/en${B_PCT}" --out "$W/${AT}.aug.jsonl" \
      --prob "$AUG_PROB" --snr-min "${AUG_SNR_MIN:-0}" --snr-max "${AUG_SNR_MAX:-20}" \
      --num-workers "${PREP_WORKERS:-16}"
  python -m scriptleak.augment select --manifest "$W/${AT}.aug.jsonl" --langs th en --out "$W/${AT}_aug-both.jsonl"
  python -m scriptleak.augment select --manifest "$W/${AT}.aug.jsonl" --langs en    --out "$W/${AT}_aug-en.jsonl"
  python -m scriptleak.augment select --manifest "$W/${AT}.aug.jsonl" --langs th    --out "$W/${AT}_aug-th.jsonl"
  python -m scriptleak.augment filter-heldout --manifest "$W/th_test.strata.jsonl" --out "$W/th_test.heldout.jsonl"
  # the curve set: clean + held-out noise only, no dialects (small, so every snapshot can be scored)
  python - "$W/th_test.heldout.jsonl" "$W/th_curve.jsonl" <<'PY'
import json, sys
keep = [l for l in open(sys.argv[1], encoding="utf-8")
        if l.strip() and (json.loads(l).get("stratum") == "clean" or str(json.loads(l).get("stratum", "")).startswith("snr"))]
open(sys.argv[2], "w", encoding="utf-8").writelines(keep)
print(f"curve set: {len(keep)} utterances")
PY
  if [ -s "$W/probeA/en_strata.jsonl" ]; then
    python -m scriptleak.augment filter-heldout --manifest "$W/probeA/en_strata.jsonl" --out "$W/en_test.heldout.jsonl"
  else
    echo "NOTE: run 'probeA' first to get the noisy English test set"
  fi
}

stage_trainB() {  # stage_trainB KIND
  need BASE_CONFIG "Pick one of the yaml files printed by scripts/setup_env.sh (step 4)."
  local kind="${1:-}" manifest init=() label m
  [ "$INIT" != "none" ] && init=(--init-pretrained "$INIT")
  case "$kind" in
    both|en|th) manifest="$W/${AT}_aug-$kind.jsonl" ;;
    rir)        manifest="$W/${AT}_rir-both.jsonl" ;;
    clean)      manifest="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl" ;;
    noinit)     manifest="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl"; init=() ;;
    *) echo "usage: killtest.sh trainB both|en|th|rir|clean|noinit"; exit 1 ;;
  esac
  [ -s "$manifest" ] || { echo "missing $manifest: run 'prepB' first"; exit 1; }
  label="$(_label "$kind")"; m="$(_model_dir "$kind")"
  if [ -s "$m/final.nemo" ]; then
    echo "$m/final.nemo exists: training of B${B_PCT}_$label skipped"; return 0
  fi
  echo "training B${B_PCT}_$label from $(basename "$manifest") (seed $SEED)"
  python -m scriptleak.nemo_tools.train --base-config "$BASE_CONFIG" \
      --train-manifest "$manifest" \
      --val-manifest "$W/th_central.dev.jsonl" "$W/en_dev.clean.jsonl" \
      --tokenizer "th=$W/tokenizers/th_bpe1024" "en=$W/tokenizers/en_bpe256" \
      ${init[@]+"${init[@]}"} --exp-dir "$m" --save-every-epochs "$SAVE_EVERY" --seed "$SEED" \
      --max-epochs "$B_EPOCHS" --batch-size "$BATCH" --num-workers 8 --devices "$GPUS"
}

_dump_if_missing() {  # MODEL MANIFEST OUT
  if [ ! -s "$3/meta.json" ] || [ ! -s "$3/utts.jsonl" ]; then
    CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.dump_logprobs --model "$1" --manifest "$2" --out "$3"
  fi
}

_compare_all() {  # FILE_NAME [extra compare args]: one row per evaluated model of this B_PCT
  local fname="$1"; shift
  local all=() f n
  for f in "$W"/results/B${B_PCT}_*/"$fname"; do
    [ -e "$f" ] || continue
    n="$(basename "$(dirname "$f")")"; all+=("${n#B${B_PCT}_}=$f")
  done
  [ ${#all[@]} -gt 0 ] && python -m scriptleak.compare "$@" "${all[@]}" || true
}

_run_jobs() {  # TAG JOB...: JOB = "MODEL|MANIFEST|OUT[|EXTRA ARGS]"; one GPU per worker
  local tag="$1"; shift
  local jobs=("$@") ngpu="${REAL_GPUS:-$GPUS}" g logs="$W/logs"
  [ ${#jobs[@]} -gt 0 ] || return 0
  mkdir -p "$logs"
  echo "   ${#jobs[@]} dumps on $ngpu GPUs; logs: $logs/${tag}_gpu<N>.log  ($(date +%H:%M))"
  for ((g = 0; g < ngpu; g++)); do
    (
      local i mm man out extra
      for ((i = g; i < ${#jobs[@]}; i += ngpu)); do
        IFS='|' read -r mm man out extra <<< "${jobs[$i]}"
        CUDA_VISIBLE_DEVICES=$g python -m "${DUMP_TOOL:-scriptleak.nemo_tools.dump_logprobs}" --model "$mm" \
            --manifest "$man" --out "$out" $extra >> "$logs/${tag}_gpu$g.log" 2>&1 \
          || echo "!! dump failed: $(basename "$(dirname "$out")")/$(basename "$out") (see $logs/${tag}_gpu$g.log)"
      done
    ) &
  done
  wait
  echo "   dumps done  ($(date +%H:%M))"
}

_need_dump() { [ ! -s "$1/meta.json" ] || [ ! -s "$1/utts.jsonl" ]; }

stage_evalB() {  # stage_evalB KIND [KIND ...]
  [ $# -ge 1 ] || { echo "usage: killtest.sh evalB base|clean|noinit|both|en|th|adrm_all|... [...]"; exit 1; }
  local kind label m dd labels=() models=() jobs=() snap ep
  for kind in "$@"; do
    label="$(_label "$kind")" || continue
    m="$(_model_dir "$kind")"
    [ -s "$m/final.nemo" ] || { echo "!! $m/final.nemo not found; skipping $label"; continue; }
    labels+=("$label"); models+=("$m")
    dd="$W/dumps/B${B_PCT}_$label"
    _need_dump "$dd/heldout" && jobs+=("$m/final.nemo|$W/th_test.heldout.jsonl|$dd/heldout")
    [ -s "$W/probeA/th_probes.jsonl" ] && _need_dump "$dd/probes" && jobs+=("$m/final.nemo|$W/probeA/th_probes.jsonl|$dd/probes")
    [ -s "$W/en_test.heldout.jsonl" ] && _need_dump "$dd/en" && jobs+=("$m/final.nemo|$W/en_test.heldout.jsonl|$dd/en")
    for snap in "$m"/epoch*.nemo; do
      [ -e "$snap" ] || continue
      ep="$(basename "$snap" .nemo)"
      _need_dump "$dd/curve_$ep" && jobs+=("$snap|$W/th_curve.jsonl|$dd/curve_$ep")
      [ -s "$W/en_test.heldout.jsonl" ] && _need_dump "$dd/curve_en_$ep" && jobs+=("$snap|$W/en_test.heldout.jsonl|$dd/curve_en_$ep")
    done
  done
  echo "== evalB: ${labels[*]}"
  _run_jobs evalB "${jobs[@]+"${jobs[@]}"}"
  local i r f
  for ((i = 0; i < ${#labels[@]}; i++)); do
    label="${labels[$i]}"; dd="$W/dumps/B${B_PCT}_$label"; r="$W/results/B${B_PCT}_$label"; mkdir -p "$r"
    _score() {  # DUMP SPOKEN OUT
      [ -s "$1/utts.jsonl" ] || return 0
      [ -s "$3" ] && [ "$3" -nt "$1/utts.jsonl" ] && return 0
      python -m scriptleak.sweep --dump "$1" --majority th --minority en --spoken "$2" \
          --group-by stratum --methods greedy --out "$3" > /dev/null || echo "!! scoring $(basename "$1") failed for $label"
    }
    _score "$dd/heldout" th "$r/heldout.json"
    _score "$dd/probes" th "$r/probes.json"
    _score "$dd/en" en "$r/en.json"
    for f in "$dd"/curve_epoch*; do
      [ -d "$f" ] || continue
      ep="${f##*/curve_}"
      _score "$f" th "$r/curve_$ep.json"
      _score "$dd/curve_en_$ep" en "$r/curve_en_$ep.json"
    done
  done
  {
    echo "################ Phase B, English = ${B_PCT}% of hours: Thai test, held-out noise (leak rate / CER) ################"
    _compare_all heldout.json
    echo; echo "################ Distortions never used in training (leak rate / CER) ################"
    _compare_all probes.json
    echo; echo "################ English test (Thai-script rate / WER) ################"
    _compare_all en.json --error wer
    echo; echo "################ Both directions at once (final models) ################"
    local all=() n
    for f in "$W"/results/B${B_PCT}_*/heldout.json; do
      [ -e "$f" ] || continue
      n="$(basename "$(dirname "$f")")"; all+=("${n#B${B_PCT}_}=$f,$(dirname "$f")/en.json")
    done
    [ ${#all[@]} -gt 0 ] && python -m scriptleak.twoway "${all[@]}"
    local l
    for l in ${labels[@]+"${labels[@]}"}; do
      r="$W/results/B${B_PCT}_$l"; all=()
      for f in "$r"/curve_epoch*.json; do
        [ -e "$f" ] || continue
        ep="$(basename "$f" .json)"; ep="${ep#curve_}"
        all+=("$ep=$f,$r/curve_en_$ep.json")
      done
      [ ${#all[@]} -gt 0 ] || continue
      [ -e "$r/heldout.json" ] && all+=("final=$r/heldout.json,$r/en.json")
      echo; echo "################ $l during training, both directions ################"
      python -m scriptleak.twoway "${all[@]}"
    done
  } 2>&1 | tee "$W/phaseB_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/phaseB_en${B_PCT}_summary.txt"
}

stage_nightB() {  # prepB, then train every KIND given (default: both noinit), then evalB base + KINDs
  local kinds=("$@")
  [ ${#kinds[@]} -gt 0 ] || kinds=(both noinit)
  echo "== nightB, English = ${B_PCT}%, AUG_PROB = ${AUG_PROB}, seed = ${SEED}: ${kinds[*]}  ($(date))"
  stage_prepB
  local k
  for k in "${kinds[@]}"; do [ "$k" = rir ] && stage_prepR; done
  for k in "${kinds[@]}"; do
    echo "== training B${B_PCT}_$(_label "$k")  ($(date))"
    ( stage_trainB "$k" ) 2>&1 | tee "$W/train_B${B_PCT}_$(_label "$k").log" || echo "!! training $k failed; continuing"
  done
  echo "== evaluation  ($(date))"
  stage_evalB base "${kinds[@]}"
  echo "== nightB done  ($(date))"
}

# ---------------------------------------------------------------- real noise (v17)
# Phase B used MUSAN noise in training and test. These sets were recorded in
# real conditions. realprep needs no GPU and can run while a model trains;
# realB needs the GPUs and refuses to start while another job is using them.
#   LOTUS_FRAC   share of LOTUSDIS test segments kept (same segments for every mic)  0.35
#   AMI_FRAC     share of AMI eval segments kept (far-field English, v21)              0.5
#   WITH_GS2     1 = also try the gated GigaSpeech 2 Thai test                          0
#   REAL_MODELS  labels to score, e.g. "base both p10_th"   (default: every model of B_PCT)
#   REAL_SKIP    regex of labels to leave out                (default: noinit)
#   REAL_GPUS    GPUs used by realB                          (default: GPUS)
#   REAL_BATCH   utterances per batch when dumping           (default: 16)
R="$W/real"

stage_realprep() {
  mkdir -p "$R"
  local lotus_raw="$R/lotus_test.raw.jsonl" gs2_raw="$R/gs2_test.raw.jsonl"
  echo "== LOTUSDIS test split (about 1.6 GB from Hugging Face)  ($(date))"
  if [ ! -s "$lotus_raw" ]; then
    python -m scriptleak.prepare hf --dataset nectec/LOTUSDIS --split test --data-files "data/test-*" \
        --text-col sentence --copy-cols speaker_id mic --num-workers "${PREP_WORKERS:-8}" \
        --audio-out "$D/lotusdis/test/wav" --out "$lotus_raw" || echo "!! LOTUSDIS failed; continuing"
  fi
  if [ -s "$lotus_raw" ]; then
    python -m scriptleak.real build --manifest "$lotus_raw" --name lotus --stratum-field mic \
        --keep-frac "${LOTUS_FRAC:-0.35}" --out-thai "$R/lotus.th.jsonl" --out-mixed "$R/lotus.mixed.jsonl" \
        --report "$R/lotus.build.json" --strata-dir "$R/strata"
  fi
  if [ "${WITH_GS2:-0}" = 1 ]; then
    echo "== GigaSpeech 2 Thai test (gated)  ($(date))"
    if [ ! -s "$gs2_raw" ]; then
      if python -m scriptleak.real fetch-gs2 --out-dir "$D/gigaspeech2"; then
        python -m scriptleak.prepare gigaspeech2 --tsv "$D/gigaspeech2/data/th/test.tsv" \
            --audio-dir "$D/gigaspeech2/data/th/test" --out "$gs2_raw" || echo "!! GigaSpeech 2 manifest failed"
      else
        echo "!! GigaSpeech 2 skipped (see the message above)."
      fi
    fi
    if [ -s "$gs2_raw" ]; then
      python -m scriptleak.real build --manifest "$gs2_raw" --name gs2 --group-fields utt_id \
          --out-thai "$R/gs2.th.jsonl" --out-mixed "$R/gs2.mixed.jsonl" \
          --report "$R/gs2.build.json" --strata-dir "$R/strata"
    fi
  fi
  echo "== AMI meetings, far-field single microphone, eval split (real noisy English)  ($(date))"
  local ami_raw="$R/ami_eval.raw.jsonl"
  if [ ! -s "$ami_raw" ]; then
    python -m scriptleak.real ami --out-dir "$D/ami" --split eval --mic sdm --num-workers "${PREP_WORKERS:-8}" --out "$ami_raw" \
      || echo "!! AMI download failed; continuing"
  fi
  if [ -s "$ami_raw" ]; then
    python -m scriptleak.real build-en --manifest "$ami_raw" --name ami --keep-frac "${AMI_FRAC:-0.5}" \
        --out "$R/ami.en.jsonl" --report "$R/ami.build.json" --strata-dir "$R/strata"
  fi
  echo "== Acoustic condition: training blocks vs real test sets  ($(date))"
  local items=("th_train=$W/th_central.train.jsonl" "en_train=$W/en_train.clean.jsonl") f
  for f in "$R"/strata/*.jsonl; do [ -e "$f" ] && items+=("$(basename "$f" .jsonl)=$f"); done
  python -m scriptleak.noisefloor --manifest "${items[@]}" --sample 500 || echo "!! noisefloor failed"
  echo "== realprep done  ($(date))"
}

_find_models() {  # prints "label<TAB>model" for every model to score (MODELS / SKIP, or REAL_MODELS / REAL_SKIP)
  local m l list="${MODELS:-${REAL_MODELS:-}}" skip="${SKIP:-${REAL_SKIP:-noinit}}"
  if [ -n "$list" ]; then
    for l in $list; do
      if [ "$l" = base ]; then m="$W/exp/th${TH_HOURS}_en${B_PCT}/final.nemo"; else m="$W/exp/B${B_PCT}_$l/final.nemo"; fi
      if [ -s "$m" ]; then printf '%s\t%s\n' "$l" "$m"; else echo "!! $m not found; skipping $l" >&2; fi
    done
    return 0
  fi
  m="$W/exp/th${TH_HOURS}_en${B_PCT}/final.nemo"
  [ -s "$m" ] && printf 'base\t%s\n' "$m"
  for m in "$W"/exp/B${B_PCT}_*/final.nemo; do
    [ -e "$m" ] || continue
    l="$(basename "$(dirname "$m")")"; l="${l#B${B_PCT}_}"
    [[ "$l" =~ $skip ]] && continue
    printf '%s\t%s\n' "$l" "$m"
  done
}

_real_sets() {  # sets that realprep produced, as DIRNAME=MANIFEST
  local s
  for s in lotus.th lotus.mixed gs2.th gs2.mixed ami.en; do
    [ -s "$R/$s.jsonl" ] && echo "real_${s/./_}=$R/$s.jsonl"
  done
  return 0
}

_gpus_free() {  # refuses (exit 1) while another process uses the GPUs, unless FORCE=1
  local busy
  busy="$(nvidia-smi --query-compute-apps=pid --format=csv,noheader 2>/dev/null | grep -c . || true)"
  if [ "${busy:-0}" -gt 0 ] && [ "${FORCE:-${REAL_FORCE:-0}}" != 1 ]; then
    echo "!! $busy process(es) are using the GPUs (training still running?). Run this when they finish,"
    echo "   or set FORCE=1 if you are sure."
    exit 1
  fi
}

PD_LABELS=(); PD_MODELS=()
_load_models() {  # fills PD_LABELS / PD_MODELS from _find_models
  PD_LABELS=(); PD_MODELS=()
  local l m
  while IFS=$'\t' read -r l m; do PD_LABELS+=("$l"); PD_MODELS+=("$m"); done < <(_find_models)
  [ ${#PD_LABELS[@]} -gt 0 ] || { echo "no trained model of B_PCT=$B_PCT found"; exit 1; }
}

_parallel_dump() {  # TAG DIR=MANIFEST...: dump every set for every model in PD_LABELS, one model per GPU
  local tag="$1"; shift
  local ngpu="${REAL_GPUS:-$GPUS}" g i logs="$W/logs"
  mkdir -p "$logs"
  echo "   ${#PD_LABELS[@]} models (${PD_LABELS[*]}) on $ngpu GPUs; logs: $logs/${tag}_B${B_PCT}_<model>.log  ($(date))"
  for ((g = 0; g < ngpu; g++)); do
    (
      for ((i = g; i < ${#PD_LABELS[@]}; i += ngpu)); do
        local dd="$W/dumps/B${B_PCT}_${PD_LABELS[$i]}" item
        for item in "$@"; do
          local sn="${item%%=*}" man="${item#*=}"
          if [ ! -s "$dd/$sn/meta.json" ] || [ ! -s "$dd/$sn/utts.jsonl" ]; then
            CUDA_VISIBLE_DEVICES=$g python -m scriptleak.nemo_tools.dump_logprobs --model "${PD_MODELS[$i]}" \
                --manifest "$man" --out "$dd/$sn" --transducer --batch-size "${REAL_BATCH:-16}" \
                >> "$logs/${tag}_B${B_PCT}_${PD_LABELS[$i]}.log" 2>&1 \
              || echo "!! dump ${PD_LABELS[$i]} / $sn failed (see its log)"
          fi
        done
        echo "   done: ${PD_LABELS[$i]}  ($(date +%H:%M))"
      done
    ) &
  done
  wait
}

_compare_files() {  # FILE_NAME CMD...: CMD NAME=PATH... over every model of this B_PCT that has FILE_NAME
  local fname="$1"; shift
  local all=() f n
  for f in "$W"/results/B${B_PCT}_*/"$fname"; do
    [ -e "$f" ] || continue
    n="$(basename "$(dirname "$f")")"; all+=("${n#B${B_PCT}_}=$f")
  done
  [ ${#all[@]} -gt 0 ] && "$@" "${all[@]}" || true
}

stage_realB() {
  _gpus_free
  local sets=() line
  while read -r line; do [ -n "$line" ] && sets+=("$line"); done < <(_real_sets)
  [ ${#sets[@]} -gt 0 ] || { echo "no real test set found; run realprep first"; exit 1; }
  _load_models
  echo "== realB, English = ${B_PCT}%: ${sets[*]}"
  _parallel_dump realB "${sets[@]}"
  echo "== scoring  ($(date))"
  local i
  for ((i = 0; i < ${#PD_LABELS[@]}; i++)); do
    local dd="$W/dumps/B${B_PCT}_${PD_LABELS[$i]}" r="$W/results/B${B_PCT}_${PD_LABELS[$i]}" sn
    mkdir -p "$r"
    for sn in lotus_th gs2_th; do
      [ -s "$dd/real_$sn/utts.jsonl" ] || continue
      python -m scriptleak.sweep --dump "$dd/real_$sn" --majority th --minority en --spoken th \
          --group-by stratum --methods greedy --out "$r/real_$sn.json" > /dev/null || echo "!! $sn failed for ${PD_LABELS[$i]}"
      python -m scriptleak.evaluate --manifest "$dd/real_$sn/utts.jsonl" --majority th --minority en \
          --hyp-field pred_transducer --group-by stratum --out "$r/real_${sn}_rnnt.json" > /dev/null \
        || echo "!! $sn transducer scoring failed for ${PD_LABELS[$i]}"
    done
    if [ -s "$dd/real_ami_en/utts.jsonl" ]; then
      python -m scriptleak.sweep --dump "$dd/real_ami_en" --majority th --minority en --spoken en \
          --group-by stratum --methods greedy --out "$r/real_ami_en.json" > /dev/null || echo "!! ami_en failed for ${PD_LABELS[$i]}"
      python -m scriptleak.evaluate --manifest "$dd/real_ami_en/utts.jsonl" --majority en --minority th \
          --hyp-field pred_transducer --group-by stratum --out "$r/real_ami_en_rnnt.json" > /dev/null \
        || echo "!! ami_en transducer scoring failed for ${PD_LABELS[$i]}"
    fi
    for sn in lotus_mixed gs2_mixed; do
      [ -s "$dd/real_$sn/utts.jsonl" ] || continue
      python -m scriptleak.retention score --manifest "$dd/real_$sn/utts.jsonl" --group-by stratum \
          --out "$r/real_$sn.json" > /dev/null || echo "!! $sn retention failed for ${PD_LABELS[$i]}"
    done
  done
  {
    local sn head
    for sn in lotus_th gs2_th; do
      compgen -G "$W/results/B${B_PCT}_*/real_$sn.json" > /dev/null || continue
      case "$sn" in lotus_th) head="LOTUSDIS far-field meetings, per microphone" ;; *) head="GigaSpeech 2 test (YouTube)" ;; esac
      echo "################ $head, English = ${B_PCT}%: CTC head (leak rate / CER) ################"
      _compare_all "real_$sn.json"
      echo; echo "################ $head: transducer head (leak rate / CER) ################"
      _compare_all "real_${sn}_rnnt.json"
      echo
    done
    for sn in lotus_mixed gs2_mixed; do
      compgen -G "$W/results/B${B_PCT}_*/real_$sn.json" > /dev/null || continue
      echo "################ $sn: English words that really are in the Thai reference ################"
      _compare_files "real_$sn.json" python -m scriptleak.retention table
      echo
    done
    if compgen -G "$W/results/B${B_PCT}_*/real_ami_en.json" > /dev/null; then
      echo "################ AMI meetings, far-field English, English = ${B_PCT}%: CTC head (Thai-script rate / WER) ################"
      _compare_all real_ami_en.json --error wer
      echo; echo "################ AMI: transducer head (Thai-script rate / WER) ################"
      _compare_all real_ami_en_rnnt.json --error wer
      echo; echo "################ Real audio, both directions: LOTUSDIS Thai -> Latin / AMI English -> Thai (CTC) ################"
      local all=() f n
      for f in "$W"/results/B${B_PCT}_*/real_lotus_th.json; do
        [ -e "$f" ] || continue
        n="$(basename "$(dirname "$f")")"; all+=("${n#B${B_PCT}_}=$f,$(dirname "$f")/real_ami_en.json")
      done
      [ ${#all[@]} -gt 0 ] && python -m scriptleak.twoway "${all[@]}" --strata ALL
      echo
    fi
    echo "################ Leakage taken apart (empty outputs, hardness, duration) ################"
    [ -n "$(ls "$W"/dumps/B${B_PCT}_*/real_lotus_th/utts.jsonl 2>/dev/null)" ] && \
      python -m scriptleak.realdiag --work "$W" --b-pct "$B_PCT" --set real_lotus_th --spoken th --ref th \
          --out "$W/realdiag_lotus_en${B_PCT}.json"
    [ -n "$(ls "$W"/dumps/B${B_PCT}_*/real_ami_en/utts.jsonl 2>/dev/null)" ] && \
      python -m scriptleak.realdiag --work "$W" --b-pct "$B_PCT" --set real_ami_en --spoken en --ref en \
          --out "$W/realdiag_ami_en${B_PCT}.json"
    true
  } 2>&1 | tee "$W/real_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/real_en${B_PCT}_summary.txt"
}

# ---------------------------------------------------------------- phase C (v19)
# Hypotheses phase A could not settle. No training in probeC; adaptB trains.
#   probeC          babble (Thai / multilingual), music, quiet talker over a steady background,
#                   with and without speech; and why the balanced model still leaks a little
#                   (H1 as a side mechanism, CTC vs transducer). The audio is made first (CPU,
#                   can run during training); the GPU part refuses while the GPUs are busy.
#   adaptB KIND     G2b: is a shortcut from a long first stage removed by a short second stage?
#                   adrm_all  adrm_enc   start from the leaking model, adapt on balanced noise
#                   adim_all  adim_enc   start from the balanced model, adapt on the plain mix
#                   _all keeps the whole model, _enc only the encoder (decoders start fresh).
#   nightC [KIND..] adaptB for each KIND (default all four), then evalB base both + KINDs.
#   ADAPT_EPOCHS (5), ADAPT_LR (1e-4, fixed: no warm-up), PROBE_UTTS (1000),
#   RESID_MODELS ("base both p10_both": models for the residual-leak analysis)
stage_probeC() {
  local P="$W/probeC"
  mkdir -p "$P"
  if [ ! -s "$P/th_probes.jsonl" ] || [ ! -s "$P/nonspeech.jsonl" ]; then
    echo "== making probe audio  ($(date))"
    python -m scriptleak.probes2 --manifest "$W/th_central.test.jsonl" --musan-dir "$D/musan" \
        --out-dir "$D/probeC_audio" --out-manifest "$P/th_probes.jsonl" --out-nonspeech "$P/nonspeech.jsonl" \
        --max-utts "${PROBE_UTTS:-1000}"
  fi
  _gpus_free
  _load_models
  echo "== probeC, English = ${B_PCT}%"
  _parallel_dump probeC "probeC_th=$P/th_probes.jsonl" "probeC_ns=$P/nonspeech.jsonl"
  # residual leaks: the held-out test set again, with both heads, for a few models only
  local keep_l=() keep_m=() i l
  for ((i = 0; i < ${#PD_LABELS[@]}; i++)); do
    for l in ${RESID_MODELS:-base both p10_both}; do
      [ "${PD_LABELS[$i]}" = "$l" ] && { keep_l+=("$l"); keep_m+=("${PD_MODELS[$i]}"); }
    done
  done
  if [ ${#keep_l[@]} -gt 0 ] && [ -s "$W/th_test.heldout.jsonl" ]; then
    PD_LABELS=("${keep_l[@]}"); PD_MODELS=("${keep_m[@]}")
    _parallel_dump resid "heldout_rnnt=$W/th_test.heldout.jsonl"
  fi
  _load_models
  echo "== scoring  ($(date))"
  for ((i = 0; i < ${#PD_LABELS[@]}; i++)); do
    local dd="$W/dumps/B${B_PCT}_${PD_LABELS[$i]}" r="$W/results/B${B_PCT}_${PD_LABELS[$i]}"
    mkdir -p "$r"
    if [ -s "$dd/probeC_th/utts.jsonl" ]; then
      python -m scriptleak.sweep --dump "$dd/probeC_th" --majority th --minority en --spoken th \
          --group-by stratum --methods greedy --out "$r/probeC_th.json" > /dev/null || echo "!! probeC_th failed for ${PD_LABELS[$i]}"
      python -m scriptleak.evaluate --manifest "$dd/probeC_th/utts.jsonl" --majority th --minority en \
          --hyp-field pred_transducer --group-by stratum --out "$r/probeC_th_rnnt.json" > /dev/null || true
    fi
    if [ -s "$dd/probeC_ns/utts.jsonl" ]; then
      python -m scriptleak.nonspeech --manifest "$dd/probeC_ns/utts.jsonl" --out "$r/probeC_ns.json" > /dev/null || true
      python -m scriptleak.nonspeech --manifest "$dd/probeC_ns/utts.jsonl" --hyp-field pred_transducer \
          --out "$r/probeC_ns_rnnt.json" > /dev/null || true
    fi
  done
  {
    echo "################ C1. Thai speech + babble / music / quiet talker, English = ${B_PCT}%: CTC (leak rate / CER) ################"
    echo "(soft10/soft0 have the same SNR as noise10/noise0, 10-20 dB lower level; babmx is multilingual babble)"
    _compare_all probeC_th.json
    echo; echo "################ C1. same, transducer head ################"
    _compare_all probeC_th_rnnt.json
    echo; echo "################ C2. No speech: share of outputs with Latin letters, CTC ################"
    echo "(Latin output on babmx_only may be a correct transcript of English talkers in the babble)"
    _compare_files probeC_ns.json python -m scriptleak.nonspeech --compare
    echo; echo "################ C2. same, transducer head ################"
    _compare_files probeC_ns_rnnt.json python -m scriptleak.nonspeech --compare
    echo; echo "################ C2. same, share of outputs with any text at all (CTC) ################"
    _compare_files probeC_ns.json python -m scriptleak.nonspeech --key any_rate --compare
    local l dd
    for l in ${RESID_MODELS:-base both p10_both}; do
      dd="$W/dumps/B${B_PCT}_$l/heldout_rnnt"
      [ -s "$dd/utts.jsonl" ] || continue
      echo; echo "################ C3. $l on the held-out Thai test: which head leaks ################"
      python -m scriptleak.heads --manifest "$dd/utts.jsonl" --majority th --minority en --group-by stratum || true
      echo; echo "################ C3. $l: why the CTC head's leak frames win (H1 = mass split) ################"
      python -m scriptleak.analysis --dump "$dd" --majority th --minority en \
          --out "$W/results/B${B_PCT}_$l/frames_heldout.json" || true
    done
  } 2>&1 | tee "$W/probeC_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/probeC_en${B_PCT}_summary.txt"
}

stage_adaptB() {  # stage_adaptB KIND
  need BASE_CONFIG "Pick one of the yaml files printed by scripts/setup_env.sh (step 4)."
  local kind="${1:-}" manifest init include label m
  case "$kind" in
    adrm_all|adrm_enc) manifest="$W/${AT}_aug-both.jsonl"; init="$W/exp/th${TH_HOURS}_en${B_PCT}/final.nemo" ;;
    adim_all|adim_enc) manifest="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl"; init="$(_model_dir both)/final.nemo" ;;
    *) echo "usage: killtest.sh adaptB adrm_all|adrm_enc|adim_all|adim_enc"; exit 1 ;;
  esac
  case "$kind" in
    *_all) include=(encoder decoder joint ctc_decoder) ;;
    *_enc) include=(encoder) ;;
  esac
  [ -s "$manifest" ] || { echo "missing $manifest: run 'prepB' first"; exit 1; }
  [ -s "$init" ] || { echo "missing $init: the starting model has not been trained"; exit 1; }
  label="$(_label "$kind")"; m="$(_model_dir "$kind")"
  if [ -s "$m/final.nemo" ]; then
    echo "$m/final.nemo exists: adaptation B${B_PCT}_$label skipped"; return 0
  fi
  echo "adapting B${B_PCT}_$label: from $(basename "$(dirname "$init")") (${include[*]}), data $(basename "$manifest"), ${ADAPT_EPOCHS:-5} epochs at lr ${ADAPT_LR:-1e-4}"
  python -m scriptleak.nemo_tools.train --base-config "$BASE_CONFIG" \
      --train-manifest "$manifest" \
      --val-manifest "$W/th_central.dev.jsonl" "$W/en_dev.clean.jsonl" \
      --tokenizer "th=$W/tokenizers/th_bpe1024" "en=$W/tokenizers/en_bpe256" \
      --init-nemo "$init" --init-include "${include[@]}" \
      --exp-dir "$m" --save-every-epochs "${ADAPT_SAVE:-$([ "${ADAPT_EPOCHS:-5}" -le 5 ] && echo 1 || echo 3)}" \
      --seed "$SEED" --constant-lr "${ADAPT_LR:-1e-4}" \
      --max-epochs "${ADAPT_EPOCHS:-5}" --batch-size "$BATCH" --num-workers 8 --devices "$GPUS"
}

stage_nightC() {  # adaptB for each KIND (default all four), then evalB base both + KINDs
  local kinds=("$@") k
  [ ${#kinds[@]} -gt 0 ] || kinds=(adrm_all adrm_enc adim_all adim_enc)
  _gpus_free
  echo "== nightC, English = ${B_PCT}%, AUG_PROB = ${AUG_PROB}, seed = ${SEED}: ${kinds[*]}  ($(date))"
  for k in "${kinds[@]}"; do
    echo "== adapting B${B_PCT}_$(_label "$k")  ($(date))"
    ( stage_adaptB "$k" ) 2>&1 | tee "$W/train_B${B_PCT}_$(_label "$k").log" || echo "!! adaptation $k failed; continuing"
  done
  echo "== evaluation  ($(date))"
  stage_evalB base both "${kinds[@]}"
  echo "== nightC done  ($(date))"
}

# ---------------------------------------------------------------- v20: everything still to run, in one go
# realB + probeC (all trained models), nightC (G2b), English curves for the seed-1 models,
# clean seed 0, clean + both seed 2, then realB + probeC again for the new models.
# Each step runs in its own subshell: one failing step does not stop the next.
# About 20 hours on 8 A100. Steps already done are skipped (existing models and dumps are reused).
stage_marathon() {
  _gpus_free
  local step
  _step() {  # NAME CMD...
    local name="$1"; shift
    echo; echo "######## marathon: $name  ($(date))"
    ( "$@" ) 2>&1 | tee "$W/logs/marathon_$name.log" || echo "!! marathon step $name failed; going on"
  }
  mkdir -p "$W/logs"
  _step realB      stage_realB
  _step probeC     stage_probeC
  _step nightC     env SEED=0 bash "$HERE/scripts/killtest.sh" nightC
  _step eval_s1    env SEED=1 bash "$HERE/scripts/killtest.sh" evalB clean both
  _step clean_s0   env SEED=0 bash "$HERE/scripts/killtest.sh" nightB clean
  _step seed2      env SEED=2 bash "$HERE/scripts/killtest.sh" nightB clean both
  _step realB_new  stage_realB
  _step probeC_new stage_probeC
  echo; echo "######## marathon done  ($(date))"
}

# ---------------------------------------------------------------- v23
#   getrir     download the OpenSLR 28 room impulse responses (about 1.3 GB) into $D/RIRS_NOISES
#   prepR      reverberation (+ noise/music on 70% of those) on AUG_PROB of the utterances of BOTH blocks
#   trainB rir / nightB rir   train on it (label "rir")
#   marathon2  getrir, rir, th seeds 1 and 2, 15-epoch adaptations, then realB + probeC (about 19 h)
stage_getrir() {
  if [ -d "$D/RIRS_NOISES" ]; then echo "have $D/RIRS_NOISES"; return 0; fi
  mkdir -p "$D/downloads"
  wget -c -O "$D/downloads/rirs_noises.zip" "${OPENSLR:-https://www.openslr.org/resources}/28/rirs_noises.zip"
  ( cd "$D" && unzip -q -o downloads/rirs_noises.zip )
  [ -d "$D/RIRS_NOISES" ] || { echo "!! unzip did not create $D/RIRS_NOISES"; return 1; }
  echo "RIRs ready in $D/RIRS_NOISES"
}

stage_prepR() {
  [ -d "$D/RIRS_NOISES" ] || stage_getrir
  local base="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl"
  if [ -s "$W/${AT}_rir-both.jsonl" ]; then echo "have $W/${AT}_rir-both.jsonl"; return 0; fi
  python -m scriptleak.augment make-rir --manifest "$base" --rir-dir "$D/RIRS_NOISES" --noise-dir "$D/musan" \
      --out-dir "$D/aug_rir/en${B_PCT}" --out "$W/${AT}_rir-both.jsonl" \
      --prob "$AUG_PROB" --noise-prob "${RIR_NOISE_PROB:-0.7}" \
      --snr-min "${AUG_SNR_MIN:-0}" --snr-max "${AUG_SNR_MAX:-20}" --num-workers "${PREP_WORKERS:-16}"
}

stage_marathon2() {
  local step
  _step2() {  # NAME CMD...
    local name="$1"; shift
    echo; echo "######## marathon2: $name  ($(date))"
    ( "$@" ) 2>&1 | tee "$W/logs/marathon2_$name.log" || echo "!! marathon2 step $name failed; going on"
  }
  mkdir -p "$W/logs"
  _step2 getrir     stage_getrir
  _step2 rir        env SEED=0 bash "$HERE/scripts/killtest.sh" nightB rir
  _step2 th_s1      env SEED=1 bash "$HERE/scripts/killtest.sh" nightB th
  _step2 th_s2      env SEED=2 bash "$HERE/scripts/killtest.sh" nightB th
  _step2 adapt15    env SEED=0 ADAPT_EPOCHS=15 FORCE=1 bash "$HERE/scripts/killtest.sh" nightC adrm_enc adrm_all
  _step2 realB      env FORCE=1 bash "$HERE/scripts/killtest.sh" realB
  _step2 probeC     env FORCE=1 bash "$HERE/scripts/killtest.sh" probeC
  echo; echo "######## marathon2 done  ($(date))"
}

# ---------------------------------------------------------------- v24
#   seedC     CPU only: do seeds leak on the same utterances / speakers / kinds of sentence,
#             and 95% intervals (cluster bootstrap) for the real-audio leak rates
#   realdev   CPU + network: LOTUSDIS validation and AMI dev, the real DEV sets used to choose models
#   selectC   GPU: averaged weights of the last checkpoints of each run, dumps of every candidate
#             (final, averaged, checkpoints from epoch SEL_MIN_EPOCH on, 30 by default) on dev and test, and
#             whether choosing by the dev set lowers the test leak rate
#   SEL_MODELS (the 12 models of the clean / both / rir / th recipes), AVG_K (3: final + 2 last
#   checkpoints), SEL_MIN_EPOCH (30), LOTUS_DEV_FRAC (0.35), AMI_DEV_FRAC (0.5)
stage_seedC() {
  {
    echo "################ Do seeds leak on the same utterances? LOTUSDIS (Thai speech -> Latin) ################"
    python -m scriptleak.seedvar --work "$W" --b-pct "$B_PCT" --set real_lotus_th --out "$W/seedvar_lotus_en${B_PCT}.json" || true
    echo; echo "################ Same question on AMI (English speech -> Thai) ################"
    python -m scriptleak.seedvar --work "$W" --b-pct "$B_PCT" --set real_ami_en --out "$W/seedvar_ami_en${B_PCT}.json" || true
    echo; echo "################ 95% intervals for the real-audio leak rates ################"
    python -m scriptleak.bootstrap --work "$W" --b-pct "$B_PCT" --out "$W/bootstrap_en${B_PCT}.json" || true
  } 2>&1 | tee "$W/seedC_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/seedC_en${B_PCT}_summary.txt"
}

stage_realdev() {
  mkdir -p "$R"
  local raw="$R/lotus_dev.raw.jsonl" araw="$R/ami_dev.raw.jsonl"
  echo "== LOTUSDIS validation split  ($(date))"
  if [ ! -s "$raw" ]; then
    python -m scriptleak.prepare hf --dataset nectec/LOTUSDIS --split validation --data-files "data/validation-*" \
        --text-col sentence --copy-cols speaker_id mic --num-workers "${PREP_WORKERS:-8}" \
        --audio-out "$D/lotusdis/dev/wav" --out "$raw" || echo "!! LOTUSDIS validation failed"
  fi
  if [ -s "$raw" ]; then
    python -m scriptleak.real build --manifest "$raw" --name lotus --stratum-field mic \
        --keep-frac "${LOTUS_DEV_FRAC:-0.35}" --out-thai "$R/lotus_dev.th.jsonl" --out-mixed "$R/lotus_dev.mixed.jsonl" \
        --report "$R/lotus_dev.build.json"
  fi
  echo "== AMI dev, far-field  ($(date))"
  if [ ! -s "$araw" ]; then
    python -m scriptleak.real ami --out-dir "$D/ami" --split dev --mic sdm --num-workers "${PREP_WORKERS:-8}" \
        --out "$araw" || echo "!! AMI dev failed"
  fi
  if [ -s "$araw" ]; then
    python -m scriptleak.real build-en --manifest "$araw" --name ami --keep-frac "${AMI_DEV_FRAC:-0.5}" \
        --out "$R/ami_dev.en.jsonl" --report "$R/ami_dev.build.json"
  fi
}

stage_selectC() {
  _gpus_free
  if [ ! -s "$R/lotus_dev.th.jsonl" ] || [ ! -s "$R/ami_dev.en.jsonl" ]; then stage_realdev; fi
  [ -s "$R/lotus_dev.th.jsonl" ] && [ -s "$R/ami_dev.en.jsonl" ] || { echo "!! dev sets missing; see above"; exit 1; }
  local labels=(${SEL_MODELS:-clean clean_s1 clean_s2 both both_s1 both_s2 rir rir_s1 rir_s2 th th_s1 th_s2})
  local l m snaps running=0
  mkdir -p "$W/logs"
  echo "== averaging the last checkpoints (CPU)  ($(date))"
  for l in "${labels[@]}"; do
    m="$W/exp/B${B_PCT}_$l"
    [ -s "$m/final.nemo" ] && [ ! -s "${m}_avg/final.nemo" ] || continue
    snaps=($(ls "$m"/epoch*.nemo 2>/dev/null | sort | tail -n $(( ${AVG_K:-3} - 1 ))))
    [ ${#snaps[@]} -gt 0 ] || { echo "   $l: no checkpoints to average"; continue; }
    ( python -m scriptleak.nemo_tools.avg_ckpt --models "${snaps[@]}" "$m/final.nemo" --out "${m}_avg/final.nemo" \
        > "$W/logs/avg_$l.log" 2>&1 && echo "   averaged $l" || echo "!! averaging $l failed (see $W/logs/avg_$l.log)" ) &
    running=$((running + 1))
    if [ $running -ge 6 ]; then wait; running=0; fi
  done
  wait
  local jobs=() dd da snap e n item
  local DEVS=("dev_lotus_th=$R/lotus_dev.th.jsonl" "dev_ami_en=$R/ami_dev.en.jsonl")
  local TESTS=("real_lotus_th=$R/lotus.th.jsonl" "real_ami_en=$R/ami.en.jsonl")
  for l in "${labels[@]}"; do
    m="$W/exp/B${B_PCT}_$l"; dd="$W/dumps/B${B_PCT}_$l"; da="$W/dumps/B${B_PCT}_${l}_avg"
    [ -s "$m/final.nemo" ] || { echo "!! no $m/final.nemo; skipping $l"; continue; }
    for item in "${DEVS[@]}"; do
      _need_dump "$dd/${item%%=*}" && jobs+=("$m/final.nemo|${item#*=}|$dd/${item%%=*}")
    done
    for item in "${TESTS[@]}"; do
      _need_dump "$dd/${item%%=*}" && jobs+=("$m/final.nemo|${item#*=}|$dd/${item%%=*}|--transducer")
    done
    if [ -s "${m}_avg/final.nemo" ]; then
      for item in "${DEVS[@]}" "${TESTS[@]}"; do
        _need_dump "$da/${item%%=*}" && jobs+=("${m}_avg/final.nemo|${item#*=}|$da/${item%%=*}|--transducer")
      done
    fi
    for snap in "$m"/epoch*.nemo; do
      [ -e "$snap" ] || continue
      e="$(basename "$snap" .nemo)"; n=$((10#${e#epoch}))
      [ "$n" -ge "${SEL_MIN_EPOCH:-30}" ] || continue
      for item in "${DEVS[@]}" "${TESTS[@]}"; do
        _need_dump "$dd/sel_${e}_${item%%=*}" && jobs+=("$snap|${item#*=}|$dd/sel_${e}_${item%%=*}")
      done
    done
  done
  echo "== dumps  ($(date))"
  _run_jobs selectC "${jobs[@]+"${jobs[@]}"}"
  echo "== choosing by the dev set  ($(date))"
  python -m scriptleak.selection --work "$W" --b-pct "$B_PCT" --out "$W/selection_en${B_PCT}.json" 2>&1 \
    | tee "$W/selectC_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/selectC_en${B_PCT}_summary.txt"
}

# ---------------------------------------------------------------- v25
#   calibC    CPU only: one constant b added to the Latin-token scores of each model, chosen on the
#             real dev sets, applied to the test sets; how small the dev set can be; choosing by
#             MUSAN instead; leak per letter vs per utterance. Needs the dumps made by 'selectC'.
#             CALIB_WORKERS (16) processes read the dumps.
stage_calibC() {
  python -m scriptleak.calib --work "$W" --b-pct "$B_PCT" --workers "${CALIB_WORKERS:-16}" \
      --out "$W/calib_en${B_PCT}.json" 2>&1 | tee "$W/calibC_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/calibC_en${B_PCT}_summary.txt"
}

# ---------------------------------------------------------------- v26
#   ihmC      GPU: AMI eval through the close-talk headsets (IHM), the same meetings as the far-field
#             set, dumped with the 12 final models; also the LOTUSDIS Thai+English mixed set if a
#             model has no dump of it yet
#   paretoC   CPU only: leak against CER / WER / kept English words for every fix (b chosen three
#             ways on dev, utterance lock, script-marginalized decoding), trade-off curve over b,
#             leak and CER per microphone. PARETO_TOL (0.02) = allowed dev CER/WER increase.
stage_ihmC() {
  _gpus_free
  mkdir -p "$R" "$W/logs"
  local raw="$R/amiihm_test.raw.jsonl"
  echo "== AMI eval, close-talk headsets  ($(date))"
  if [ ! -s "$raw" ]; then
    python -m scriptleak.real ami --out-dir "$D/ami" --split eval --mic ihm --num-workers "${PREP_WORKERS:-8}" \
        --out "$raw" || echo "!! AMI IHM download failed"
  fi
  if [ -s "$raw" ] && [ ! -s "$R/amiihm.en.jsonl" ]; then
    python -m scriptleak.real build-en --manifest "$raw" --name amiihm --keep-frac "${AMI_FRAC:-0.5}" \
        --out "$R/amiihm.en.jsonl" --report "$R/amiihm.build.json"
  fi
  local labels=(${SEL_MODELS:-clean clean_s1 clean_s2 both both_s1 both_s2 rir rir_s1 rir_s2 th th_s1 th_s2})
  local jobs=() l m dd
  for l in "${labels[@]}"; do
    m="$W/exp/B${B_PCT}_$l/final.nemo"; dd="$W/dumps/B${B_PCT}_$l"
    [ -s "$m" ] || { echo "!! no $m; skipping $l"; continue; }
    [ -s "$R/amiihm.en.jsonl" ] && _need_dump "$dd/real_amiihm_en" && jobs+=("$m|$R/amiihm.en.jsonl|$dd/real_amiihm_en")
    [ -s "$R/lotus.mixed.jsonl" ] && _need_dump "$dd/real_lotus_mixed" && jobs+=("$m|$R/lotus.mixed.jsonl|$dd/real_lotus_mixed")
  done
  echo "== dumps  ($(date))"
  _run_jobs ihmC "${jobs[@]+"${jobs[@]}"}"
  echo "== done  ($(date))"
}

stage_paretoC() {
  python -m scriptleak.pareto --work "$W" --b-pct "$B_PCT" --workers "${CALIB_WORKERS:-16}" \
      --tol "${PARETO_TOL:-0.02}" --out "$W/pareto_en${B_PCT}.json" 2>&1 | tee "$W/paretoC_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/paretoC_en${B_PCT}_summary.txt"
}

# ---------------------------------------------------------------- v27
#   comboC    CPU only: the proposal end to end (seed chosen on the real dev set + script lock at the
#             end of each utterance), offline and, once streamC has run, in real streaming mode
#   streamC   GPU: the 12 final models run chunk by chunk with their caches (cache-aware streaming) on
#             the dev and test sets; a self-check on 32 dev utterances comes first.
#             STREAM_BATCH (16), STREAM_CONTEXT (empty = the model's own attention context, e.g. 70,13)
stage_comboC() {
  python -m scriptleak.combo --work "$W" --b-pct "$B_PCT" --workers "${CALIB_WORKERS:-16}" \
      --out "$W/combo_en${B_PCT}.json" 2>&1 | tee "$W/comboC_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/comboC_en${B_PCT}_summary.txt"
}

stage_streamC() {
  _gpus_free
  mkdir -p "$W/logs"
  local labels=(${SEL_MODELS:-clean clean_s1 clean_s2 both both_s1 both_s2 rir rir_s1 rir_s2 th th_s1 th_s2})
  local first="" l m bs="${STREAM_BATCH:-16}" ctx=""
  [ -n "${STREAM_CONTEXT:-}" ] && ctx="--att-context $STREAM_CONTEXT"
  for l in "${labels[@]}"; do [ -s "$W/exp/B${B_PCT}_$l/final.nemo" ] && { first="$l"; break; }; done
  [ -n "$first" ] || { echo "!! no final model found"; exit 1; }
  [ -s "$R/lotus_dev.th.jsonl" ] || { echo "!! dev sets missing (run realdev)"; exit 1; }
  echo "== self-check: offline vs streaming vs batched streaming, model $first  ($(date))"
  set +e
  CUDA_VISIBLE_DEVICES=0 python -m scriptleak.nemo_tools.stream_dump --model "$W/exp/B${B_PCT}_$first/final.nemo" \
      --manifest "$R/lotus_dev.th.jsonl" --selfcheck 32 --batch-size "$bs" $ctx 2>&1 | tee "$W/logs/streamC_selfcheck.log" \
      | grep -E "^(SELFCHECK|streaming:)|Error|error" 
  local rc=${PIPESTATUS[0]}
  set -e
  if [ "$rc" = 3 ]; then
    echo "   batched streaming differs from one-at-a-time: using batch size 1 (slower)"; bs=1
  elif [ "$rc" != 0 ]; then
    echo "!! streaming self-check failed (exit $rc); see $W/logs/streamC_selfcheck.log"; exit 1
  fi
  local jobs=() dd item
  local SETS=("dev_lotus_th=$R/lotus_dev.th.jsonl" "dev_ami_en=$R/ami_dev.en.jsonl"
              "real_lotus_th=$R/lotus.th.jsonl" "real_ami_en=$R/ami.en.jsonl")
  for l in "${labels[@]}"; do
    m="$W/exp/B${B_PCT}_$l/final.nemo"; dd="$W/dumps/B${B_PCT}_$l"
    [ -s "$m" ] || continue
    for item in "${SETS[@]}"; do
      [ -s "${item#*=}" ] || continue
      _need_dump "$dd/stream_${item%%=*}" && jobs+=("$m|${item#*=}|$dd/stream_${item%%=*}|--batch-size $bs $ctx")
    done
  done
  echo "== streaming dumps  ($(date))"
  DUMP_TOOL=scriptleak.nemo_tools.stream_dump _run_jobs streamC "${jobs[@]+"${jobs[@]}"}"
  echo "== done  ($(date))"
}

# ---------------------------------------------------------------- v28
#   singleC   CPU only: the proposal with one training run (checkpoint chosen on dev inside the run,
#             with the script lock) next to the three-run version, with paired 95% intervals
stage_singleC() {
  python -m scriptleak.singlerun --work "$W" --b-pct "$B_PCT" --workers "${CALIB_WORKERS:-16}" \
      --tol "${SEL_TOL:-0.01}" --out "$W/singlerun_en${B_PCT}.json" 2>&1 | tee "$W/singleC_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/singleC_en${B_PCT}_summary.txt"
}

# ---------------------------------------------------------------- v30
#   esB KIND...  GPU, long: retrain each KIND (default ES_KINDS="clean rir") for each seed in ES_SEEDS
#                ("0 1 2") with the real-dev leak monitor after every epoch (label <kind>[_sN]_es),
#                pick checkpoints with scriptleak.esmon (min-leak, guarded, early stopping), delete the
#                unpicked mon_epoch*.nemo, dump the picks on the test sets, then run esC.
#                MON_N (1000 dev utterances per set), MON_SAVE_FROM (10), SEL_TOL (0.01), ES_PATIENCE (5)
#   esC          CPU only: dev curves, test results of every rule, where training could have stopped
stage_esB() {
  _gpus_free
  need BASE_CONFIG "Pick one of the yaml files printed by scripts/setup_env.sh (step 4)."
  [ -s "$R/lotus_dev.th.jsonl" ] && [ -s "$R/ami_dev.en.jsonl" ] || { echo "!! dev sets missing (run realdev)"; exit 1; }
  local kinds=("$@"); [ ${#kinds[@]} -gt 0 ] || kinds=(${ES_KINDS:-clean rir})
  local kind seed manifest init label m picks e last jobs item
  mkdir -p "$W/logs"
  for kind in "${kinds[@]}"; do
    for seed in ${ES_SEEDS:-0 1 2}; do
      init=(); [ "$INIT" != "none" ] && init=(--init-pretrained "$INIT")
      case "$kind" in
        both|en|th) manifest="$W/${AT}_aug-$kind.jsonl" ;;
        rir)        manifest="$W/${AT}_rir-both.jsonl" ;;
        clean)      manifest="$W/train_th${TH_HOURS}_en${B_PCT}.jsonl" ;;
        *) echo "!! esB supports both|en|th|rir|clean, not '$kind'"; continue ;;
      esac
      [ -s "$manifest" ] || { echo "!! missing $manifest; skipping $kind"; continue; }
      label="$(SEED=$seed _label "$kind")_es"; m="$W/exp/B${B_PCT}_$label"
      echo; echo "######## esB: $label  ($(date))"
      if [ ! -s "$m/final.nemo" ]; then
        python -m scriptleak.nemo_tools.train --base-config "$BASE_CONFIG" \
            --train-manifest "$manifest" \
            --val-manifest "$W/th_central.dev.jsonl" "$W/en_dev.clean.jsonl" \
            --tokenizer "th=$W/tokenizers/th_bpe1024" "en=$W/tokenizers/en_bpe256" \
            ${init[@]+"${init[@]}"} --exp-dir "$m" --save-every-epochs 0 --seed "$seed" \
            --max-epochs "$B_EPOCHS" --batch-size "$BATCH" --num-workers 8 --devices "$GPUS" \
            --monitor-manifest "dev_lotus_th=$R/lotus_dev.th.jsonl" "dev_ami_en=$R/ami_dev.en.jsonl" \
            --monitor-n "${MON_N:-1000}" --monitor-save-from "${MON_SAVE_FROM:-10}" \
            2>&1 | tee "$W/logs/esB_$label.log" | grep -E "\[devmon\]|Error|error|Saved" || true
      fi
      [ -s "$m/final.nemo" ] || { echo "!! training of $label failed (see $W/logs/esB_$label.log)"; continue; }
      python -m scriptleak.esmon select --exp-dir "$m" --tol "${SEL_TOL:-0.01}" --patience "${ES_PATIENCE:-5}" --prune \
        || { echo "!! esmon select failed for $label"; continue; }
      last="$(python -c "import json,sys; print(json.load(open(sys.argv[1]))['final'])" "$m/esmon_picks.json")"
      jobs=()
      for e in $(python -c "import json,sys; d=json.load(open(sys.argv[1])); print(' '.join(sorted({str(v) for k,v in d.items() if not k.endswith('_stop')})))" "$m/esmon_picks.json"); do
        for item in "real_lotus_th=$R/lotus.th.jsonl" "real_ami_en=$R/ami.en.jsonl"; do
          if [ "$e" = "$last" ]; then
            _need_dump "$W/dumps/B${B_PCT}_$label/${item%%=*}" && jobs+=("$m/final.nemo|${item#*=}|$W/dumps/B${B_PCT}_$label/${item%%=*}")
          else
            local ck; ck="$(printf '%s/mon_epoch%03d.nemo' "$m" "$e")"
            local od; od="$(printf '%s/dumps/B%s_%s/mon_epoch%03d_%s' "$W" "$B_PCT" "$label" "$e" "${item%%=*}")"
            [ -s "$ck" ] && _need_dump "$od" && jobs+=("$ck|${item#*=}|$od")
          fi
        done
      done
      _run_jobs "esB_$label" "${jobs[@]+"${jobs[@]}"}"
    done
  done
  stage_esC
}

stage_esC() {
  local labels=() d
  for d in "$W"/exp/B${B_PCT}_*_es; do [ -s "$d/devmon.jsonl" ] && labels+=("$(basename "$d" | sed "s/^B${B_PCT}_//")"); done
  [ ${#labels[@]} -gt 0 ] || { echo "no *_es run with devmon.jsonl yet"; return 0; }
  python -m scriptleak.esmon report --work "$W" --b-pct "$B_PCT" --labels "${labels[@]}" \
      --out "$W/esmon_en${B_PCT}.json" 2>&1 | tee "$W/esC_en${B_PCT}_summary.txt"
  echo "Summary saved to $W/esC_en${B_PCT}_summary.txt"
}

case "${1:-}" in
  prepare)   stage_prepare ;;
  audit)     stage_audit ;;
  split)     stage_split ;;
  mix)       stage_mix ;;
  tokenizer) stage_tokenizer ;;
  train05)   train_one 05 ;;
  train20)   train_one 20 ;;
  dump)      stage_dump ;;
  results)   stage_results ;;
  probeA)    stage_probeA ;;
  noisefloor) stage_noisefloor ;;
  prepB)     stage_prepB ;;
  trainB)    stage_trainB "${2:-}" ;;
  evalB)     shift; stage_evalB "$@" ;;
  nightB)    shift; stage_nightB "$@" ;;
  realprep)  stage_realprep ;;
  realB)     stage_realB ;;
  probeC)    stage_probeC ;;
  adaptB)    stage_adaptB "${2:-}" ;;
  nightC)    shift; stage_nightC "$@" ;;
  marathon)  stage_marathon ;;
  getrir)    stage_getrir ;;
  prepR)     stage_prepR ;;
  marathon2) stage_marathon2 ;;
  seedC)     stage_seedC ;;
  realdev)   stage_realdev ;;
  selectC)   stage_selectC ;;
  calibC)    stage_calibC ;;
  ihmC)      stage_ihmC ;;
  paretoC)   stage_paretoC ;;
  comboC)    stage_comboC ;;
  streamC)   stage_streamC ;;
  singleC)   stage_singleC ;;
  esB)       shift; stage_esB "$@" ;;
  esC)       stage_esC ;;
  *) sed -n '2,35p' "$0"; exit 1 ;;
esac
